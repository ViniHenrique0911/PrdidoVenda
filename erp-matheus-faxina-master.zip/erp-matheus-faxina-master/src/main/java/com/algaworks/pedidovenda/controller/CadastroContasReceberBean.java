package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Cliente;
import com.algaworks.pedidovenda.model.ContasReceber;
import com.algaworks.pedidovenda.repository.Clientes;
import com.algaworks.pedidovenda.repository.ContasRecebers;
import com.algaworks.pedidovenda.security.UsuarioLogado;
import com.algaworks.pedidovenda.security.UsuarioSistema;
import com.algaworks.pedidovenda.service.CadastroContasReceberService;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroContasReceberBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private ContasReceber receber;

	@Inject
	private CadastroContasReceberService cadastroContasReceberService;

	@Inject
	private Clientes clientes;

	@Inject
	@UsuarioLogado
	private UsuarioSistema usuarioLogado;

	@Inject
	private ContasRecebers contasRecebers;

	private List<ContasReceber> contasReceberVinculada;

	private List<Cliente> listClientes;

	public void pegaIdContasReceber() {
		contasReceberVinculada = contasRecebers.contasRecebersVinculadas(receber.getPedido().getId());
	}

	public void inicializar() {
		this.listClientes = clientes.todosClientes();
		if (receber == null) {
			limpar();
		} else {
			pegaIdContasReceber();
			this.recalcularValor();
		}
	}

	public void limpar() {
		this.receber = new ContasReceber();
	}

	public void salvar() {
		/*
		 * Date data = new Date(); SimpleDateFormat spf = new
		 * SimpleDateFormat("yyyy-MM-dd"); String dataFormatada = spf.format(data);
		 * List<AberturaCaixa> aberturaCaixaMemoria =
		 * contasRecebers.aberturaCaixas(usuarioLogado.getUsuario().getId(),
		 * dataFormatada); if (aberturaCaixaMemoria.isEmpty()) {
		 * FacesUtil.addErrorMessage("É necessário abrir o caixa para receber!"); } else
		 * {
		 */
		try {
			cadastroContasReceberService.salvar(receber);
			FacesUtil.addInfoMessage("Contas a receber foi salvo com sucesso!");
			limpar();
		} catch (Exception e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	/* } */

	public void recalcularValor() {
		if (this.receber != null) {
			this.receber.recalcularValorTotal();
		}
	}

	public void recalcularDesconto() {
		if (this.receber != null) {
			this.receber.recalcularDesconto();
		}
	}

	public void recalcularJuros() {
		if (this.receber != null) {
			this.receber.recalcularJuros();
		}
	}

	public ContasReceber getReceber() {
		return receber;
	}

	public void setReceber(ContasReceber receber) {
		this.receber = receber;
	}

	public boolean isEditando() {
		return receber != null && receber.getId() == null;
	}

	public List<ContasReceber> getContasReceberVinculada() {
		return contasReceberVinculada;
	}

	public List<Cliente> getListClientes() {
		return listClientes;
	}

}
