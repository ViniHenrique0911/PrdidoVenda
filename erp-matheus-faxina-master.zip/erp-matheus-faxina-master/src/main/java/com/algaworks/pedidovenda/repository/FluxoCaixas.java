package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import com.algaworks.pedidovenda.model.FluxoCaixa;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class FluxoCaixas implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public List<FluxoCaixa> tudo() {
		return this.manager.createQuery("from FluxoCaixa", FluxoCaixa.class).getResultList();
	}

	public FluxoCaixa guardar(FluxoCaixa fluxoCaixa) {
		return manager.merge(fluxoCaixa);
	}
	
	@Transactional
	public void remover(FluxoCaixa fluxoCaixa) throws NegocioException {
		try {
			fluxoCaixa = porId(fluxoCaixa.getId());
			manager.remove(fluxoCaixa);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Fluxo de caixa não pode ser excluído.");
		}
	}

	public List<FluxoCaixa> porFluxoCaixa(String nome) {
		return this.manager.createQuery("from FluxoCaixa where upper(nome) like :nome", FluxoCaixa.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
	
	public FluxoCaixa porId(Long id) {
		return this.manager.find(FluxoCaixa.class, id);
	}

	public List<FluxoCaixa> porNome(String nome) {
		return this.manager.createQuery("from FluxoCaixa " + "where upper(nome) like :nome", FluxoCaixa.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

}