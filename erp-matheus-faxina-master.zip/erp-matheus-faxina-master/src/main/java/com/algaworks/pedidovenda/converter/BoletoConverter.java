package com.algaworks.pedidovenda.converter;

import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.convert.ClientConverter;

import com.algaworks.pedidovenda.model.Boleto;
import com.algaworks.pedidovenda.repository.Boletos;

@FacesConverter(forClass = Boleto.class)
public class BoletoConverter implements Converter, ClientConverter {

	@Inject
	private Boletos boletos;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Boleto retorno = null;

		if (StringUtils.isNotEmpty(value)) {
			retorno = this.boletos.porCodigo(new Long(value));
		}

		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			Boleto boleto = (Boleto) value; 
			return boleto != null && boleto.getId() != null ? boleto.getId().toString() : null;
		}
		return "";
	}

	@Override
	public Map<String, Object> getMetadata() {
		return null;
	}

	@Override
	public String getConverterId() {
		return "com.algaworks.Boleto";
	}

}