package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Categoria;
import com.algaworks.pedidovenda.service.CadastroCategoriaService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroCategoriaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Categoria categoria;
	
	@Inject
	private CadastroCategoriaService cadastroCategoriaService;
	
	public void inicializar(){
		if (categoria == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.categoria = new Categoria();
	}
	
	public void salvar() {
		try {
			cadastroCategoriaService.salvar(categoria);
			limpar();
			
			FacesUtil.addInfoMessage("Categoria foi salvo com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public Categoria getCategoria() {
		return categoria;
	}
	
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	
	public boolean isEditando() {
		return categoria != null && categoria.getId() == null;
	}
	
}
