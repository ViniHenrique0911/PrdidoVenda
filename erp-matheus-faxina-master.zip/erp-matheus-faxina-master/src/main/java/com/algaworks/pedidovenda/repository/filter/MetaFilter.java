package com.algaworks.pedidovenda.repository.filter;

import java.io.Serializable;

public class MetaFilter implements Serializable {

	private static final long serialVersionUID = 1L;

	private String vendedor;

	public String getVendedor() {
		return vendedor;
	}

	public void setVendedor(String vendedor) {
		this.vendedor = vendedor;
	}

}