package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.repository.Estados;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroEstadoService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Estados estados;
	
	@Transactional
	public Estado salvar(Estado estado) throws NegocioException {
		return estados.guardar(estado);
	}
}