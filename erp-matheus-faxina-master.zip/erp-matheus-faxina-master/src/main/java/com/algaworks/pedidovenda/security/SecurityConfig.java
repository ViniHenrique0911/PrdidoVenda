package com.algaworks.pedidovenda.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Bean
	public AppUserDetailsService userDetailsService() {
		return new AppUserDetailsService();
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		JsfLoginUrlAuthenticationEntryPoint jsfLoginEntry = new JsfLoginUrlAuthenticationEntryPoint();
		jsfLoginEntry.setLoginFormUrl("/Login.xhtml");
		jsfLoginEntry.setRedirectStrategy(new JsfRedirectStrategy());
		
		JsfAccessDeniedHandler jsfDeniedEntry = new JsfAccessDeniedHandler();
		jsfDeniedEntry.setLoginPath("/AcessoNegado.xhtml");
		jsfDeniedEntry.setContextRelative(true);
		
		http
			.csrf().disable()
			.headers().frameOptions().sameOrigin()
			.and()
			
		.authorizeRequests()
			.antMatchers("/Login.xhtml", "/Erro.xhtml", "/javax.faces.resource/**").permitAll()
			.antMatchers("/Home.xhtml", "/AcessoNegado.xhtml", "/dialogos/**").authenticated()
			.antMatchers("/ajusteEstoques/**").hasRole("GERENCIAR_AJUSTE_ESTOQUES")
			.antMatchers("/boletos/**").hasRole("GERENCIAR_BOLETOS")
			.antMatchers("/categorias/**").hasRole("GERENCIAR_CATEGORIAS")
			.antMatchers("/clientes/**").hasRole("GERENCIAR_CLIENTES")
			.antMatchers("/compras/**").hasRole("GERENCIAR_COMPRAS")
			.antMatchers("/configuracaoEmpresas/**").hasRole("GERENCIAR_CONFIGURACAO_EMPRESAS")
			.antMatchers("/contasRecebers/**").hasRole("GERENCIAR_CONTAS_RECEBERS")
			.antMatchers("/devolucoes/**").hasRole("GERENCIAR_DEVOLUCOES")
			.antMatchers("/estados/**").hasRole("GERENCIAR_ESTADOS")
			.antMatchers("/marcas/**").hasRole("GERENCIAR_MARCAS")
			.antMatchers("/menus/**").hasRole("GERENCIAR_MENUS")
			.antMatchers("/metas/**").hasRole("GERENCIAR_METAS")
			.antMatchers("/parcelas/**").hasRole("GERENCIAR_PARCELAS")
			.antMatchers("/pedidos/**").hasRole("GERENCIAR_PEDIDOS")
			.antMatchers("/permissoes/**").hasRole("GERENCIAR_PERMISSOES")
			.antMatchers("/produtos/**").hasRole("GERENCIAR_PRODUTOS")
			.antMatchers("/relatorios/**").hasRole("GERENCIAR_RELATORIOS")
			.antMatchers("/subCategorias/**").hasRole("GERENCIAR_SUB_CATEGORIAS")
			.antMatchers("/usuarios/**").hasRole("GERENCIAR_USUARIOS")
			.antMatchers("/preparar/**").hasRole("GERENCIAR_PREPAROS")
			.antMatchers("/forma_pagamentos/**").hasRole("GERENCIAR_FORMAS_PAGAMENTOS")
			.antMatchers("/mesas/**").hasRole("GERENCIAR_MESAS")
			.antMatchers("/caixas/**").hasRole("GERENCIAR_CAIXAS")
			.antMatchers("/grupos/**").hasRole("GERENCIAR_GRUPOS")
			.and()
		
		.formLogin()
			.loginPage("/Login.xhtml")
			.failureUrl("/Login.xhtml?invalid=true")
			.and()
		
		.logout()
			.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
			.and()
		
		.exceptionHandling()
			.accessDeniedPage("/AcessoNegado.xhtml")
			.authenticationEntryPoint(jsfLoginEntry)
			.accessDeniedHandler(jsfDeniedEntry);
	}
	
}