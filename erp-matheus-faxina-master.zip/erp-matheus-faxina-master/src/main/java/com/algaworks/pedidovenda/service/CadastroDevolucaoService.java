package com.algaworks.pedidovenda.service;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Devolucao;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.model.StatusDevolucao;
import com.algaworks.pedidovenda.repository.Devolucoes;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroDevolucaoService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Devolucoes devolucoes;
	
	@Transactional
	public Devolucao salvar(Devolucao devolucao) throws NegocioException {
		if (devolucao.isNovo()) {
			devolucao.setDataCriacao(new Date());
			devolucao.setStatus(StatusDevolucao.NAO_DEVOLVIDA);
		}
		
		devolucao.recalcularValorTotal();
		
		if (devolucao.isNaoAlteravel()) {
			throw new NegocioException("Devolução não pode ser alterado no status "
					+ devolucao.getStatus().getDescricao() + ".");
		}
		
		if (devolucao.getItens().isEmpty()) {
			throw new NegocioException("A devolução deve possuir pelo menos um item.");
		}
		
		if (devolucao.isValorTotalNegativo()) {
			throw new NegocioException("Valor total da devolução não pode ser negativo.");
		}
		
		devolucao = this.devolucoes.guardar(devolucao);
		return devolucao;
	}

	public List<Produto> produtosPorCliente() {
		return null;
	}
	
}