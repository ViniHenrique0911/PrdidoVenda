package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.AjusteEstoque;
import com.algaworks.pedidovenda.repository.AjusteEstoques;
import com.algaworks.pedidovenda.repository.filter.AjusteEstoqueFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaAjusteEstoquesBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private AjusteEstoques ajusteEstoques;
	
	private AjusteEstoqueFilter filtro;
	private List<AjusteEstoque> ajusteEstoquesFiltrados;
	
	private AjusteEstoque ajusteEstoqueSelecionado;
	
	public PesquisaAjusteEstoquesBean() {
		filtro = new AjusteEstoqueFilter();
	}
	
	public void pesquisar() {
		ajusteEstoquesFiltrados = ajusteEstoques.filtrados(filtro);
	}
	
	public void excluir() {
		try {
			ajusteEstoques.remover(ajusteEstoqueSelecionado);
			ajusteEstoquesFiltrados.remove(ajusteEstoqueSelecionado);
			
			FacesUtil.addInfoMessage("Ajuste de estoque do produto " + ajusteEstoqueSelecionado.getProduto().getNome() + 
					" foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<AjusteEstoque> getAjusteEstoquesFiltrados() {
		return ajusteEstoquesFiltrados;
	}

	public AjusteEstoqueFilter getFiltro() {
		return filtro;
	}

	public AjusteEstoque getAjusteEstoqueSelecionado() {
		return ajusteEstoqueSelecionado;
	}

	public void setAjusteEstoqueSelecionado(AjusteEstoque ajusteEstoqueSelecionado) {
		this.ajusteEstoqueSelecionado = ajusteEstoqueSelecionado;
	}
	
}
