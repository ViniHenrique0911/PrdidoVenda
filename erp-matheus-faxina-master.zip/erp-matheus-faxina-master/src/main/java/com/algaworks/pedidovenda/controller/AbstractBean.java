package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import com.algaworks.pedidovenda.converter.ConverterGenerico;
import com.algaworks.pedidovenda.repository.AbstractRepository;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

public abstract class AbstractBean<T> implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Class<T> classe;
	private List<T> listagem;
	private T entidade;
	private ConverterGenerico converter;
	
	public ConverterGenerico converter() {
		if (converter == null) {
			converter = new ConverterGenerico(getRepository());
		}
		return converter;
	}
	
	public AbstractBean(Class<T> classe) {
		this.classe = classe;
	}
	
	public abstract AbstractRepository<T> getRepository();

	public void salvar() {
		try {
			getRepository().salvar(entidade);
			FacesUtil.addInfoMessage("Registro salvo com sucesso!");
		} catch (Exception e) {
			FacesUtil.addErrorMessage("Erro ao salvar o registro!");
		}
	}

	public List<T> getListar() {
		if (listagem == null) {
			listagem = getRepository().listar();
		}
		
		return listagem;
	}

	public void excluir() {
		try {
			getRepository().excluir(entidade);
			FacesUtil.addInfoMessage("Registro excluído com sucesso!");
		} catch (Exception e) {
			FacesUtil.addInfoMessage("O registro não pode ser excluído!");
		}
	}
	
	public T getEntidade() {
		return entidade;
	}
	
	public void setEntidade(T entidade) {
        this.entidade = entidade;
    }

}
