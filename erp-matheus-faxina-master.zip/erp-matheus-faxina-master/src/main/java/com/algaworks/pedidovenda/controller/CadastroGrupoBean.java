package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.model.DualListModel;

import com.algaworks.pedidovenda.model.Grupo;
import com.algaworks.pedidovenda.model.Permissao;
import com.algaworks.pedidovenda.repository.Grupoos;
import com.algaworks.pedidovenda.service.CadastroGrupoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroGrupoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CadastroGrupoService cadastroGrupoService;

	private Grupo grupo;

	private Permissao grupoPermissao;

	private boolean editandoPermissao;

	@Inject
	private Grupoos grupos;

	private DualListModel<Permissao> listPermissoes;

	public CadastroGrupoBean() {
		limpar();
	}

	public void inicializar() {
		if (grupo == null) {
			limpar();
		}
		List<Permissao> lista = grupos.porGrupo();
		lista.removeAll(grupo.getPermissoes());

		listPermissoes = new DualListModel<>(lista, new ArrayList<>(grupo.getPermissoes()));
	}

	private void limpar() {
		grupo = new Grupo();
	}

	public void pegaPermissao(String nome) {
		System.out.println(nome);
	}

	public void salvar() {
		try {
			grupo.setPermissoes(listPermissoes.getTarget());
			this.grupo = cadastroGrupoService.salvar(this.grupo);
			limpar();
			System.out.println(listPermissoes);
			FacesUtil.addInfoMessage("Grupo foi salvo com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		}
	}

	public Grupo getGrupo() {
		return grupo;
	}

	public void setGrupo(Grupo grupo) {
		this.grupo = grupo;
	}

	public boolean isEditando() {
		return this.grupo.getId() != null;
	}

	public Permissao getGrupoPermissao() {
		return grupoPermissao;
	}

	public void setGrupoPermissao(Permissao grupoPermissao) {
		this.grupoPermissao = grupoPermissao;
	}

	public boolean isEditandoPermissao() {
		return editandoPermissao;
	}

	public void setEditandoPermissao(boolean editandoPermissao) {
		this.editandoPermissao = editandoPermissao;
	}

	public DualListModel<Permissao> getListPermissoes() {
		return listPermissoes;
	}

	public void setListPermissoes(DualListModel<Permissao> listPermissoes) {
		this.listPermissoes = listPermissoes;
	}

}