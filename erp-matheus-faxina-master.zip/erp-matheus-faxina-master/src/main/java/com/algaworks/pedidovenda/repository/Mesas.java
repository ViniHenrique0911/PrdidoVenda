
package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Mesa;
import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.repository.filter.MesaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Mesas implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Mesa porId(Long id) {
		return this.manager.find(Mesa.class, id);
	}
	
	public List<Mesa> todasMesas() {
		return this.manager.createQuery("from Mesa", Mesa.class).getResultList();
	}

	public List<Mesa> porNome(String nome) {
		return this.manager.createQuery("from Mesa " + "where upper(nome) like :nome", Mesa.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Mesa> filtrados(MesaFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Mesa> criteriaQuery = builder.createQuery(Mesa.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Mesa> mesaRoot = criteriaQuery.from(Mesa.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(mesaRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(mesaRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(mesaRoot.get("nome")));

		TypedQuery<Mesa> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public Mesa guardar(Mesa mesa) {
		return manager.merge(mesa);
	}

	@Transactional
	public void remover(Mesa mesa) throws NegocioException {
		try {
			mesa = porId(mesa.getId());
			manager.remove(mesa);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Mesa não pode ser excluído.");
		}
	}

	public List<Estado> porEstado(String nome) {
		return this.manager.createQuery("from Estado where upper(nome) like :nome", Estado.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
}