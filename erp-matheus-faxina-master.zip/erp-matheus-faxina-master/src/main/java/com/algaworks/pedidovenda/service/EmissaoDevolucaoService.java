package com.algaworks.pedidovenda.service;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.ContasReceber;
import com.algaworks.pedidovenda.model.Devolucao;
import com.algaworks.pedidovenda.model.StatusContasReceber;
import com.algaworks.pedidovenda.model.StatusDevolucao;
import com.algaworks.pedidovenda.model.TipoContasReceber;
import com.algaworks.pedidovenda.repository.ContasRecebers;
import com.algaworks.pedidovenda.repository.Devolucoes;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class EmissaoDevolucaoService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CadastroDevolucaoService cadastroDevolucaoService;
	
	@Inject
	private EstoqueDevolucaoService estoqueService;
	
	@Inject
	private Devolucoes devolucoes;
	
	@Inject
	private ContasRecebers contasRecebers;
	
	@Transactional
	public Devolucao emitir(Devolucao devolucao) throws NegocioException {
		devolucao = this.cadastroDevolucaoService.salvar(devolucao);
		
		if (devolucao.isNaoEmissivel()) {
			throw new NegocioException("Devolucao não pode ser emitido com status "
					+ devolucao.getStatus().getDescricao() + ".");
		}
		
		this.estoqueService.aumentarItensEstoque(devolucao);
		
		devolucao.setStatus(StatusDevolucao.DEVOLVIDA);
		
		gerarContasReceber(devolucao);
		/*gerarComissao(devolucao);*/
		
		devolucao = this.devolucoes.guardar(devolucao);
		
		return devolucao;
	}
	
	/*private void gerarComissao(Devolucao devolucao) {
		Comissao comissao = new Comissao();
		comissao.setDevolucao(devolucao);
		comissao.setDataComissao(devolucao.getDataCriacao());
		comissao.setValorComissao(calcularPorcentagem(comissao.getPorcentagem(), devolucao.getValorTotal()));
		comissao.setVendedor(devolucao.getVendedor());
		comissao.setTipoComissao(TipoComissao.DEVOLUCAO);
		comissoes.guardar(comissao);
	}*/
	
	public BigDecimal calcularPorcentagem(BigDecimal porcentagem, BigDecimal valor) {
		return valor.divide(new BigDecimal(100.0)).multiply(porcentagem);
	}
	
	public void gerarContasReceber(Devolucao devolucao) {
        ContasReceber contasReceber = new ContasReceber();
        contasReceber.setCliente(devolucao.getCliente());
        contasReceber.setDataLancamento(devolucao.getDataCriacao());
        contasReceber.setDevolucao(devolucao);
        contasReceber.setVendedor(devolucao.getVendedor());
        contasReceber.setStatus(StatusContasReceber.A_RECEBER);
        contasReceber.setValorPagamento(devolucao.getValorTotal());
        contasReceber.setDataVencimento(devolucao.getDataCriacao());
        contasReceber.setTipoContasReceber(TipoContasReceber.CREDITO);
        
        contasRecebers.guardar(contasReceber);
}
	
}
