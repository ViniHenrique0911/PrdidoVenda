package com.algaworks.pedidovenda.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import com.algaworks.pedidovenda.model.Marca;
import com.algaworks.pedidovenda.model.Preco;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.model.SubCategoria;
import com.algaworks.pedidovenda.model.TipoProduto;
import com.algaworks.pedidovenda.model.UnidadeMedidaProduto;
import com.algaworks.pedidovenda.repository.Produtos;
import com.algaworks.pedidovenda.repository.SubCategorias;
import com.algaworks.pedidovenda.service.CadastroProdutoService;
import com.algaworks.pedidovenda.service.FotoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroProdutoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CadastroProdutoService cadastroProdutoService;

	@Inject
	private SubCategorias subCategorias;

	@Inject
	private FotoService fotoService;

	@Inject
	private Produtos produtos;

	private Produto produto;

	private Preco grupoPreco = new Preco();

	private boolean editandoPreco;

	public CadastroProdutoBean() {
		limpar();
	}

	public void inicializar() {
		if (this.produto == null) {
			limpar();
			this.grupoPreco = new Preco();
		}
	}

	private void limpar() {
		produto = new Produto();
	}

	public void salvar() {
		try {
			this.produto = cadastroProdutoService.salvar(this.produto);
			limpar();

			FacesUtil.addInfoMessage("Produto foi salvo com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		}
	}

	public List<SubCategoria> completarSubCategoria(String nome) {
		return this.subCategorias.porSubCategoria(nome);
	}

	public void novoPreco() {
		this.grupoPreco = new Preco();
		this.grupoPreco.setProduto(this.produto);
		this.editandoPreco = false;
	}

	public void editarPreco(Preco grupoPreco) {
		this.grupoPreco = grupoPreco;
		this.editandoPreco = true;
	}

	public void confirmaPreco() {
		if (!this.produto.getGrupoPreco().contains(this.grupoPreco)
				|| this.produto.getGrupoPreco().contains(this.grupoPreco)) {
			if (this.editandoPreco == false) {
				this.produto.getGrupoPreco().add(this.grupoPreco);
			}
		}
	}

	public void excluirPreco(Preco grupoPreco) {
		this.produto.getGrupoPreco().remove(grupoPreco);
	}

	public void upload(FileUploadEvent event) {
		UploadedFile uploadedFile = event.getFile();

		try {
			fotoService.deletar(produto.getFoto());

			String foto = fotoService.salvarFotoTemp(uploadedFile.getFileName(), event.getFile().getContents());
			produto.setFoto(foto);
		} catch (Exception e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public void removerFoto() {
		try {
			fotoService.deletarTemp(produto.getFoto());
		} catch (IOException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}

		produto.setFoto(null);
	}

	public List<Marca> completarMarca(String nome) {
		return this.produtos.porMarca(nome);
	}

	public UnidadeMedidaProduto[] getUnidadeMedidaProduto() {
		return UnidadeMedidaProduto.values();
	}

	public TipoProduto[] getTipoProduto() {
		return TipoProduto.values();
	}

	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

	public boolean isEditando() {
		return this.produto.getId() != null;
	}

	public Preco getGrupoPreco() {
		return grupoPreco;
	}

	public void setGrupoPreco(Preco grupoPreco) {
		this.grupoPreco = grupoPreco;
	}

	public boolean isEditandoPreco() {
		return editandoPreco;
	}

	public void setEditandoPreco(boolean editandoPreco) {
		this.editandoPreco = editandoPreco;
	}

}