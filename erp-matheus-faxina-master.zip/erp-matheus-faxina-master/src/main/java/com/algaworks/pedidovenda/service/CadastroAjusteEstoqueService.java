package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.AjusteEstoque;
import com.algaworks.pedidovenda.repository.AjusteEstoques;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroAjusteEstoqueService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private AjusteEstoques ajusteEstoques;
	
	@Transactional
	public AjusteEstoque salvar(AjusteEstoque ajusteEstoque) throws NegocioException {
		return ajusteEstoques.guardar(ajusteEstoque);
	}
}