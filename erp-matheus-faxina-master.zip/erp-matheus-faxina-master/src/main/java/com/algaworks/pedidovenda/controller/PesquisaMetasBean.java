package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Meta;
import com.algaworks.pedidovenda.repository.Metas;
import com.algaworks.pedidovenda.repository.filter.MetaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaMetasBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private Metas metas;
	
	private MetaFilter filtro;
	private List<Meta> metasFiltrados;
	
	private Meta metaSelecionado;
	
	public PesquisaMetasBean() {
		filtro = new MetaFilter();
	}
	
	public void pesquisar() {
		metasFiltrados = metas.filtrados(filtro);
	}
	
	public void excluir() {
		try {
			metas.remover(metaSelecionado);
			metasFiltrados.remove(metaSelecionado);
			
			FacesUtil.addInfoMessage("Meta " + metaSelecionado.getVendedor().getNome() + 
					" foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<Meta> getMetasFiltrados() {
		return metasFiltrados;
	}

	public MetaFilter getFiltro() {
		return filtro;
	}

	public Meta getMetaSelecionado() {
		return metaSelecionado;
	}

	public void setMetaSelecionado(Meta metaSelecionado) {
		this.metaSelecionado = metaSelecionado;
	}
	
}
