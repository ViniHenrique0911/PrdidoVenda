package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Permissao;
import com.algaworks.pedidovenda.repository.Permissoes;
import com.algaworks.pedidovenda.repository.filter.PermissaoFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaPermissoesBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Permissoes permissoes;

	private PermissaoFilter filtro;
	private List<Permissao> permissoesFiltrados;

	private Permissao permissaoSelecionado;

	public PesquisaPermissoesBean() {
		filtro = new PermissaoFilter();
	}

	public void pesquisar() {
		permissoesFiltrados = permissoes.filtrados(filtro);
	}

	public void excluir() {
		try {
			permissoes.remover(permissaoSelecionado);
			permissoesFiltrados.remove(permissaoSelecionado);

			FacesUtil.addInfoMessage("Permissão " + permissaoSelecionado.getNome() + " foi excluída com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public Permissoes getPermissoes() {
		return permissoes;
	}

	public void setPermissoes(Permissoes permissoes) {
		this.permissoes = permissoes;
	}

	public PermissaoFilter getFiltro() {
		return filtro;
	}

	public void setFiltro(PermissaoFilter filtro) {
		this.filtro = filtro;
	}

	public List<Permissao> getPermissoesFiltrados() {
		return permissoesFiltrados;
	}

	public void setPermissoesFiltrados(List<Permissao> permissoesFiltrados) {
		this.permissoesFiltrados = permissoesFiltrados;
	}

	public Permissao getPermissaoSelecionado() {
		return permissaoSelecionado;
	}

	public void setPermissaoSelecionado(Permissao permissaoSelecionado) {
		this.permissaoSelecionado = permissaoSelecionado;
	}

}
