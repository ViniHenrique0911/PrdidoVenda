package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.repository.ContasRecebers;

@Named
@SessionScoped
public class InformacoesBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private ContasRecebers contasRecebers;
	
	public BigDecimal getTotalRecebido() {
		return contasRecebers.getTotalRecebido();
	}
	
	public BigDecimal getTotalReceber() {
		return contasRecebers.getTotalReceber();
	}
	
	public Long getTotalContasReceberRecebido() {
		return contasRecebers.getTotalContasReceberRecebido();
	}
	
	public Long getTotalContasReceberReceber() {
		return contasRecebers.getTotalContasReceberReceber();
	}
	
}
