package com.algaworks.pedidovenda.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "preco")
public class Preco implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String nome;

	private BigDecimal valor = new BigDecimal(0);

	@NotNull
	@ManyToOne
	@JoinColumn(name = "produto_id", nullable = false)
	private Produto produto;

	private Boolean baixavel;

	private Float quantidadeBaixavel = new Float(0);;

	private Boolean baixarCarvao = false;

	private Float baixarCarvaoValor = new Float(0);

	private Boolean baixarAluminio = false;

	private Float baixarAluminioValor = new Float(0);

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Boolean getBaixavel() {
		return baixavel;
	}

	public void setBaixavel(Boolean baixavel) {
		this.baixavel = baixavel;
	}

	public Float getQuantidadeBaixavel() {
		return quantidadeBaixavel;
	}

	public void setQuantidadeBaixavel(Float quantidadeBaixavel) {
		this.quantidadeBaixavel = quantidadeBaixavel;
	}

	public Boolean getBaixarCarvao() {
		return baixarCarvao;
	}

	public void setBaixarCarvao(Boolean baixarCarvao) {
		this.baixarCarvao = baixarCarvao;
	}

	public Float getBaixarCarvaoValor() {
		return baixarCarvaoValor;
	}

	public void setBaixarCarvaoValor(Float baixarCarvaoValor) {
		this.baixarCarvaoValor = baixarCarvaoValor;
	}

	public Boolean getBaixarAluminio() {
		return baixarAluminio;
	}

	public void setBaixarAluminio(Boolean baixarAluminio) {
		this.baixarAluminio = baixarAluminio;
	}

	public Float getBaixarAluminioValor() {
		return baixarAluminioValor;
	}

	public void setBaixarAluminioValor(Float baixarAluminioValor) {
		this.baixarAluminioValor = baixarAluminioValor;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Preco other = (Preco) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}