package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.repository.filter.EstadoFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Estados implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Estado porId(Long id) {
		return this.manager.find(Estado.class, id);
	}

	public List<Estado> porNome(String nome) {
		return this.manager.createQuery("from Estado " + "where upper(nome) like :nome", Estado.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Estado> filtrados(EstadoFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Estado> criteriaQuery = builder.createQuery(Estado.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Estado> estadoRoot = criteriaQuery.from(Estado.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(estadoRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}
		
		if (StringUtils.isNotBlank(filtro.getSigla())) {
			predicates.add(
					builder.like(builder.lower(estadoRoot.get("sigla")), "%" + filtro.getSigla().toLowerCase() + "%"));
		}

		criteriaQuery.select(estadoRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(estadoRoot.get("nome")));

		TypedQuery<Estado> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public Estado guardar(Estado estado) {
		return manager.merge(estado);
	}

	@Transactional
	public void remover(Estado estado) throws NegocioException {
		try {
			estado = porId(estado.getId());
			manager.remove(estado);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Estado não pode ser excluído.");
		}
	}

	public List<Estado> porEstado(String nome) {
		return this.manager.createQuery("from Estado where upper(nome) like :nome", Estado.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
}