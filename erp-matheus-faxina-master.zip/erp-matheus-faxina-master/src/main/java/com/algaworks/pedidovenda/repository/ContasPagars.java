package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.algaworks.pedidovenda.model.ContasPagar;
import com.algaworks.pedidovenda.repository.filter.ContasPagarFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class ContasPagars implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public ContasPagar porId(Long id) {
		return this.manager.find(ContasPagar.class, id);
	}
	
	public List<ContasPagar> listar() {
		Session session = this.manager.unwrap(Session.class);

		Criteria criteria = session.createCriteria(ContasPagar.class);
		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	public List<ContasPagar> filtrados(ContasPagarFilter filtro) {
		Session session = this.manager.unwrap(Session.class);

		Criteria criteria = session.createCriteria(ContasPagar.class)
				// fazemos uma associação (join) com cliente e nomeamos como "c"
				.createAlias("cliente", "c")
				// fazemos uma associação (join) com vendedor e nomeamos como "v"
				.createAlias("pedido", "p")
				.createAlias("devolucao", "d");

		if (StringUtils.isNotBlank(filtro.getNomeCliente())) {
			// acessamos o nome do cliente associado ao pedido pelo alias "c", criado
			// anteriormente
			criteria.add(Restrictions.ilike("c.nome", filtro.getNomeCliente(), MatchMode.ANYWHERE));
		}

		if (filtro.getNumeroPedidoDe() != null) {
			// id deve ser maior ou igual (ge = greater or equals) a filtro.numeroDe
			criteria.add(Restrictions.ge("p.id", filtro.getNumeroPedidoDe()));
		}

		if (filtro.getNumeroPedidoAte() != null) {
			criteria.add(Restrictions.le("p.id", filtro.getNumeroPedidoAte()));
		}
		
		if (filtro.getNumeroDevolucaoDe() != null) {
			// id deve ser maior ou igual (ge = greater or equals) a filtro.numeroDe
			criteria.add(Restrictions.ge("d.id", filtro.getNumeroDevolucaoDe()));
		}

		if (filtro.getNumeroDevolucaoAte() != null) {
			criteria.add(Restrictions.le("d.id", filtro.getNumeroDevolucaoAte()));
		}

		if (filtro.getNumeroContasDe() != null) {
			// id deve ser maior ou igual (ge = greater or equals) a filtro.numeroDe
			criteria.add(Restrictions.ge("id", filtro.getNumeroContasDe()));
		}

		if (filtro.getNumeroContasAte() != null) {
			// id deve ser maior ou igual (ge = greater or equals) a filtro.numeroDe
			criteria.add(Restrictions.le("id", filtro.getNumeroContasAte()));
		}

		if (filtro.getDataLancamentoDe() != null) {
			criteria.add(Restrictions.ge("dataLancamento", filtro.getDataLancamentoDe()));
		}

		if (filtro.getDataLancamentoAte() != null) {
			criteria.add(Restrictions.le("dataLancamento", filtro.getDataLancamentoAte()));
		}

		if (filtro.getDataPagamentoDe() != null) {
			criteria.add(Restrictions.ge("dataPagamento", filtro.getDataPagamentoDe()));
		}

		if (filtro.getDataPagamentoAte() != null) {
			criteria.add(Restrictions.le("dataPagamento", filtro.getDataPagamentoAte()));
		}

		if (filtro.getStatuses() != null && filtro.getStatuses().length > 0) {
			// adicionamos uma restrição "in", passando um array de constantes da enum StatusPedido
			criteria.add(Restrictions.in("status", filtro.getStatuses()));
		}

		return criteria.addOrder(Order.asc("id")).list();
	}

	public ContasPagar guardar(ContasPagar contasPagar) {
		return manager.merge(contasPagar);
	}

	@Transactional
	public void remover(ContasPagar contasPagar) throws NegocioException {
		try {
			contasPagar = porId(contasPagar.getId());
			manager.remove(contasPagar);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Contas a pagar não pode ser excluído.");
		}
	}
	
	public BigDecimal getTotalRecebido() {
		return (BigDecimal) manager.createQuery("select sum(cr.valorRecebimento) from ContasPagar cr where cr.status = 'RECEBIDO'").getSingleResult();
	}
	
	public BigDecimal getTotalReceber() {
		return (BigDecimal) manager.createQuery("select sum(cr.valorPagamento) from ContasPagar cr where cr.status = 'A_RECEBER'").getSingleResult();
	}
	
	public Long getTotalContasPagarRecebido() {
		return (Long) manager.createQuery("select count(cr.id) from ContasPagar cr where cr.status = 'RECEBIDO'").getSingleResult();
	}
	
	public Long getTotalContasPagarReceber() {
		return (Long) manager.createQuery("select count(cr.id) from ContasPagar cr where cr.status = 'A_RECEBER'").getSingleResult();
	}
	
}