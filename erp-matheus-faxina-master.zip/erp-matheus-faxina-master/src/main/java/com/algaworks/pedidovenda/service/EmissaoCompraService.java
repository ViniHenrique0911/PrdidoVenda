package com.algaworks.pedidovenda.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Compra;
import com.algaworks.pedidovenda.model.ContasPagar;
import com.algaworks.pedidovenda.model.ItemCompra;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.model.StatusCompra;
import com.algaworks.pedidovenda.model.StatusContasPagar;
import com.algaworks.pedidovenda.model.TipoContasPagar;
import com.algaworks.pedidovenda.repository.Compras;
import com.algaworks.pedidovenda.repository.ContasPagars;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class EmissaoCompraService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CadastroCompraService cadastroCompraService;

	@Inject
	private EstoqueCompraService estoqueService;

	@Inject
	private Compras compras;

	@Inject
	private ContasPagars contasRecebers;

	@Transactional
	public Compra emitir(Compra compra) throws NegocioException {
		compra = this.cadastroCompraService.salvar(compra);

		if (compra.isNaoEmissivel()) {
			throw new NegocioException(
					"Compra não pode ser emitido com status " + compra.getStatus().getDescricao() + ".");
		}
		
		for (ItemCompra itemCompra : compra.getItens()) {
			Produto produtoSalvar = itemCompra.getProduto();
			produtoSalvar.setValorUnitario(itemCompra.getValorUnitario());
		}

		this.estoqueService.baixarItensEstoque(compra);

		compra.setStatus(StatusCompra.EMITIDO);

		compra = this.compras.guardar(compra);

		gerarContasPagar(compra);

		return compra;
	}

	public BigDecimal calcularPorcentagem(BigDecimal porcentagem, BigDecimal valor) {
		return valor.divide(new BigDecimal(100.0)).multiply(porcentagem);
	}

	public void gerarContasPagar(Compra compra) {
		for (int i = 1; i <= compra.getParcela().getNumeroParcela(); i++) {
			Date dtParcela = compra.getDataCriacao();
			Calendar cal = Calendar.getInstance();

			if (compra.getParcela().isAvista() == true) {
				cal.setTime(dtParcela);
				dtParcela = cal.getTime();
			}

			if (compra.getParcela().isAvista() == false) {
				cal.setTime(dtParcela);
				cal.add(Calendar.MONTH, i * +1);
				dtParcela = cal.getTime();
			}

			ContasPagar contasReceber = new ContasPagar();
			contasReceber.setCliente(compra.getCliente());
			contasReceber.setDataLancamento(compra.getDataCriacao());
			contasReceber.setCompra(compra);
			contasReceber.setVendedor(compra.getVendedor());
			contasReceber.setStatus(StatusContasPagar.A_PAGAR);
			contasReceber.setNumeroParcela(i);
			contasReceber.setValorPagamento(
					compra.getValorTotal().divide(new BigDecimal(compra.getParcela().getNumeroParcela()), 2));
			contasReceber.setDataVencimento(dtParcela);
			contasReceber.setTipoContasPagar(TipoContasPagar.DEBITO);
			contasReceber.setSubTotal(
					compra.getValorTotal().divide(new BigDecimal(compra.getParcela().getNumeroParcela()), 2));

			contasRecebers.guardar(contasReceber);
		}
	}

}
