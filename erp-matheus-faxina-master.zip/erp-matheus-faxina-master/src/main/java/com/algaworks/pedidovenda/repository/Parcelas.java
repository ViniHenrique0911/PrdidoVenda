package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.algaworks.pedidovenda.model.Parcela;
import com.algaworks.pedidovenda.repository.filter.ParcelaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Parcelas implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Parcela porId(Long id) {
		return this.manager.find(Parcela.class, id);
	}

	public List<Parcela> parcelas() {
		return this.manager.createQuery("from Parcela", Parcela.class).getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Parcela> filtrados(ParcelaFilter filtro) {
		Session session = manager.unwrap(Session.class);
		Criteria criteria = session.createCriteria(Parcela.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			criteria.add(Restrictions.ilike("nome", filtro.getNome(), MatchMode.ANYWHERE));
		}

		return criteria.addOrder(Order.asc("nome")).list();
	}

	public Parcela guardar(Parcela parcela) {
		return manager.merge(parcela);
	}

	@Transactional
	public void remover(Parcela parcela) throws NegocioException {
		try {
			parcela = porId(parcela.getId());
			manager.remove(parcela);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Parcela não pode ser excluído.");
		}
	}
}