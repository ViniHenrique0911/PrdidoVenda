package com.algaworks.pedidovenda.model;

public enum TipoFluxoCaixa {

	CONTAS_RECEBER("Contas a receber"), 
	CONTAS_PAGAR("Contas a pagar");
	
	private String descricao;
	
	TipoFluxoCaixa(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}
	
}