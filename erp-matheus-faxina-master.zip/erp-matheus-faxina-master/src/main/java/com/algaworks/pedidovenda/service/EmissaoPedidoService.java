package com.algaworks.pedidovenda.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.ContasReceber;
import com.algaworks.pedidovenda.model.Pedido;
import com.algaworks.pedidovenda.model.Preparar;
import com.algaworks.pedidovenda.model.StatusContasReceber;
import com.algaworks.pedidovenda.model.StatusPedido;
import com.algaworks.pedidovenda.model.TipoContasReceber;
import com.algaworks.pedidovenda.repository.ContasRecebers;
import com.algaworks.pedidovenda.repository.Pedidos;
import com.algaworks.pedidovenda.repository.Preparars;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class EmissaoPedidoService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CadastroPedidoService cadastroPedidoService;

	@Inject
	private EstoqueService estoqueService;

	@Inject
	private Pedidos pedidos;

	@Inject
	private ContasRecebers contasRecebers;

	@Inject
	private Preparars preparars;

	@Transactional
	public Pedido emitir(Pedido pedido) throws NegocioException {
		pedido = this.cadastroPedidoService.salvar(pedido);

		if (pedido.isNaoEmissivel()) {
			throw new NegocioException(
					"Pedido não pode ser emitido com status " + pedido.getStatus().getDescricao() + ".");
		}

		if (pedido.getMesa() != null) {
			pedido.getMesa().setOcupada(true);
		}

		this.estoqueService.baixarItensEstoque(pedido);

		pedido.setStatus(StatusPedido.EMITIDO);

		pedido = this.pedidos.guardar(pedido);

		gerarContasReceber(pedido);

		if (pedido.getMandaPreparar() == true) {
			geraPreparacao(pedido);
		}

		return pedido;
	}

	public BigDecimal calcularPorcentagem(BigDecimal porcentagem, BigDecimal valor) {
		return valor.divide(new BigDecimal(100.0)).multiply(porcentagem);
	}

	private void geraPreparacao(Pedido pedido) {
		Preparar preparar = new Preparar();
		preparar.setEntregue(false);
		preparar.setPreparado(false);
		preparar.setNome(pedido.getCliente().getNome());
		preparar.setDataCriacao(pedido.getDataCriacao());
		preparar.setObservacao(pedido.getObservacao());
		preparar.setPedido(pedido);
		preparars.guardar(preparar);
	}

	public void gerarContasReceber(Pedido pedido) {
		for (int i = 1; i <= pedido.getParcela().getNumeroParcela(); i++) {
			Date dtParcela = pedido.getDataCriacao();
			Calendar cal = Calendar.getInstance();

			if (pedido.getParcela().isAvista() == true) {
				cal.setTime(dtParcela);
				dtParcela = cal.getTime();
			}

			if (pedido.getParcela().isAvista() == false) {
				cal.setTime(dtParcela);
				cal.add(Calendar.MONTH, i * +1);
				dtParcela = cal.getTime();
			}

			ContasReceber contasReceber = new ContasReceber();
			contasReceber.setCliente(pedido.getCliente());
			contasReceber.setDataLancamento(pedido.getDataCriacao());
			contasReceber.setPedido(pedido);
			contasReceber.setVendedor(pedido.getVendedor());
			contasReceber.setStatus(StatusContasReceber.A_RECEBER);
			contasReceber.setNumeroParcela(i);
			contasReceber.setValorPagamento(
					pedido.getValorTotal().divide(new BigDecimal(pedido.getParcela().getNumeroParcela()), 2));
			contasReceber.setDataVencimento(dtParcela);
			contasReceber.setTipoContasReceber(TipoContasReceber.DEBITO);
			contasReceber.setSubTotal(
					pedido.getValorTotal().divide(new BigDecimal(pedido.getParcela().getNumeroParcela()), 2));

			contasRecebers.guardar(contasReceber);
		}
	}

}
