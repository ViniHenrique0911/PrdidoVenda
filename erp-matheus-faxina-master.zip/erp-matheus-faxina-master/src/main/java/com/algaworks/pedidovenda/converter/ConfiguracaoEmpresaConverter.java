package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.ConfiguracaoEmpresa;
import com.algaworks.pedidovenda.repository.ConfiguracoesEmpresas;

@FacesConverter(forClass = ConfiguracaoEmpresa.class)
public class ConfiguracaoEmpresaConverter implements Converter {

	@Inject
	private ConfiguracoesEmpresas configuracoesEmpresas;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		ConfiguracaoEmpresa retorno = null;

		if (StringUtils.isNotEmpty(value)) {
			retorno = this.configuracoesEmpresas.porId(new Long(value));
		}

		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			ConfiguracaoEmpresa configuracaoEmpresa = (ConfiguracaoEmpresa) value; 
			return configuracaoEmpresa != null && configuracaoEmpresa.getId() != null ? configuracaoEmpresa.getId().toString() : null;
		}
		return "";
	}

}