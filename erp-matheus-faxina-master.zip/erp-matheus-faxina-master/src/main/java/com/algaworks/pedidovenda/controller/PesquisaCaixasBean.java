package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Caixa;
import com.algaworks.pedidovenda.repository.Caixas;
import com.algaworks.pedidovenda.repository.filter.CaixaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaCaixasBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private Caixas caixas;
	
	private CaixaFilter filtro;
	private List<Caixa> caixasFiltrados;
	
	private Caixa caixaSelecionado;
	
	public PesquisaCaixasBean() {
		filtro = new CaixaFilter();
	}
	
	public void pesquisar() {
		caixasFiltrados = caixas.filtrados(filtro);
	}
	
	public void excluir() {
		try {
			caixas.remover(caixaSelecionado);
			caixasFiltrados.remove(caixaSelecionado);
			
			FacesUtil.addInfoMessage("Caixa " + caixaSelecionado.getNome() + 
					" foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<Caixa> getCaixasFiltrados() {
		return caixasFiltrados;
	}

	public CaixaFilter getFiltro() {
		return filtro;
	}

	public Caixa getCaixaSelecionado() {
		return caixaSelecionado;
	}

	public void setCaixaSelecionado(Caixa caixaSelecionado) {
		this.caixaSelecionado = caixaSelecionado;
	}
	
}
