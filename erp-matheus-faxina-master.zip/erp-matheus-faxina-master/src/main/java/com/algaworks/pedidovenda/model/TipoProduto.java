package com.algaworks.pedidovenda.model;

public enum TipoProduto {

	PRODUTO("Produto"),
	KIT("Kit"),
	INSUMO("Insumo");
	
	private String descricao;
	
	TipoProduto(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}
	
}
