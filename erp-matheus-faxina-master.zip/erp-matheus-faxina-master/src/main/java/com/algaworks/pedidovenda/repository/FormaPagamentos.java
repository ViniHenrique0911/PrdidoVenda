package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.FormaPagamentoo;
import com.algaworks.pedidovenda.repository.filter.FormaPagamentoFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class FormaPagamentos implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public FormaPagamentoo porId(Long id) {
		return this.manager.find(FormaPagamentoo.class, id);
	}

	public List<FormaPagamentoo> porNome(String nome) {
		return this.manager.createQuery("from FormaPagamentoo " + "where upper(nome) like :nome", FormaPagamentoo.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<FormaPagamentoo> filtrados(FormaPagamentoFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<FormaPagamentoo> criteriaQuery = builder.createQuery(FormaPagamentoo.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<FormaPagamentoo> formaPagamentoRoot = criteriaQuery.from(FormaPagamentoo.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(builder.like(builder.lower(formaPagamentoRoot.get("nome")),
					"%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(formaPagamentoRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(formaPagamentoRoot.get("nome")));

		TypedQuery<FormaPagamentoo> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public FormaPagamentoo guardar(FormaPagamentoo formaPagamento) {
		return manager.merge(formaPagamento);
	}

	@Transactional
	public void remover(FormaPagamentoo formaPagamento) throws NegocioException {
		try {
			formaPagamento = porId(formaPagamento.getId());
			manager.remove(formaPagamento);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Forma de pagamento não pode ser excluído.");
		}
	}
}