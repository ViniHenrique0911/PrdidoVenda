package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.AberturaCaixa;
import com.algaworks.pedidovenda.repository.AberturaCaixas;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroAberturaCaixaService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private AberturaCaixas caixas;

	@Transactional
	public AberturaCaixa salvar(AberturaCaixa caixa) throws NegocioException {
		return caixas.guardar(caixa);
	}
}