package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.repository.Dashboards;

@Named
@ViewScoped
public class DashboardBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Dashboards dashboards;

	public void inicializar() {

	}

	public Long getProdutoBaixaEstoque() {
		return dashboards.getProdutosBaixaEstoque();
	}
	
	public Long getRoshAPreparar() {
		return dashboards.getRoshAPreparar();
	}

}
