package com.algaworks.pedidovenda.service;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.ContasPagar;
import com.algaworks.pedidovenda.model.FluxoCaixa;
import com.algaworks.pedidovenda.model.StatusContasPagar;
import com.algaworks.pedidovenda.model.StatusCompra;
import com.algaworks.pedidovenda.model.TipoFluxoCaixa;
import com.algaworks.pedidovenda.repository.ContasPagars;
import com.algaworks.pedidovenda.repository.FluxoCaixas;
import com.algaworks.pedidovenda.util.jpa.Transactional;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

public class CadastroContasPagarService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private ContasPagars contasPagars;
	
	@Inject
	private FluxoCaixas fluxoCaixas;
	
	@Transactional
	public ContasPagar salvarSemIf(ContasPagar contasPagar) throws NegocioException {
		return contasPagars.guardar(contasPagar);
	}
	
	@Transactional
	public ContasPagar salvar(ContasPagar contasPagar) throws NegocioException {

		BigDecimal valorPagar = contasPagar.getValorPagamento();
		BigDecimal valorReceber = contasPagar.getValorRecebimento();
		
		if (valorReceber.compareTo(valorPagar) < 0) {
			verificaValorRecebido(contasPagar, valorPagar, valorReceber);
		}
		
		if (valorPagar.compareTo(valorReceber) < 0) {
			throw new NegocioException("O valor a receber informado é maior que o valor a pagar.");
		}
		
		if (contasPagar.getCompra().getStatus() == StatusCompra.CANCELADO) {
			cancelar(contasPagar);
		}

		if (contasPagar.isCancelado()) {
			throw new NegocioException("Essa conta a receber foi cancelada.");
		}

		if (contasPagar.isRecebido()) {
			throw new NegocioException("Essa conta a receber já foi baixada.");
		}
		
		contasPagar.setStatus(StatusContasPagar.PAGO);
		
		FluxoCaixa fluxoCaixa = new FluxoCaixa();
		fluxoCaixa.setContasPagar(contasPagar);
		fluxoCaixa.setDataLancamento(contasPagar.getDataLancamento());
		fluxoCaixa.setTipoFluxoCaixa(TipoFluxoCaixa.CONTAS_RECEBER);
		fluxoCaixa.setValor(contasPagar.getValorRecebimento());
		fluxoCaixas.guardar(fluxoCaixa);
		
		return contasPagars.guardar(contasPagar);

	}

	private void verificaValorRecebido(ContasPagar contasPagar, BigDecimal valorPagar, BigDecimal valorReceber) {
		BigDecimal valorRestante;
		valorRestante = valorPagar.subtract(valorReceber);
		System.out.println(valorRestante);
		ContasPagar contasPagarNova = new ContasPagar();
		contasPagarNova.setCliente(contasPagar.getCliente());
		contasPagarNova.setDataLancamento(contasPagar.getDataLancamento());
		contasPagarNova.setDataPagamento(contasPagar.getDataPagamento());
		contasPagarNova.setDataVencimento(contasPagar.getDataVencimento());
		contasPagarNova.setNumeroParcela(contasPagar.getNumeroParcela());
		contasPagarNova.setCompra(contasPagar.getCompra());
		contasPagarNova.setStatus(StatusContasPagar.PAGO_PARCIALMENTE);
		contasPagarNova.setTipoContasPagar(contasPagar.getTipoContasPagar());
		contasPagarNova.setValorPagamento(valorRestante);
		contasPagarNova.setVendedor(contasPagar.getVendedor());
		FacesUtil.addInfoMessage("O valor recebido é menor que o valor a pagar, sendo assim, foi criado um novo contas a receber com o valor restante!");
		contasPagars.guardar(contasPagarNova);
	}

	@Transactional
	public ContasPagar cancelar(ContasPagar contasPagar) throws NegocioException {

		if (contasPagar.isReceber()) {
			contasPagar.setStatus(StatusContasPagar.CANCELADO);
			return contasPagars.guardar(contasPagar);
		} else {
			throw new NegocioException(
					"Essa conta a receber não pode ser cancelada pois já foi recebida ou já está cancelada.");
		}
	}

}