package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;

import com.algaworks.pedidovenda.model.Menu;
import com.algaworks.pedidovenda.repository.Menus;

@Named
@ViewScoped
public class MenuBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private MenuModel modeloDoMenu;
	
	@Inject
	private Menus menus;
	
	public MenuModel getModeloDoMenu() {
		return modeloDoMenu;
	}
	
	public void setModeloDoMenu(MenuModel modeloDoMenu) {
		this.modeloDoMenu = modeloDoMenu;
	}
	
	@PostConstruct
	public void iniciar(){
		List<Menu> listaMenu = menus.listarTodos();
		
		modeloDoMenu = new DefaultMenuModel();

		for (Menu menu : listaMenu) {
			if (menu.getCaminho() == null) {
				DefaultSubMenu subMenu =  new DefaultSubMenu(menu.getRotulo());
			
				for (Menu item : menus.menusFilhos()) {
					if (item.getMenu() != null) {
						DefaultMenuItem menuItem = new DefaultMenuItem(item.getRotulo());
						menuItem.setUrl(item.getCaminho());
						
						subMenu.addElement(menuItem);
					}
				}
				
				modeloDoMenu.addElement(subMenu);
			}
			/*if (menu.getCaminho() == null) {
				DefaultSubMenu subMenu = new DefaultSubMenu(menu.getRotulo());
				
				for (Menu item : menus.menusFilhos()){
					DefaultMenuItem menuItem = new DefaultMenuItem(item.getRotulo());
					menuItem.setUrl(item.getCaminho());
					
					subMenu.addElement(menuItem);
				}
				
				modeloDoMenu.addElement(subMenu);
			}*/
		}
	}

}
