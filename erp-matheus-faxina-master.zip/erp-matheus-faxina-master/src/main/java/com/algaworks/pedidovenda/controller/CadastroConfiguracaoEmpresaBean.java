package com.algaworks.pedidovenda.controller;

import java.io.IOException;
import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import com.algaworks.pedidovenda.model.ConfiguracaoEmpresa;
import com.algaworks.pedidovenda.repository.ConfiguracoesEmpresas;
import com.algaworks.pedidovenda.service.CadastroConfiguracaoEmpresaService;
import com.algaworks.pedidovenda.service.FotoEmpresaService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroConfiguracaoEmpresaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ConfiguracaoEmpresa configuracaoEmpresa;
	
	@Inject
	private CadastroConfiguracaoEmpresaService cadastroConfiguracaoEmpresaService;
	
	@Inject
	private FotoEmpresaService fotoService;
	
	@Inject
	private ConfiguracoesEmpresas configuracoesEmpresas;
	
	public void inicializar(){
		if (configuracaoEmpresa == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.configuracaoEmpresa = new ConfiguracaoEmpresa();
	}
	
	public void salvar() {
		try {
			cadastroConfiguracaoEmpresaService.salvar(configuracaoEmpresa);
			limpar();
			
			FacesUtil.addInfoMessage("Configuração da empresa foi salvo com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public void upload(FileUploadEvent event) {
		UploadedFile uploadedFile = event.getFile();

		try {
			fotoService.deletar(configuracaoEmpresa.getFoto());

			String foto = fotoService.salvarFotoTemp(uploadedFile.getFileName(), event.getFile().getContents());
			configuracaoEmpresa.setFoto(foto);
		} catch (Exception e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public void removerFoto() {
		try {
			fotoService.deletarTemp(configuracaoEmpresa.getFoto());
		} catch (IOException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}

		configuracaoEmpresa.setFoto(null);
	}
	
	public ConfiguracaoEmpresa getConfiguracaoEmpresa() {
		return configuracaoEmpresa;
	}
	
	public void setConfiguracaoEmpresa(ConfiguracaoEmpresa configuracaoEmpresa) {
		this.configuracaoEmpresa = configuracaoEmpresa;
	}
	
	public boolean isEditando() {
		return configuracaoEmpresa != null && configuracaoEmpresa.getId() == null;
	}

}
