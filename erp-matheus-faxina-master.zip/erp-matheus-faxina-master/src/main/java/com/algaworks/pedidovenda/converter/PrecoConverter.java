package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Cidade;
import com.algaworks.pedidovenda.model.Preco;
import com.algaworks.pedidovenda.repository.GrupoPrecos;

@FacesConverter(forClass = Preco.class)
public class PrecoConverter implements Converter {

	@Inject
	private GrupoPrecos grupoPrecos;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Preco retorno = null;
		
		if (StringUtils.isNotEmpty(value)) {
			Long id = new Long(value);
			retorno = grupoPrecos.porId(id);
		}
		
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			Preco cidade = (Preco) value;
			return cidade.getId() == null ? null : cidade.getId().toString();
		}
		
		return "";
	}

}
