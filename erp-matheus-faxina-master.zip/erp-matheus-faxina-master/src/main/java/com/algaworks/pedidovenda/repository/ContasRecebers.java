package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;

import com.algaworks.pedidovenda.model.AberturaCaixa;
import com.algaworks.pedidovenda.model.Cliente;
import com.algaworks.pedidovenda.model.ContasReceber;
import com.algaworks.pedidovenda.repository.filter.ContasReceberFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class ContasRecebers implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public ContasReceber porId(Long id) {
		return this.manager.find(ContasReceber.class, id);
	}

	public List<ContasReceber> contasRecebersVinculadas(Long id) {
		return this.manager.createQuery("from ContasReceber where pedido_id = :id", ContasReceber.class)
				.setParameter("id", id).getResultList();
	}
	
	public BigDecimal valorAReceber(Long id) {
		return this.manager.createQuery("select valorPagamento from ContasReceber where id = :id", BigDecimal.class).setParameter("id", id).getSingleResult();
	}
	
	public BigDecimal valorRecebido(Long id) {
		return this.manager.createQuery("select valorRecebimento from ContasReceber where id = :id", BigDecimal.class).setParameter("id", id).getSingleResult();
	}

	public List<ContasReceber> listar() {
		Session session = this.manager.unwrap(Session.class);

		Criteria criteria = session.createCriteria(ContasReceber.class);
		return criteria.list();
	}

	public List<ContasReceber> filtrados(ContasReceberFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<ContasReceber> criteriaQuery = builder.createQuery(ContasReceber.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<ContasReceber> caixaRoot = criteriaQuery.from(ContasReceber.class);

		if (StringUtils.isNotBlank(filtro.getNomeCliente())) {
			predicates.add(builder.like(builder.lower(caixaRoot.get("nome")),
					"%" + filtro.getNomeCliente().toLowerCase() + "%"));
		}

		criteriaQuery.select(caixaRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(caixaRoot.get("nome")));

		TypedQuery<ContasReceber> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	private List<Predicate> criarPredicatesParaFiltro(ContasReceberFilter filtro, Root<ContasReceber> pedidoRoot,
			From<?, ?> clienteJoin, From<?, ?> vendedorJoin) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		List<Predicate> predicates = new ArrayList<>();

		if (StringUtils.isNotBlank(filtro.getNomeCliente())) {
			predicates.add(builder.like(clienteJoin.get("nome"), "%" + filtro.getNomeCliente() + "%"));
		}

		if (filtro.getStatuses() != null && filtro.getStatuses().length > 0) {
			predicates.add(pedidoRoot.get("status").in(Arrays.asList(filtro.getStatuses())));
		}

		return predicates;
	}

	public int quantidadeFiltrados(ContasReceberFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);

		Root<ContasReceber> pedidoRoot = criteriaQuery.from(ContasReceber.class);
		Join<ContasReceber, Cliente> clienteJoin = pedidoRoot.join("cliente", JoinType.INNER);
		Join<ContasReceber, Cliente> vendedorJoin = pedidoRoot.join("vendedor", JoinType.INNER);

		List<Predicate> predicates = criarPredicatesParaFiltro(filtro, pedidoRoot, clienteJoin, vendedorJoin);

		criteriaQuery.select(builder.count(pedidoRoot));
		criteriaQuery.where(predicates.toArray(new Predicate[0]));

		TypedQuery<Long> query = manager.createQuery(criteriaQuery);

		return query.getSingleResult().intValue();
	}

	public ContasReceber guardar(ContasReceber contasReceber) {
		return manager.merge(contasReceber);
	}

	public List<AberturaCaixa> aberturaCaixas(Long id, String data) {
		return this.manager
				.createQuery("from AberturaCaixa where data_abertura = :data and usuario_id = :id", AberturaCaixa.class)
				.setParameter("data", data).setParameter("id", id).getResultList();
	}

	@Transactional
	public void remover(ContasReceber contasReceber) throws NegocioException {
		try {
			contasReceber = porId(contasReceber.getId());
			manager.remove(contasReceber);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Contas a receber não pode ser excluído.");
		}
	}

	public BigDecimal getTotalRecebido() {
		return (BigDecimal) manager
				.createQuery("select sum(cr.valorRecebimento) from ContasReceber cr where cr.status = 'RECEBIDO'")
				.getSingleResult();
	}

	public BigDecimal getTotalReceber() {
		return (BigDecimal) manager
				.createQuery("select sum(cr.valorPagamento) from ContasReceber cr where cr.status = 'A_RECEBER'")
				.getSingleResult();
	}

	public Long getTotalContasReceberRecebido() {
		return (Long) manager.createQuery("select count(cr.id) from ContasReceber cr where cr.status = 'RECEBIDO'")
				.getSingleResult();
	}

	public Long getTotalContasReceberReceber() {
		return (Long) manager.createQuery("select count(cr.id) from ContasReceber cr where cr.status = 'A_RECEBER'")
				.getSingleResult();
	}

}