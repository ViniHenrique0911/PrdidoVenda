package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Compra;
import com.algaworks.pedidovenda.model.ContasPagar;
import com.algaworks.pedidovenda.model.StatusCompra;
import com.algaworks.pedidovenda.repository.Compras;
import com.algaworks.pedidovenda.repository.ContasPagars;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CancelamentoCompraService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Compras compras;
	
	@Inject
	private EstoqueCompraService estoqueService;
	
	@Inject
	private ContasPagars contasRecebers;
		
	@Transactional
	public ContasPagar salvarSemIf(ContasPagar contasReceber) throws NegocioException {
		return contasRecebers.guardar(contasReceber);
	}
	
	@Transactional
	public Compra cancelar(Compra compra) throws NegocioException {
		compra = this.compras.porId(compra.getId());
		
		if (compra.isNaoCancelavel()) {
			throw new NegocioException("Compra não pode ser cancelado no status "
					+ compra.getStatus().getDescricao() + ".");
		}
		
		if (compra.isEmitido()) {
			this.estoqueService.retornarItensEstoque(compra);
		}
		
		compra.setStatus(StatusCompra.CANCELADO);
		
		compra = this.compras.guardar(compra);
		
		return compra;
	}
	
}