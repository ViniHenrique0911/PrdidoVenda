package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Marca;
import com.algaworks.pedidovenda.repository.filter.MarcaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Marcas implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Marca porId(Long id) {
		return this.manager.find(Marca.class, id);
	}

	public List<Marca> porNome(String nome) {
		return this.manager.createQuery("from Marca " + "where upper(nome) like :nome", Marca.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Marca> filtrados(MarcaFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Marca> criteriaQuery = builder.createQuery(Marca.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Marca> marcaRoot = criteriaQuery.from(Marca.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(marcaRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(marcaRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(marcaRoot.get("nome")));

		TypedQuery<Marca> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public Marca guardar(Marca marca) {
		return manager.merge(marca);
	}

	@Transactional
	public void remover(Marca marca) throws NegocioException {
		try {
			marca = porId(marca.getId());
			manager.remove(marca);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Marca não pode ser excluído.");
		}
	}

	public List<Marca> porMarca(String nome) {
		return this.manager.createQuery("from Marca where upper(nome) like :nome", Marca.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
}