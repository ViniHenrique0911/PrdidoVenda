package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.AjusteEstoque;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.repository.Produtos;
import com.algaworks.pedidovenda.service.CadastroAjusteEstoqueService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroAjusteEstoqueBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private AjusteEstoque ajusteEstoque;

	private List<Produto> listaProdutos;

	@Inject
	private CadastroAjusteEstoqueService cadastroAjusteEstoqueService;

	@Inject
	private Produtos produtos;

	public void salvar() throws Exception {
		try {
			this.ajusteEstoque.ajustarEstoque();
			this.cadastroAjusteEstoqueService.salvar(ajusteEstoque);
			FacesUtil.addInfoMessage("Ajuste de estoque foi salvo com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}

		this.limpar();
	}

	@PostConstruct
	public void inicializar() {
		if (ajusteEstoque == null) {
			limpar();
		}
		this.listaProdutos = produtos.buscarTodos();
	}

	public void limpar() {
		this.ajusteEstoque = new AjusteEstoque();
	}

	public AjusteEstoque getAjusteEstoque() {
		return ajusteEstoque;
	}

	public void setAjusteEstoque(AjusteEstoque ajusteEstoque) {
		this.ajusteEstoque = ajusteEstoque;
	}

	public List<Produto> getProdutos() {
		return listaProdutos;
	}

	public void setProdutos(List<Produto> listaProdutos) {
		this.listaProdutos = listaProdutos;
	}

	public void carregarEstoqueAntigo() {
		ajusteEstoque.setEstoqueAnterior(ajusteEstoque.getProduto().getQuantidadeEstoque());
	}

	public boolean isEditando() {
		return ajusteEstoque != null && ajusteEstoque.getId() == null;
	}

}
