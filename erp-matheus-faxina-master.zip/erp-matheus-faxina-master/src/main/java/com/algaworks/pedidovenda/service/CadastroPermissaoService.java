package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Permissao;
import com.algaworks.pedidovenda.repository.Permissoes;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroPermissaoService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Permissoes permissoes;
	
	@Transactional
	public Permissao salvar(Permissao permissao) throws NegocioException {
		return permissoes.guardar(permissao);
	}
}