package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Preparar;
import com.algaworks.pedidovenda.repository.Preparars;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroPrepararService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Preparars preparars;
	
	@Transactional
	public Preparar salvar(Preparar preparar) throws NegocioException {
		return preparars.guardar(preparar);
	}
}