package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Caixa;
import com.algaworks.pedidovenda.repository.Caixas;
import com.algaworks.pedidovenda.service.CadastroCaixaService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroCaixaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Caixa caixa;
	
	@Inject
	private Caixas caixas;
	
	@Inject
	private CadastroCaixaService cadastroCaixaService;
	
	public void inicializar(){
		if (caixa == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.caixa = new Caixa();
	}
	
	public void salvar() {
		try {
			cadastroCaixaService.salvar(caixa);
			limpar();
			
			FacesUtil.addInfoMessage("Caixa foi salvo com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public Caixa getCaixa() {
		return caixa;
	}
	
	public void setCaixa(Caixa caixa) {
		this.caixa = caixa;
	}
	
	public boolean isEditando() {
		return caixa != null && caixa.getId() == null;
	}
	
}
