package com.algaworks.pedidovenda.model.validation;

public interface FisicaGroup {

}
