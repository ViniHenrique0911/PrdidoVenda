package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Marca;
import com.algaworks.pedidovenda.repository.Marcas;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroMarcaService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Marcas marcas;
	
	@Transactional
	public Marca salvar(Marca marca) throws NegocioException {
		return marcas.guardar(marca);
	}
}