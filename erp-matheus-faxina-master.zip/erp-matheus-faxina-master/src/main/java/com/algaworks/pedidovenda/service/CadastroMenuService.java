package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Menu;
import com.algaworks.pedidovenda.repository.Menus;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroMenuService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Menus menus;
	
	@Transactional
	public Menu salvar(Menu menu) throws NegocioException {
		return menus.guardar(menu);
	}
}