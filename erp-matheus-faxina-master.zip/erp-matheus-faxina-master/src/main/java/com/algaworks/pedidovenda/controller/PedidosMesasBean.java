package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Mesa;
import com.algaworks.pedidovenda.repository.Pedidos;

@Named
@ViewScoped
public class PedidosMesasBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Pedidos pedidos;

	private List<Mesa> mesas;

	public void inicializar() {
		this.mesas = this.pedidos.porMesa();
	}

	public List<Mesa> getMesas() {
		return mesas;
	}

}