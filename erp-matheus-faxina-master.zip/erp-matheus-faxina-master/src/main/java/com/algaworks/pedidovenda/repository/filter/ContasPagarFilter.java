package com.algaworks.pedidovenda.repository.filter;

import java.io.Serializable;
import java.util.Date;

import com.algaworks.pedidovenda.model.StatusContasPagar;

public class ContasPagarFilter implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long numeroPedidoDe;
	private Long numeroPedidoAte;
	private Long numeroDevolucaoDe;
	private Long numeroDevolucaoAte;
	private Long numeroContasDe;
	private Long numeroContasAte;
	private Date dataLancamentoDe;
	private Date dataLancamentoAte;
	private Date dataPagamentoDe;
	private Date dataPagamentoAte;
	private String nomeCliente;
	private StatusContasPagar[] statuses;

	public Long getNumeroPedidoDe() {
		return numeroPedidoDe;
	}

	public void setNumeroPedidoDe(Long numeroPedidoDe) {
		this.numeroPedidoDe = numeroPedidoDe;
	}

	public Long getNumeroDevolucaoDe() {
		return numeroDevolucaoDe;
	}

	public void setNumeroDevolucaoDe(Long numeroDevolucaoDe) {
		this.numeroDevolucaoDe = numeroDevolucaoDe;
	}

	public Long getNumeroDevolucaoAte() {
		return numeroDevolucaoAte;
	}

	public void setNumeroDevolucaoAte(Long numeroDevolucaoAte) {
		this.numeroDevolucaoAte = numeroDevolucaoAte;
	}

	public Long getNumeroPedidoAte() {
		return numeroPedidoAte;
	}

	public void setNumeroPedidoAte(Long numeroPedidoAte) {
		this.numeroPedidoAte = numeroPedidoAte;
	}

	public Long getNumeroContasDe() {
		return numeroContasDe;
	}

	public void setNumeroContasDe(Long numeroContasDe) {
		this.numeroContasDe = numeroContasDe;
	}

	public Long getNumeroContasAte() {
		return numeroContasAte;
	}

	public void setNumeroContasAte(Long numeroContasAte) {
		this.numeroContasAte = numeroContasAte;
	}

	public Date getDataLancamentoDe() {
		return dataLancamentoDe;
	}

	public void setDataLancamentoDe(Date dataLancamentoDe) {
		this.dataLancamentoDe = dataLancamentoDe;
	}

	public Date getDataLancamentoAte() {
		return dataLancamentoAte;
	}

	public void setDataLancamentoAte(Date dataLancamentoAte) {
		this.dataLancamentoAte = dataLancamentoAte;
	}

	public Date getDataPagamentoDe() {
		return dataPagamentoDe;
	}

	public void setDataPagamentoDe(Date dataPagamentoDe) {
		this.dataPagamentoDe = dataPagamentoDe;
	}

	public Date getDataPagamentoAte() {
		return dataPagamentoAte;
	}

	public void setDataPagamentoAte(Date dataPagamentoAte) {
		this.dataPagamentoAte = dataPagamentoAte;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public StatusContasPagar[] getStatuses() {
		return statuses;
	}

	public void setStatuses(StatusContasPagar[] statuses) {
		this.statuses = statuses;
	}

}