package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Caixa;
import com.algaworks.pedidovenda.repository.Caixas;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroCaixaService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Caixas caixas;
	
	@Transactional
	public Caixa salvar(Caixa caixa) throws NegocioException {
		return caixas.guardar(caixa);
	}
}