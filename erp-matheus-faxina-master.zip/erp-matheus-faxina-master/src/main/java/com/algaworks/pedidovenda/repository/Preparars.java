package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import com.algaworks.pedidovenda.model.Preparar;
import com.algaworks.pedidovenda.repository.filter.PrepararFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Preparars implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Preparar porId(Long id) {
		return this.manager.find(Preparar.class, id);
	}

	public List<Preparar> porNome(String nome) {
		return this.manager.createQuery("from Preparar " + "where upper(nome) like :nome", Preparar.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Preparar> filtrados(PrepararFilter filtro) {
		return manager.createQuery("from Preparar where preparado = 0", Preparar.class).getResultList();
	}

	public List<Preparar> preparados(PrepararFilter filtro) {
		return manager.createQuery("from Preparar where preparado = 1 and entregue = 0", Preparar.class).getResultList();
	}

	public List<Preparar> entregues(PrepararFilter filtro) {
		return manager.createQuery("from Preparar where entregue = 1", Preparar.class).getResultList();
	}

	public Preparar guardar(Preparar preparar) {
		return manager.merge(preparar);
	}
	
	public Preparar entregar(Preparar preparar) {
		preparar.setEntregue(true);
		return manager.merge(preparar);
	}

	@Transactional
	public void remover(Preparar preparar) throws NegocioException {
		try {
			preparar = porId(preparar.getId());
			manager.remove(preparar);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Preparar não pode ser excluído.");
		}
	}
}