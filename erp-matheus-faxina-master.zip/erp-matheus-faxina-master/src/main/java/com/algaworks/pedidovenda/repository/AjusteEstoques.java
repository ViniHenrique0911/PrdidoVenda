package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.AjusteEstoque;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.repository.filter.AjusteEstoqueFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class AjusteEstoques implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public AjusteEstoque porId(Long id) {
		return this.manager.find(AjusteEstoque.class, id);
	}

	public List<AjusteEstoque> porNome(String nome) {
		return this.manager.createQuery("from AjusteEstoque " + "where upper(nome) like :nome", AjusteEstoque.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<AjusteEstoque> filtrados(AjusteEstoqueFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<AjusteEstoque> criteriaQuery = builder.createQuery(AjusteEstoque.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<AjusteEstoque> AjusteEstoqueRoot = criteriaQuery.from(AjusteEstoque.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(AjusteEstoqueRoot.get("motivo")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(AjusteEstoqueRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(AjusteEstoqueRoot.get("motivo")));

		TypedQuery<AjusteEstoque> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public AjusteEstoque guardar(AjusteEstoque AjusteEstoque) {
		return manager.merge(AjusteEstoque);
	}

	@Transactional
	public void remover(AjusteEstoque AjusteEstoque) throws NegocioException {
		try {
			AjusteEstoque = porId(AjusteEstoque.getId());
			manager.remove(AjusteEstoque);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Ajuste de estoque não pode ser excluído.");
		}
	}

	public List<Produto> porProduto(String nome) {
		return this.manager.createQuery("from Produto where upper(nome) like :nome", Produto.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
	
}