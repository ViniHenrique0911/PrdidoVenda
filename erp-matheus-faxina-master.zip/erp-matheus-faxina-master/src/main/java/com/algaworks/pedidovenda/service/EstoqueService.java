package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.ItemPedido;
import com.algaworks.pedidovenda.model.Pedido;
import com.algaworks.pedidovenda.repository.Pedidos;
import com.algaworks.pedidovenda.security.UsuarioLogado;
import com.algaworks.pedidovenda.security.UsuarioSistema;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class EstoqueService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Pedidos pedidos;

	@Inject
	@UsuarioLogado
	private UsuarioSistema usuarioSistema;

	private String skuCarvao;
	private String skuAluminio;

	public String carvao() {
		return this.skuCarvao = pedidos.pegaSkuCarvao();
	}

	public String aluminio() {
		return this.skuAluminio = pedidos.pegaSkuAluminio();
	}

	@Transactional
	public void baixarItensEstoque(Pedido pedido) throws NegocioException {
		carvao();
		aluminio();
		pedido = this.pedidos.porId(pedido.getId());

		for (ItemPedido item : pedido.getItens()) {
			if (item.getGrupoPreco().getBaixavel() == true) {
				item.getProduto()
						.baixarEstoque(new Float(item.getQuantidade() * item.getGrupoPreco().getQuantidadeBaixavel()));
				if (item.getGrupoPreco().getBaixarAluminio() == true) {
					pedidos.recuperaCarvao(this.skuCarvao)
							.baixarEstoque(item.getQuantidade() * item.getGrupoPreco().getBaixarCarvaoValor());
				}

				if (item.getGrupoPreco().getBaixarCarvao() == true) {
					pedidos.recuperaAluminio(this.skuAluminio)
							.baixarEstoque(item.getQuantidade() * item.getGrupoPreco().getBaixarAluminioValor());
				}
			}
		}
	}

	public void retornarItensEstoque(Pedido pedido) {
		carvao();
		aluminio();
		pedido = this.pedidos.porId(pedido.getId());

		for (ItemPedido item : pedido.getItens()) {
			if (item.getGrupoPreco().getBaixavel() == true) {
				item.getProduto().adicionarEstoque(
						new Float(item.getQuantidade() * item.getGrupoPreco().getQuantidadeBaixavel()));

				if (item.getGrupoPreco().getBaixarAluminio() == true) {
					pedidos.recuperaCarvao(this.skuCarvao)
							.adicionarEstoque(item.getQuantidade() * item.getGrupoPreco().getBaixarCarvaoValor());
				}

				if (item.getGrupoPreco().getBaixarCarvao() == true) {
					pedidos.recuperaAluminio(this.skuAluminio)
							.adicionarEstoque(item.getQuantidade() * item.getGrupoPreco().getBaixarAluminioValor());
				}

			}
		}
	}

}
