package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.service.CadastroEstadoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroEstadoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Estado estado;
	
	@Inject
	private CadastroEstadoService cadastroEstadoService;
	
	public void inicializar(){
		if (estado == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.estado = new Estado();
	}
	
	public void salvar() {
		try {
			cadastroEstadoService.salvar(estado);
			limpar();
			
			FacesUtil.addInfoMessage("Estado foi salvo com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public Estado getEstado() {
		return estado;
	}
	
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	
	public boolean isEditando() {
		return estado != null && estado.getId() == null;
	}
	
}
