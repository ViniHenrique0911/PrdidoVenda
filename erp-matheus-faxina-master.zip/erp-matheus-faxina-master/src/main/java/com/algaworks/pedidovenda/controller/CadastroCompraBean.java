package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.deltaspike.core.api.scope.ViewAccessScoped;
import org.hibernate.validator.constraints.NotBlank;
import org.primefaces.event.SelectEvent;

import com.algaworks.pedidovenda.model.Categoria;
import com.algaworks.pedidovenda.model.Cliente;
import com.algaworks.pedidovenda.model.EnderecoEntrega;
import com.algaworks.pedidovenda.model.EnderecoEntregaCompra;
import com.algaworks.pedidovenda.model.FormaPagamentoo;
import com.algaworks.pedidovenda.model.ItemCompra;
import com.algaworks.pedidovenda.model.Mesa;
import com.algaworks.pedidovenda.model.Parcela;
import com.algaworks.pedidovenda.model.Compra;
import com.algaworks.pedidovenda.model.Preco;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.model.SubCategoria;
import com.algaworks.pedidovenda.model.UnidadeMedidaProduto;
import com.algaworks.pedidovenda.repository.Clientes;
import com.algaworks.pedidovenda.repository.Mesas;
import com.algaworks.pedidovenda.repository.Parcelas;
import com.algaworks.pedidovenda.repository.Compras;
import com.algaworks.pedidovenda.repository.Produtos;
import com.algaworks.pedidovenda.service.CadastroCompraService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;
import com.algaworks.pedidovenda.validation.SKU;

@Named
@ViewAccessScoped
public class CadastroCompraBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Parcelas parcelas;

	@Inject
	private Clientes clientes;

	@Inject
	private Produtos produtos;

	@Inject
	private CadastroCompraService cadastroCompraService;

	private String sku;

	private String nome;

	@Produces
	@CompraEdicao
	private Compra compra;

	@Inject
	private Mesas mesass;

	@Inject
	private Compras compras;

	private List<Parcela> listParcelas;
	private List<FormaPagamentoo> listFormaPagamentos;
	private List<Mesa> mesas;
	private List<Cliente> listClientes;

	private Produto produtoLinhaEditavel;

	private boolean campoAtivo;

	private BigDecimal novoValor;

	private Mesa mesaSelecionada;

	private List<Categoria> categorias;
	private List<SubCategoria> subCategorias;
	private List<Produto> listaProdutos;

	private Preco grupoPreco;

	private ItemCompra itemCompra = new ItemCompra();

	public String tipoMesa(Mesa mesa) {
        if (!mesa.isOcupada()) {
            return "mesa-livre.png";
        }
        return "mesa-ocupada.png";
    }

	
	public void pegaProduto(Produto produto) {
		itemCompra.setProduto(produto);
		itemCompra.setCompra(this.compra);
		itemCompra.setGrupoPreco(produto.getGrupoPreco().get(0));

		compra.getItens().add(itemCompra);
		this.compra.recalcularValorTotal();
	}

	public List<Categoria> listCategorias() {
		return this.categorias = compras.todasCategorias();
	}

	public List<SubCategoria> buscarSubCategorias(Categoria categoria) {
		return this.subCategorias = compras.todasSubCategoriasPorCategoria(categoria.getId());
	}

	public List<Produto> buscarProdutosPorSubCategorias(SubCategoria subCategoria) {
		return this.listaProdutos = compras.todosProdutos(subCategoria.getId());
	}

	public CadastroCompraBean() {
		limpar();
	}

	public List<Mesa> inicializaMesa() {
		return compras.todasMesas();
	}

	public boolean liberaMesaCompra(Mesa mesa) {
		if (mesa.isOcupada() == true) {
			return false;
		} else {
			return true;
		}
	}

	public boolean liberaMesaMesa(Mesa mesa) {
		if (mesa.isOcupada() == true) {
			return true;
		} else {
			return false;
		}
	}

	public void liberarMesa() {
		try {
			mesaSelecionada.setOcupada(false);
			mesass.guardar(mesaSelecionada);
			FacesUtil.addInfoMessage("A mesa " + mesaSelecionada.getNome() + " foi atualizada com sucesso!");
		} catch (Exception e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public void novoCompra(Mesa m) {
		compra = new Compra();
		inicializar();
	}

	public List<Preco> completarGrupoPreco(Produto produto) {
		return this.produtos.porGrupoPreco(produto.getId());
	}

	public void inicializarCompra() {
		this.listFormaPagamentos = this.compras.porFormaPagamento();
		this.mesas = this.compras.porMesa();

		this.recalcularCompra();

	}

	public void inicializar() {
		if (this.compra == null) {
			limpar();
		}

		this.listFormaPagamentos = this.compras.porFormaPagamento();
		this.mesas = this.compras.porMesa();

		this.compra.adicionarItemVazio();

		this.recalcularCompra();
		System.out.println("Método inicializar: " + compra.getItens());
	}

	public void clienteSelecionado(SelectEvent event) {
		compra.setCliente((Cliente) event.getObject());
	}

	private void limpar() {
		compra = new Compra();
		compra.setEnderecoEntrega(new EnderecoEntregaCompra());
	}

	public void compraAlterado(@Observes CompraAlteradoEvent event) {
		this.compra = event.getCompra();
	}

	public void salvar() {
		this.compra.removerItemVazio();

		try {
			this.compra = this.cadastroCompraService.salvar(this.compra);
			FacesUtil.addInfoMessage("Compra foi salvo com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		} finally {
			this.compra.adicionarItemVazio();
		}
	}

	public void pegaFormaPagamento() {
		listParcelas = compras.porParcelaFiltradaPorFormaPagamento(compra.getFormaPagamento().getId());
	}

	public void recalcularCompra() {
		if (this.compra != null) {
			this.compra.recalcularValorTotal();
		}
	}

	public void carregarProdutoPorSku() {
		if (StringUtils.isNotEmpty(this.sku)) {
			this.produtoLinhaEditavel = this.produtos.porSku(this.sku);
			this.carregarProdutoLinhaEditavel();
		}
	}

	public void pegaGrupoPreco(BigDecimal valor) {
		this.compra.recalcularValorTotal();
	}

	public BigDecimal recuperaValor(BigDecimal valor) {
		return valor;
	}

	public void carregarProdutoLinhaEditavel() {
		ItemCompra item = this.compra.getItens().get(0);

		if (this.produtoLinhaEditavel != null) {
			if (this.existeItemComProduto(this.produtoLinhaEditavel)) {
				FacesUtil.addErrorMessage("Já existe um item no compra com o produto informado.");
			} else {
				item.setProduto(this.produtoLinhaEditavel);
				this.compra.adicionarItemVazio();
				this.produtoLinhaEditavel = null;
				this.sku = null;
				this.compra.recalcularValorTotal();
			}
		}
	}

	private boolean existeItemComProduto(Produto produto) {
		boolean existeItem = false;

		for (ItemCompra item : this.getCompra().getItens()) {
			if (produto.equals(item.getProduto())) {
				existeItem = true;
				break;
			}
		}

		return existeItem;
	}

	public List<Produto> completarProduto(String nome) {
		return this.produtos.porNome(nome);
	}

	public void atualizarQuantidade(ItemCompra item, int linha) {
		if (item.getQuantidade() < 1.0) {
			if (linha == 0.0) {
				item.setQuantidade(new Float(1.0));
			} else {
				this.getCompra().getItens().remove(linha);
			}
		}

		this.compra.recalcularValorTotal();
	}

	public void removerProduto(float linha) {
		this.getCompra().getItens().remove(linha);
	}

	public UnidadeMedidaProduto[] getUnidadesMedida() {
		return UnidadeMedidaProduto.values();
	}

	public List<Cliente> completarCliente(String nome) {
		return this.clientes.porNomeJuridica(nome);
	}

	public Compra getCompra() {
		return compra;
	}

	public void setCompra(Compra compra) {
		this.compra = compra;
	}

	public List<Parcela> getListParcelas() {
		return listParcelas;
	}

	public boolean isEditando() {
		return this.compra.getId() != null;
	}

	public Produto getProdutoLinhaEditavel() {
		return produtoLinhaEditavel;
	}

	public void setProdutoLinhaEditavel(Produto produtoLinhaEditavel) {
		this.produtoLinhaEditavel = produtoLinhaEditavel;
	}

	@SKU
	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	@NotBlank
	public String getNomeCliente() {
		return compra.getCliente() == null ? null : compra.getCliente().getNome();
	}

	public void setNomeCliente(String nome) {
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public boolean isCampoAtivo() {
		return campoAtivo;
	}

	public void setCampoAtivo(boolean campoAtivo) {
		this.campoAtivo = campoAtivo;
	}

	public BigDecimal getNovoValor() {
		return novoValor;
	}

	public void setNovoValor(BigDecimal novoValor) {
		this.novoValor = novoValor;
	}

	public Parcelas getParcelas() {
		return parcelas;
	}

	public void setParcelas(Parcelas parcelas) {
		this.parcelas = parcelas;
	}

	public List<FormaPagamentoo> getListFormaPagamentos() {
		return listFormaPagamentos;
	}

	public void setListFormaPagamentos(List<FormaPagamentoo> listFormaPagamentos) {
		this.listFormaPagamentos = listFormaPagamentos;
	}

	public void setListParcelas(List<Parcela> listParcelas) {
		this.listParcelas = listParcelas;
	}

	public List<Mesa> getMesas() {
		return mesas;
	}

	public void setMesas(List<Mesa> mesas) {
		this.mesas = mesas;
	}

	public List<Cliente> getListClientes() {
		return listClientes;
	}

	public Mesa getMesaSelecionada() {
		return mesaSelecionada;
	}

	public List<SubCategoria> getSubCategorias() {
		return subCategorias;
	}

	public List<Produto> getListaProdutos() {
		return listaProdutos;
	}

	public Preco getGrupoPreco() {
		return grupoPreco;
	}

	public ItemCompra getItemCompra() {
		return itemCompra;
	}

}