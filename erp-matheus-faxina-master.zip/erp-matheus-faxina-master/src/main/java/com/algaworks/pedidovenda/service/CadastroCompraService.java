package com.algaworks.pedidovenda.service;

import java.io.Serializable;
import java.util.Date;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Compra;
import com.algaworks.pedidovenda.model.StatusCompra;
import com.algaworks.pedidovenda.repository.Compras;
import com.algaworks.pedidovenda.security.UsuarioLogado;
import com.algaworks.pedidovenda.security.UsuarioSistema;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroCompraService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Compras compras;
	
	@Inject
	@UsuarioLogado
	private UsuarioSistema usuarioLogado;
	
	@Transactional
	public Compra salvar(Compra compra) throws NegocioException {
		if (compra.isNovo()) {
			compra.setDataCriacao(new Date());
			compra.setStatus(StatusCompra.ORCAMENTO);
		}
		
		compra.recalcularValorTotal();
		
		if (compra.isNaoAlteravel()) {
			throw new NegocioException("Compra não pode ser alterado no status "
					+ compra.getStatus().getDescricao() + ".");
		}
		
		if (compra.getItens().isEmpty()) {
			throw new NegocioException("O compra deve possuir pelo menos um item.");
		}
		
		if (compra.isValorTotalNegativo()) {
			throw new NegocioException("Valor total do compra não pode ser negativo.");
		}
		
		compra.setVendedor(usuarioLogado.getUsuario());
		compra = this.compras.guardar(compra);
		return compra;
	}
	
}
