package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Grupo;
import com.algaworks.pedidovenda.repository.Grupoos;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroGrupoService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Grupoos grupos;

	@Transactional
	public Grupo salvar(Grupo grupo) throws NegocioException {
		Grupo grupoExistente = grupos.porSku(grupo.getNome());

		if (grupoExistente != null && !grupoExistente.equals(grupo)) {
			throw new NegocioException("Já existe um grupo com o SKU informado.");
		}

		return grupos.guardar(grupo);
	}
}
