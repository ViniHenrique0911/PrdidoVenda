package com.algaworks.pedidovenda.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.validation.SKU;

@Entity
@Table(name = "produto")
public class Produto implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank
	@Size(max = 80)
	@Column(nullable = false, length = 80)
	private String nome;

	@NotBlank(message = "Por favor, informe o SKU")
	@SKU(message = "Por favor, informe um SKU no formato XX9999")
	@Column(nullable = false, length = 20, unique = true)
	private String sku;

	@Column(name = "valor_unitario", precision = 10, scale = 2)
	private BigDecimal valorUnitario;

	@NotNull
	@Column(name = "quantidade_estoque", nullable = false)
	private Float quantidadeEstoque;

	@NotNull
	@ManyToOne
	@JoinColumn(name = "sub_categoria_id", nullable = false)
	private SubCategoria subCategoria;

	private String foto;

	@Column(name = "codigo_barras", nullable = false)
	private String codigoBarras;

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(nullable = false, length = 20)
	private TipoProduto tipoProduto;

	@NotNull
	@ManyToOne
	@JoinColumn(name = "cliente_id", nullable = false)
	private Marca marca;

	@OneToMany(mappedBy = "produto", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private List<Preco> grupoPreco = new ArrayList<>();

	private Boolean ativo = true;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku == null ? null : sku.toUpperCase();
	}

	public BigDecimal getValorUnitario() {
		return valorUnitario;
	}

	public void setValorUnitario(BigDecimal valorUnitario) {
		this.valorUnitario = valorUnitario;
	}

	public Float getQuantidadeEstoque() {
		return quantidadeEstoque;
	}

	public void setQuantidadeEstoque(Float quantidadeEstoque) {
		this.quantidadeEstoque = quantidadeEstoque;
	}

	public SubCategoria getSubCategoria() {
		return subCategoria;
	}

	public void setSubCategoria(SubCategoria subCategoria) {
		this.subCategoria = subCategoria;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

	public TipoProduto getTipoProduto() {
		return tipoProduto;
	}

	public void setTipoProduto(TipoProduto tipoProduto) {
		this.tipoProduto = tipoProduto;
	}

	public Marca getMarca() {
		return marca;
	}

	public void setMarca(Marca marca) {
		this.marca = marca;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	public List<Preco> getGrupoPreco() {
		return grupoPreco;
	}

	public void setGrupoPreco(List<Preco> grupoPreco) {
		this.grupoPreco = grupoPreco;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Produto other = (Produto) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public void baixarEstoque(Float quantidade) throws NegocioException {
		Float novaQuantidade = this.getQuantidadeEstoque() - quantidade;

		if (novaQuantidade < 0) {
			throw new NegocioException(
					"Não há disponibilidade no estoque de " + quantidade + " itens do produto " + this.getSku() + ".");
		}

		this.setQuantidadeEstoque(novaQuantidade);

	}

	public void aumentarEstoque(Float quantidade) throws NegocioException {
		Float novaQuantidade = this.getQuantidadeEstoque() + quantidade;

		if (novaQuantidade < 0) {
			throw new NegocioException(
					"Não há disponibilidade no estoque de " + quantidade + " itens do produto " + this.getSku() + ".");
		}

		this.setQuantidadeEstoque(novaQuantidade);
	}

	public void ajusteEstoque(Float novoEstoque) {
		setQuantidadeEstoque(novoEstoque);
	}

	public void adicionarEstoque(Float quantidade) {
		this.setQuantidadeEstoque(getQuantidadeEstoque() + quantidade);
	}

	public void retornarEstoque(Float quantidade) {
		this.setQuantidadeEstoque(getQuantidadeEstoque() - quantidade);
	}

}