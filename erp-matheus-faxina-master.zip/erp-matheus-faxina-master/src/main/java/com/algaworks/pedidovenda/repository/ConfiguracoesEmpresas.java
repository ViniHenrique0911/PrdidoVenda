package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.algaworks.pedidovenda.model.ConfiguracaoEmpresa;
import com.algaworks.pedidovenda.repository.filter.ConfiguracaoEmpresaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class ConfiguracoesEmpresas implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public ConfiguracaoEmpresa porId(Long id) {
		return this.manager.find(ConfiguracaoEmpresa.class, id);
	}

	public ConfiguracaoEmpresa pegaId1() {
		return this.manager.find(ConfiguracaoEmpresa.class, 1L);
	}

	public ConfiguracaoEmpresa configuracaoEmpresaIdUm() {
		return (ConfiguracaoEmpresa) this.manager
				.createQuery("from ConfiguracaoEmpresa where id = 1", ConfiguracaoEmpresa.class).getResultList();
	}

	public List<ConfiguracaoEmpresa> porEmpresa(String nome) {
		return this.manager
				.createQuery("from ConfiguracaoEmpresa where upper(razaoSocial) like :razaoSocial",
						ConfiguracaoEmpresa.class)
				.setParameter("razaoSocial", nome.toUpperCase() + "%").getResultList();
	}

	public List<ConfiguracaoEmpresa> configuracaoEmpresas() {
		return this.manager.createQuery("from ConfiguracaoEmpresa", ConfiguracaoEmpresa.class).getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<ConfiguracaoEmpresa> filtrados(ConfiguracaoEmpresaFilter filtro) {
		Session session = manager.unwrap(Session.class);
		Criteria criteria = session.createCriteria(ConfiguracaoEmpresa.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			criteria.add(Restrictions.ilike("razaoSocial", filtro.getNome(), MatchMode.ANYWHERE));
		}

		return criteria.addOrder(Order.asc("razaoSocial")).list();
	}

	public ConfiguracaoEmpresa guardar(ConfiguracaoEmpresa configuracaoEmpresa) {
		return manager.merge(configuracaoEmpresa);
	}

	@Transactional
	public void remover(ConfiguracaoEmpresa configuracaoEmpresa) throws NegocioException {
		try {
			configuracaoEmpresa = porId(configuracaoEmpresa.getId());
			manager.remove(configuracaoEmpresa);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Configuraçao da empresa não pode ser excluído.");
		}
	}
}