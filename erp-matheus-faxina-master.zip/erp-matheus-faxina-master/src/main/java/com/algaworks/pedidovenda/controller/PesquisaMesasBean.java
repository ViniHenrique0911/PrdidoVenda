package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Mesa;
import com.algaworks.pedidovenda.repository.Mesas;
import com.algaworks.pedidovenda.repository.filter.MesaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaMesasBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private Mesas mesas;
	
	private MesaFilter filtro;
	private List<Mesa> mesasFiltrados;
	
	private Mesa mesaSelecionado;
	
	public PesquisaMesasBean() {
		filtro = new MesaFilter();
	}
	
	public void pesquisar() {
		mesasFiltrados = mesas.filtrados(filtro);
	}
	
	public void excluir() {
		try {
			mesas.remover(mesaSelecionado);
			mesasFiltrados.remove(mesaSelecionado);
			
			FacesUtil.addInfoMessage("Mesa " + mesaSelecionado.getNome() + 
					" foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<Mesa> getMesasFiltrados() {
		return mesasFiltrados;
	}

	public MesaFilter getFiltro() {
		return filtro;
	}

	public Mesa getMesaSelecionado() {
		return mesaSelecionado;
	}

	public void setMesaSelecionado(Mesa mesaSelecionado) {
		this.mesaSelecionado = mesaSelecionado;
	}
	
}
