package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Marca;
import com.algaworks.pedidovenda.repository.Marcas;
import com.algaworks.pedidovenda.repository.filter.MarcaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaMarcasBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private Marcas marcas;
	
	private MarcaFilter filtro;
	private List<Marca> marcasFiltrados;
	
	private Marca marcaSelecionado;
	
	public PesquisaMarcasBean() {
		filtro = new MarcaFilter();
	}
	
	public void pesquisar() {
		marcasFiltrados = marcas.filtrados(filtro);
	}
	
	public void excluir() {
		try {
			marcas.remover(marcaSelecionado);
			marcasFiltrados.remove(marcaSelecionado);
			
			FacesUtil.addInfoMessage("Marca " + marcaSelecionado.getNome() + 
					" foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<Marca> getMarcasFiltrados() {
		return marcasFiltrados;
	}

	public MarcaFilter getFiltro() {
		return filtro;
	}

	public Marca getMarcaSelecionado() {
		return marcaSelecionado;
	}

	public void setMarcaSelecionado(Marca marcaSelecionado) {
		this.marcaSelecionado = marcaSelecionado;
	}
	
}
