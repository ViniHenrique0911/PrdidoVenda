package com.algaworks.pedidovenda.util.report;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.hibernate.jdbc.Work;

import com.algaworks.pedidovenda.model.Produto;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;

public class ExecutorEtiquetaRelatorio implements Work {

	private String caminhoRelatorio;

	private List<Produto> produtos;

	private boolean relatorioGerado;

	public ExecutorEtiquetaRelatorio(String caminhoRelatorio, List<Produto> produtos) {
		this.caminhoRelatorio = caminhoRelatorio;
		this.produtos = produtos;
	}

	@Override
	public void execute(Connection connection) throws SQLException {
		try {
			InputStream relatorioStream = this.getClass().getResourceAsStream(this.caminhoRelatorio);
			JasperPrint print = JasperFillManager.fillReport(relatorioStream, (Map<String, Object>) produtos, connection);
			JasperReport relatorio = JasperCompileManager.compileReport(this.caminhoRelatorio);
			JRBeanCollectionDataSource dados = new JRBeanCollectionDataSource(produtos, false);
			JasperViewer view = new JasperViewer(print, false);
			view.setVisible(true);
		} catch (

		Exception e) {
			throw new SQLException("Erro ao executar relatório " + this.caminhoRelatorio, e);
		}
	}

	public boolean isRelatorioGerado() {
		return relatorioGerado;
	}

}
