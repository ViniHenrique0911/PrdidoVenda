package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import com.algaworks.pedidovenda.repository.AbstractRepository;

public class ConverterGenerico implements Converter {

	private final AbstractRepository abstractRepository;

    public ConverterGenerico(AbstractRepository abstractRepository) {
        this.abstractRepository = abstractRepository;
    }

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        return abstractRepository.pesquisarId(Long.valueOf(value));
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        return value.toString();
    }
	
}
