package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Cidade;
import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.repository.filter.CidadeFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Cidades implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Cidade porId(Long id) {
		return this.manager.find(Cidade.class, id);
	}

	public List<Cidade> porNome(String nome) {
		return this.manager.createQuery("from Cidade " + "where upper(nome) like :nome", Cidade.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Cidade> filtrados(CidadeFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Cidade> criteriaQuery = builder.createQuery(Cidade.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Cidade> cidadeRoot = criteriaQuery.from(Cidade.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(cidadeRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(cidadeRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(cidadeRoot.get("nome")));

		TypedQuery<Cidade> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public Cidade guardar(Cidade cidade) {
		return manager.merge(cidade);
	}

	@Transactional
	public void remover(Cidade cidade) throws NegocioException {
		try {
			cidade = porId(cidade.getId());
			manager.remove(cidade);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Cidade não pode ser excluído.");
		}
	}

	public List<Estado> porEstado() {
		return this.manager.createQuery("from Estado", Estado.class).getResultList();
	}
}