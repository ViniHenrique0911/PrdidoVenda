package com.algaworks.pedidovenda.controller;

import java.io.OutputStream;
import java.io.Serializable;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletResponse;

import com.algaworks.pedidovenda.boleto.EmissorBoleto;
import com.algaworks.pedidovenda.model.Boleto;
import com.algaworks.pedidovenda.model.ContasPagar;
import com.algaworks.pedidovenda.model.StatusContasPagar;
import com.algaworks.pedidovenda.repository.Boletos;
import com.algaworks.pedidovenda.repository.ContasPagars;
import com.algaworks.pedidovenda.repository.filter.ContasPagarFilter;
import com.algaworks.pedidovenda.service.CadastroContasPagarService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaContasPagarsBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private ContasPagars contasPagars;

	@Inject
	private CadastroContasPagarService cadastroContasPagarService;

	@Inject
	private EmissorBoleto emissorBoleto;

	@Inject
	private Boletos boletos;

	private ContasPagar contasPagar;

	private ContasPagarFilter filtro;
	private List<ContasPagar> contasPagarsFiltrados;

	private ContasPagar contasPagarSelecionado;

	public String recuperaCor(String descricao) {
		if (descricao.equals("Recebido")) {
			return "color: blue";
		} 
		if (descricao.equals("A Receber")) {
			return "color: yellow";
		} else {
			return "color: red";
		}
	}
	
	public boolean desabilitarBotaoBoleto(String descricao) {
		if (descricao.equals("Cancelado")) {
			return true;
		}
		
		if (descricao.equals("Recebido")) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean desabilitarBotaoBaixar(String descricao) {
		if (descricao.equals("Recebido")) {
			return true;
		}
		
		if (descricao.equals("Cancelado")) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean desabilitarBotaoCancelar(String descricao) {
		if (descricao.equals("Recebido")) {
			return true;
		}
		
		if (descricao.equals("Cancelado")) {
			return true;
		} else {
			return false;
		}
	}

	public PesquisaContasPagarsBean() {
		filtro = new ContasPagarFilter();
	}

	public void pesquisar() {
		contasPagarsFiltrados = contasPagars.listar();
	}

	private void enviarBoleto(byte[] pdf) {
		HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext()
				.getResponse();

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition",
				"attachment; filename=boleto " + contasPagarSelecionado.getCliente().getNome() + ".pdf");

		try {
			OutputStream output = response.getOutputStream();
			output.write(pdf);
			response.flushBuffer();
		} catch (Exception e) {
			throw new RuntimeException("Erro gerando boleto", e);
		}

		FacesContext.getCurrentInstance().responseComplete();
	}

	public void cancelar() {
		try {
			if (contasPagarSelecionado.isNaoCancelavel()) {
				cadastroContasPagarService.cancelar(contasPagarSelecionado);
				FacesUtil.addInfoMessage("Contas a receber foi cancelada com sucesso!");
			}
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public void excluir() {
		try {
			contasPagars.remover(contasPagarSelecionado);
			contasPagarsFiltrados.remove(contasPagarSelecionado);

			FacesUtil.addInfoMessage("Contas a pagar do cliente " + contasPagarSelecionado.getCliente().getNome() + " foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public StatusContasPagar[] getStatuses() {
		return StatusContasPagar.values();
	}

	public List<ContasPagar> getContasPagarsFiltrados() {
		return contasPagarsFiltrados;
	}

	public ContasPagarFilter getFiltro() {
		return filtro;
	}

	public ContasPagar getContasPagarSelecionado() {
		return contasPagarSelecionado;
	}

	public ContasPagar getContasPagar() {
		return contasPagar;
	}

	public void setContasPagarSelecionado(ContasPagar contasPagarSelecionado) {
		this.contasPagarSelecionado = contasPagarSelecionado;
	}

}
