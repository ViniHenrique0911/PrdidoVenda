package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Categoria;
import com.algaworks.pedidovenda.model.SubCategoria;
import com.algaworks.pedidovenda.repository.SubCategorias;
import com.algaworks.pedidovenda.service.CadastroSubCategoriaService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroSubCategoriaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private SubCategoria subCategoria;
	
	@Inject
	private SubCategorias subCategorias;
	
	@Inject
	private CadastroSubCategoriaService cadastroSubCategoriaService;
	
	public void inicializar(){
		if (subCategoria == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.subCategoria = new SubCategoria();
	}
	
	public void salvar() {
		try {
			cadastroSubCategoriaService.salvar(subCategoria);
			limpar();
			
			FacesUtil.addInfoMessage("Sub categoria foi salvo com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<Categoria> completarCategoria(String nome) {
		return this.subCategorias.porCategoria(nome);
	}
	
	public SubCategoria getSubCategoria() {
		return subCategoria;
	}
	
	public void setSubCategoria(SubCategoria subCategoria) {
		this.subCategoria = subCategoria;
	}
	
	public boolean isEditando() {
		return subCategoria != null && subCategoria.getId() == null;
	}
	
}
