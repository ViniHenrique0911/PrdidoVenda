package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Cidade;
import com.algaworks.pedidovenda.repository.Cidades;
import com.algaworks.pedidovenda.repository.filter.CidadeFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaCidadesBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private Cidades cidades;
	
	private CidadeFilter filtro;
	private List<Cidade> cidadesFiltrados;
	
	private Cidade cidadeSelecionado;
	
	public PesquisaCidadesBean() {
		filtro = new CidadeFilter();
	}
	
	public void pesquisar() {
		cidadesFiltrados = cidades.filtrados(filtro);
	}
	
	public void excluir() {
		try {
			cidades.remover(cidadeSelecionado);
			cidadesFiltrados.remove(cidadeSelecionado);
			
			FacesUtil.addInfoMessage("Cidade " + cidadeSelecionado.getNome() + 
					" foi excluída com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<Cidade> getCidadesFiltrados() {
		return cidadesFiltrados;
	}

	public CidadeFilter getFiltro() {
		return filtro;
	}

	public Cidade getCidadeSelecionado() {
		return cidadeSelecionado;
	}

	public void setCidadeSelecionado(Cidade cidadeSelecionado) {
		this.cidadeSelecionado = cidadeSelecionado;
	}
	
}
