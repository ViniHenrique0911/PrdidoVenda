package com.algaworks.pedidovenda.repository.filter;

import java.io.Serializable;
import java.util.Date;

import com.algaworks.pedidovenda.model.StatusContasReceber;

public class ContasReceberFilter implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long numeroPedidoDe;
	private Long numeroPedidoAte;
	private Long numeroDevolucaoDe;
	private Long numeroDevolucaoAte;
	private Long numeroContasDe;
	private Long numeroContasAte;
	private Date dataLancamentoDe;
	private Date dataLancamentoAte;
	private Date dataPagamentoDe;
	private Date dataPagamentoAte;
	private String nomeCliente;
	private StatusContasReceber[] statuses;

	private int primeiroRegistro;
	private int quantidadeRegistros;
	private String propriedadeOrdenacao;
	private boolean ascendente;

	public Long getNumeroPedidoDe() {
		return numeroPedidoDe;
	}

	public void setNumeroPedidoDe(Long numeroPedidoDe) {
		this.numeroPedidoDe = numeroPedidoDe;
	}

	public Long getNumeroDevolucaoDe() {
		return numeroDevolucaoDe;
	}

	public void setNumeroDevolucaoDe(Long numeroDevolucaoDe) {
		this.numeroDevolucaoDe = numeroDevolucaoDe;
	}

	public Long getNumeroDevolucaoAte() {
		return numeroDevolucaoAte;
	}

	public void setNumeroDevolucaoAte(Long numeroDevolucaoAte) {
		this.numeroDevolucaoAte = numeroDevolucaoAte;
	}

	public Long getNumeroPedidoAte() {
		return numeroPedidoAte;
	}

	public void setNumeroPedidoAte(Long numeroPedidoAte) {
		this.numeroPedidoAte = numeroPedidoAte;
	}

	public Long getNumeroContasDe() {
		return numeroContasDe;
	}

	public void setNumeroContasDe(Long numeroContasDe) {
		this.numeroContasDe = numeroContasDe;
	}

	public Long getNumeroContasAte() {
		return numeroContasAte;
	}

	public void setNumeroContasAte(Long numeroContasAte) {
		this.numeroContasAte = numeroContasAte;
	}

	public Date getDataLancamentoDe() {
		return dataLancamentoDe;
	}

	public void setDataLancamentoDe(Date dataLancamentoDe) {
		this.dataLancamentoDe = dataLancamentoDe;
	}

	public Date getDataLancamentoAte() {
		return dataLancamentoAte;
	}

	public void setDataLancamentoAte(Date dataLancamentoAte) {
		this.dataLancamentoAte = dataLancamentoAte;
	}

	public Date getDataPagamentoDe() {
		return dataPagamentoDe;
	}

	public void setDataPagamentoDe(Date dataPagamentoDe) {
		this.dataPagamentoDe = dataPagamentoDe;
	}

	public Date getDataPagamentoAte() {
		return dataPagamentoAte;
	}

	public void setDataPagamentoAte(Date dataPagamentoAte) {
		this.dataPagamentoAte = dataPagamentoAte;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public StatusContasReceber[] getStatuses() {
		return statuses;
	}

	public void setStatuses(StatusContasReceber[] statuses) {
		this.statuses = statuses;
	}

	public int getPrimeiroRegistro() {
		return primeiroRegistro;
	}

	public void setPrimeiroRegistro(int primeiroRegistro) {
		this.primeiroRegistro = primeiroRegistro;
	}

	public int getQuantidadeRegistros() {
		return quantidadeRegistros;
	}

	public void setQuantidadeRegistros(int quantidadeRegistros) {
		this.quantidadeRegistros = quantidadeRegistros;
	}

	public String getPropriedadeOrdenacao() {
		return propriedadeOrdenacao;
	}

	public void setPropriedadeOrdenacao(String propriedadeOrdenacao) {
		this.propriedadeOrdenacao = propriedadeOrdenacao;
	}

	public boolean isAscendente() {
		return ascendente;
	}

	public void setAscendente(boolean ascendente) {
		this.ascendente = ascendente;
	}

}