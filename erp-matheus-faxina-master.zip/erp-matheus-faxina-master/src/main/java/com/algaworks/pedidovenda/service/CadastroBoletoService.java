package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Boleto;
import com.algaworks.pedidovenda.repository.Boletos;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroBoletoService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Boletos boletos;
	
	@Transactional
	public Boleto salvar(Boleto boleto) throws NegocioException {
		return boletos.guardar(boleto);
	}
}