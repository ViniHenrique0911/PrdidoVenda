package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Permissao;
import com.algaworks.pedidovenda.repository.filter.PermissaoFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Permissoes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Permissao porId(Long id) {
		return this.manager.find(Permissao.class, id);
	}

	public List<Permissao> porNome(String nome) {
		return this.manager.createQuery("from Permissao " + "where upper(nome) like :nome", Permissao.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Permissao> filtrados(PermissaoFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Permissao> criteriaQuery = builder.createQuery(Permissao.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Permissao> permissaoRoot = criteriaQuery.from(Permissao.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(permissaoRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(permissaoRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(permissaoRoot.get("nome")));

		TypedQuery<Permissao> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public Permissao guardar(Permissao permissao) {
		return manager.merge(permissao);
	}

	@Transactional
	public void remover(Permissao permissao) throws NegocioException {
		try {
			permissao = porId(permissao.getId());
			manager.remove(permissao);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Permissao não pode ser excluído.");
		}
	}

}