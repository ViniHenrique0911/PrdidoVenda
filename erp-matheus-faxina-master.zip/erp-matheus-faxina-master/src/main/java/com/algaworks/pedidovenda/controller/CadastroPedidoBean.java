package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.deltaspike.core.api.scope.ViewAccessScoped;
import org.hibernate.validator.constraints.NotBlank;
import org.primefaces.event.SelectEvent;

import com.algaworks.pedidovenda.model.Categoria;
import com.algaworks.pedidovenda.model.Cliente;
import com.algaworks.pedidovenda.model.EnderecoEntrega;
import com.algaworks.pedidovenda.model.FormaPagamentoo;
import com.algaworks.pedidovenda.model.ItemPedido;
import com.algaworks.pedidovenda.model.Mesa;
import com.algaworks.pedidovenda.model.Parcela;
import com.algaworks.pedidovenda.model.Pedido;
import com.algaworks.pedidovenda.model.Preco;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.model.SubCategoria;
import com.algaworks.pedidovenda.model.UnidadeMedidaProduto;
import com.algaworks.pedidovenda.repository.Clientes;
import com.algaworks.pedidovenda.repository.Mesas;
import com.algaworks.pedidovenda.repository.Parcelas;
import com.algaworks.pedidovenda.repository.Pedidos;
import com.algaworks.pedidovenda.repository.Produtos;
import com.algaworks.pedidovenda.service.CadastroPedidoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;
import com.algaworks.pedidovenda.validation.SKU;

@Named
@ViewAccessScoped
public class CadastroPedidoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Parcelas parcelas;

	@Inject
	private Clientes clientes;

	@Inject
	private Produtos produtos;

	@Inject
	private CadastroPedidoService cadastroPedidoService;

	private String sku;

	private String nome;

	@Produces
	@PedidoEdicao
	private Pedido pedido;

	@Inject
	private Mesas mesass;

	@Inject
	private Pedidos pedidos;

	private List<Parcela> listParcelas;
	private List<FormaPagamentoo> listFormaPagamentos;
	private List<Mesa> mesas;
	private List<Cliente> listClientes;

	private Produto produtoLinhaEditavel;

	private boolean campoAtivo;

	private BigDecimal novoValor;

	private Mesa mesaSelecionada;

	private List<Categoria> categorias;
	private List<SubCategoria> subCategorias;
	private List<Produto> listaProdutos;

	private Preco grupoPreco;

	private ItemPedido itemPedido = new ItemPedido();

	public String tipoMesa(Mesa mesa) {
        if (!mesa.isOcupada()) {
            return "mesa-livre.png";
        }
        return "mesa-ocupada.png";
    }

	
	public void pegaProduto(Produto produto) {
		itemPedido.setProduto(produto);
		itemPedido.setPedido(this.pedido);
		itemPedido.setGrupoPreco(produto.getGrupoPreco().get(0));

		pedido.getItens().add(itemPedido);
		this.pedido.recalcularValorTotal();
	}

	public List<Categoria> listCategorias() {
		return this.categorias = pedidos.todasCategorias();
	}

	public List<SubCategoria> buscarSubCategorias(Categoria categoria) {
		return this.subCategorias = pedidos.todasSubCategoriasPorCategoria(categoria.getId());
	}

	public List<Produto> buscarProdutosPorSubCategorias(SubCategoria subCategoria) {
		return this.listaProdutos = pedidos.todosProdutos(subCategoria.getId());
	}

	public CadastroPedidoBean() {
		limpar();
	}

	public List<Mesa> inicializaMesa() {
		return pedidos.todasMesas();
	}

	public boolean liberaMesaPedido(Mesa mesa) {
		if (mesa.isOcupada() == true) {
			return false;
		} else {
			return true;
		}
	}

	public boolean liberaMesaMesa(Mesa mesa) {
		if (mesa.isOcupada() == true) {
			return true;
		} else {
			return false;
		}
	}

	public void liberarMesa() {
		try {
			mesaSelecionada.setOcupada(false);
			mesass.guardar(mesaSelecionada);
			FacesUtil.addInfoMessage("A mesa " + mesaSelecionada.getNome() + " foi atualizada com sucesso!");
		} catch (Exception e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public void novoPedido(Mesa m) {
		pedido = new Pedido();
		pedido.setMesa(m);
		pedido.setEnderecoEntrega(new EnderecoEntrega());
		inicializar();
	}

	public List<Preco> completarGrupoPreco(Produto produto) {
		return this.produtos.porGrupoPreco(produto.getId());
	}

	public void inicializarPedido() {
		this.listFormaPagamentos = this.pedidos.porFormaPagamento();
		this.mesas = this.pedidos.porMesa();

		this.recalcularPedido();

	}

	public void inicializar() {
		if (this.pedido == null) {
			limpar();
		}

		this.listFormaPagamentos = this.pedidos.porFormaPagamento();
		this.mesas = this.pedidos.porMesa();

		this.pedido.adicionarItemVazio();

		this.recalcularPedido();
		System.out.println("Método inicializar: " + pedido.getItens());
	}

	public void clienteSelecionado(SelectEvent event) {
		pedido.setCliente((Cliente) event.getObject());
	}

	private void limpar() {
		pedido = new Pedido();
		pedido.setEnderecoEntrega(new EnderecoEntrega());
	}

	public void pedidoAlterado(@Observes PedidoAlteradoEvent event) {
		this.pedido = event.getPedido();
	}

	public void salvar() {
		this.pedido.removerItemVazio();

		try {
			this.pedido = this.cadastroPedidoService.salvar(this.pedido);
			FacesUtil.addInfoMessage("Pedido foi salvo com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		} finally {
			this.pedido.adicionarItemVazio();
		}
	}

	public void pegaFormaPagamento() {
		listParcelas = pedidos.porParcelaFiltradaPorFormaPagamento(pedido.getFormaPagamento().getId());
	}

	public void recalcularPedido() {
		if (this.pedido != null) {
			this.pedido.recalcularValorTotal();
		}
	}

	public void carregarProdutoPorSku() {
		if (StringUtils.isNotEmpty(this.sku)) {
			this.produtoLinhaEditavel = this.produtos.porSku(this.sku);
			this.carregarProdutoLinhaEditavel();
		}
	}

	public void pegaGrupoPreco(BigDecimal valor) {
		this.pedido.recalcularValorTotal();
	}

	public BigDecimal recuperaValor(BigDecimal valor) {
		return valor;
	}

	public void carregarProdutoLinhaEditavel() {
		ItemPedido item = this.pedido.getItens().get(0);

		if (this.produtoLinhaEditavel != null) {
			if (this.existeItemComProduto(this.produtoLinhaEditavel)) {
				FacesUtil.addErrorMessage("Já existe um item no pedido com o produto informado.");
			} else {
				item.setProduto(this.produtoLinhaEditavel);
				this.pedido.adicionarItemVazio();
				item.setGrupoPreco(this.produtoLinhaEditavel.getGrupoPreco().get(0));
				this.produtoLinhaEditavel = null;
				this.sku = null;
				this.pedido.recalcularValorTotal();
			}
		}
	}

	private boolean existeItemComProduto(Produto produto) {
		boolean existeItem = false;

		for (ItemPedido item : this.getPedido().getItens()) {
			if (produto.equals(item.getProduto())) {
				existeItem = true;
				break;
			}
		}

		return existeItem;
	}

	public List<Produto> completarProduto(String nome) {
		return this.produtos.porNome(nome);
	}

	public void atualizarQuantidade(ItemPedido item, int linha) {
		if (item.getQuantidade() < 1.0) {
			if (linha == 0.0) {
				item.setQuantidade(new Float(1.0));
			} else {
				this.getPedido().getItens().remove(linha);
			}
		}

		this.pedido.recalcularValorTotal();
	}

	public void removerProduto(float linha) {
		this.getPedido().getItens().remove(linha);
	}

	public UnidadeMedidaProduto[] getUnidadesMedida() {
		return UnidadeMedidaProduto.values();
	}

	public List<Cliente> completarCliente(String nome) {
		return this.clientes.porNome(nome);
	}

	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

	public List<Parcela> getListParcelas() {
		return listParcelas;
	}

	public boolean isEditando() {
		return this.pedido.getId() != null;
	}

	public Produto getProdutoLinhaEditavel() {
		return produtoLinhaEditavel;
	}

	public void setProdutoLinhaEditavel(Produto produtoLinhaEditavel) {
		this.produtoLinhaEditavel = produtoLinhaEditavel;
	}

	@SKU
	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	@NotBlank
	public String getNomeCliente() {
		return pedido.getCliente() == null ? null : pedido.getCliente().getNome();
	}

	public void setNomeCliente(String nome) {
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public boolean isCampoAtivo() {
		return campoAtivo;
	}

	public void setCampoAtivo(boolean campoAtivo) {
		this.campoAtivo = campoAtivo;
	}

	public BigDecimal getNovoValor() {
		return novoValor;
	}

	public void setNovoValor(BigDecimal novoValor) {
		this.novoValor = novoValor;
	}

	public Parcelas getParcelas() {
		return parcelas;
	}

	public void setParcelas(Parcelas parcelas) {
		this.parcelas = parcelas;
	}

	public List<FormaPagamentoo> getListFormaPagamentos() {
		return listFormaPagamentos;
	}

	public void setListFormaPagamentos(List<FormaPagamentoo> listFormaPagamentos) {
		this.listFormaPagamentos = listFormaPagamentos;
	}

	public void setListParcelas(List<Parcela> listParcelas) {
		this.listParcelas = listParcelas;
	}

	public List<Mesa> getMesas() {
		return mesas;
	}

	public void setMesas(List<Mesa> mesas) {
		this.mesas = mesas;
	}

	public List<Cliente> getListClientes() {
		return listClientes;
	}

	public Mesa getMesaSelecionada() {
		return mesaSelecionada;
	}

	public List<SubCategoria> getSubCategorias() {
		return subCategorias;
	}

	public List<Produto> getListaProdutos() {
		return listaProdutos;
	}

	public Preco getGrupoPreco() {
		return grupoPreco;
	}

	public ItemPedido getItemPedido() {
		return itemPedido;
	}

}