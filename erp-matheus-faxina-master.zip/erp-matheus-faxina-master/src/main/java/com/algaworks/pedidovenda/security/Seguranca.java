package com.algaworks.pedidovenda.security;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Produces;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import com.algaworks.pedidovenda.model.ConfiguracaoEmpresa;
import com.algaworks.pedidovenda.model.Grupo;
import com.algaworks.pedidovenda.repository.ConfiguracoesEmpresas;
import com.algaworks.pedidovenda.repository.Pedidos;

@Named
@RequestScoped
public class Seguranca {

	@Inject
	private Pedidos pedidos;

	@Inject
	private ConfiguracoesEmpresas configuracoesEmpresas;

	@Inject
	private ExternalContext externalContext;

	@Inject
	@UsuarioLogado
	private UsuarioSistema usuarioSistema;

	public String getRecuperaFotoEmpresa() {
		String foto = null;

		ConfiguracaoEmpresa configuracaoEmpresa = configuracoesEmpresas.porId(1L);

		if (configuracaoEmpresa != null) {
			foto = configuracaoEmpresa.getFoto();
		}

		return foto;
	}

	public String getRecuperaFotoEmpresaUsuarioLogado() {
		String foto = null;

		UsuarioSistema usuarioLogado = getUsuarioLogado();

		if (usuarioLogado != null) {
			foto = usuarioLogado.getUsuario().getConfiguracaoEmpresa().getFoto();
		}

		return foto;
	}

	public String getRecuperaFotoUsuarioLogado() {
		String foto = null;

		UsuarioSistema usuarioLogado = getUsuarioLogado();

		if (usuarioLogado != null) {
			foto = usuarioLogado.getUsuario().getFoto();
		}

		return foto;
	}

	public String getNomeUsuario() {
		String nome = null;

		UsuarioSistema usuarioLogado = getUsuarioLogado();

		if (usuarioLogado != null) {
			nome = usuarioLogado.getUsuario().getNome();
		}

		return nome;
	}

	@Produces
	@UsuarioLogado
	public UsuarioSistema getUsuarioLogado() {
		UsuarioSistema usuario = null;

		UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) FacesContext
				.getCurrentInstance().getExternalContext().getUserPrincipal();

		if (auth != null && auth.getPrincipal() != null) {
			usuario = (UsuarioSistema) auth.getPrincipal();
		}

		return usuario;
	}
	
	public boolean getDesativaBotaoPelaPermissaoSoVendedor() {
		
		UsuarioSistema usuarioLogado = getUsuarioLogado();
		
		String nomeDoGrupo = null;
		
		
		for (Grupo grupo : usuarioLogado.getUsuario().getGrupos()) {
			nomeDoGrupo = grupo.getNome();
		}
		
		if (nomeDoGrupo.equals("ADMINISTRADORES")) {
			return true;
		}
		
		return false;
	
	}
	
public boolean getDesativaBotaoPelaPermissaoSoGerente() {
		
		UsuarioSistema usuarioLogado = getUsuarioLogado();
		
		String nomeDoGrupo = null;
		
		
		for (Grupo grupo : usuarioLogado.getUsuario().getGrupos()) {
			nomeDoGrupo = grupo.getNome();
		}
		
		if (nomeDoGrupo.equals("GERENTE")) {
			return true;
		}
		
		return false;
	
	}

	public Long getTotalPedidoPorUsuario() {
		return pedidos.getPedidoTotalPorFuncionario(usuarioSistema.getUsuario());
	}

	public boolean isEmitirPedidoPermitido() {
		return externalContext.isUserInRole("ADMINISTRADORES") || externalContext.isUserInRole("VENDEDORES");
	}

	public boolean isCancelarPedidoPermitido() {
		return externalContext.isUserInRole("ADMINISTRADORES") || externalContext.isUserInRole("VENDEDORES");
	}

	public boolean isEmitirCompraPermitido() {
		return externalContext.isUserInRole("ADMINISTRADORES") || externalContext.isUserInRole("VENDEDORES");
	}

	public boolean isCancelarCompraPermitido() {
		return externalContext.isUserInRole("ADMINISTRADORES") || externalContext.isUserInRole("VENDEDORES");
	}

	public boolean isBaixarContasReceber() {
		return externalContext.isUserInRole("ADMINISTRADORES") || externalContext.isUserInRole("VENDEDORES");
	}

}
