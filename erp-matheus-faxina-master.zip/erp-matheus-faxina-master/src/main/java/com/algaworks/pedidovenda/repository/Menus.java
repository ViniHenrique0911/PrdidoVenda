package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.model.Menu;
import com.algaworks.pedidovenda.repository.filter.MenuFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Menus implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Menu porId(Long id) {
		return this.manager.find(Menu.class, id);
	}
	
	public List<Menu> menusFilhos() {
		return this.manager.createQuery("from Menu", Menu.class).getResultList();
	}

	public List<Menu> porNome(String nome) {
		return this.manager.createQuery("from Menu " + "where upper(nome) like :nome", Menu.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Menu> listarTodos() {
		return this.manager.createQuery("from Menu", Menu.class).getResultList();
	}

	public List<Menu> menusPais() {
		return this.manager.createQuery("from Menu where menu_id = null", Menu.class).getResultList();
	}

	public List<Menu> filtrados(MenuFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Menu> criteriaQuery = builder.createQuery(Menu.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Menu> menuRoot = criteriaQuery.from(Menu.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates
					.add(builder.like(builder.lower(menuRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(menuRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(menuRoot.get("nome")));

		TypedQuery<Menu> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public Menu guardar(Menu menu) {
		return manager.merge(menu);
	}

	@Transactional
	public void remover(Menu menu) throws NegocioException {
		try {
			menu = porId(menu.getId());
			manager.remove(menu);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Menu não pode ser excluído.");
		}
	}

	public List<Estado> porEstado(String nome) {
		return this.manager.createQuery("from Estado where upper(nome) like :nome", Estado.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
}