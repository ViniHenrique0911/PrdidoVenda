package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Mesa;
import com.algaworks.pedidovenda.repository.Mesas;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroMesaService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Mesas mesas;
	
	@Transactional
	public Mesa salvar(Mesa mesa) throws NegocioException {
		return mesas.guardar(mesa);
	}
}