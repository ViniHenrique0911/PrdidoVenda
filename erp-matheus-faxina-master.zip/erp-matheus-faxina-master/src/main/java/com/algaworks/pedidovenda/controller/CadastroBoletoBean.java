package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Boleto;
import com.algaworks.pedidovenda.service.CadastroBoletoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroBoletoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Boleto boleto;
	
	@Inject
	private CadastroBoletoService cadastroBoletoService;
	
	public void inicializar(){
		if (boleto == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.boleto = new Boleto();
	}
	
	public void salvar() {
		try {
			cadastroBoletoService.salvar(boleto);
			limpar();
			
			FacesUtil.addInfoMessage("Boleto foi salvo com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public Boleto getBoleto() {
		return boleto;
	}
	
	public void setBoleto(Boleto boleto) {
		this.boleto = boleto;
	}
	
	public boolean isEditando() {
		return boleto != null && boleto.getId() == null;
	}


}
