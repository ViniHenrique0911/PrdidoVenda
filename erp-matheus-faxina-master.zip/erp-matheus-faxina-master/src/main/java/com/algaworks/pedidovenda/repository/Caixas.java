package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Caixa;
import com.algaworks.pedidovenda.repository.filter.CaixaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Caixas implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Caixa porId(Long id) {
		return this.manager.find(Caixa.class, id);
	}

	public List<Caixa> porNome(String nome) {
		return this.manager.createQuery("from Caixa " + "where upper(nome) like :nome", Caixa.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Caixa> filtrados(CaixaFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Caixa> criteriaQuery = builder.createQuery(Caixa.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Caixa> caixaRoot = criteriaQuery.from(Caixa.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(caixaRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(caixaRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(caixaRoot.get("nome")));

		TypedQuery<Caixa> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public Caixa guardar(Caixa caixa) {
		return manager.merge(caixa);
	}

	@Transactional
	public void remover(Caixa caixa) throws NegocioException {
		try {
			caixa = porId(caixa.getId());
			manager.remove(caixa);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Caixa não pode ser excluído.");
		}
	}

}