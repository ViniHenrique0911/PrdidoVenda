package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.ContasReceber;
import com.algaworks.pedidovenda.model.Devolucao;
import com.algaworks.pedidovenda.model.StatusContasReceber;
import com.algaworks.pedidovenda.service.CancelamentoDevolucaoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@RequestScoped
public class CancelamentoDevolucaoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CancelamentoDevolucaoService cancelamentoDevolucaoService;
	
	@Inject
	private Event<DevolucaoAlteradoEvent> devolucaoAlteradoEvent;
	
	@Inject
	@DevolucaoEdicao
	private Devolucao devolucao;
	
	public void cancelarDevolucao() {
		try {
			this.devolucao = this.cancelamentoDevolucaoService.cancelar(this.devolucao);
			this.devolucaoAlteradoEvent.fire(new DevolucaoAlteradoEvent(this.devolucao));
			cancelaContasReceber();
			
			FacesUtil.addInfoMessage("Devolução foi cancelada com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		}
	}
	
	public void cancelaContasReceber() {
		for(ContasReceber contasReceber : devolucao.getContasRecebers()) {
			try {
				contasReceber.setStatus(StatusContasReceber.CANCELADO);
				cancelamentoDevolucaoService.salvarSemIf(contasReceber);
			} catch (NegocioException e) {
				e.printStackTrace();
			}
		}
	}
	
}
