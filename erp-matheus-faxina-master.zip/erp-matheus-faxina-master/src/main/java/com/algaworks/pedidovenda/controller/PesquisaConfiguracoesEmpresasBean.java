package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.ConfiguracaoEmpresa;
import com.algaworks.pedidovenda.repository.ConfiguracoesEmpresas;
import com.algaworks.pedidovenda.repository.filter.ConfiguracaoEmpresaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaConfiguracoesEmpresasBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private ConfiguracoesEmpresas configuracoesEmpresas;
	
	private ConfiguracaoEmpresaFilter filtro;
	private List<ConfiguracaoEmpresa> configuracoesEmpresasFiltrados;
	
	private ConfiguracaoEmpresa configuracaoEmpresaSelecionado;
	
	public PesquisaConfiguracoesEmpresasBean() {
		filtro = new ConfiguracaoEmpresaFilter();
	}
	
	public void pesquisar() {
		configuracoesEmpresasFiltrados = configuracoesEmpresas.filtrados(filtro);
	}
	
	public void excluir() {
		try {
			configuracoesEmpresas.remover(configuracaoEmpresaSelecionado);
			configuracoesEmpresasFiltrados.remove(configuracaoEmpresaSelecionado);
			
			FacesUtil.addInfoMessage("Configuração da empresa " + configuracaoEmpresaSelecionado.getRazaoSocial() + 
					" foi excluída com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<ConfiguracaoEmpresa> getConfiguracoesEmpresasFiltrados() {
		return configuracoesEmpresasFiltrados;
	}

	public ConfiguracaoEmpresaFilter getFiltro() {
		return filtro;
	}

	public ConfiguracaoEmpresa getConfiguracaoEmpresaSelecionado() {
		return configuracaoEmpresaSelecionado;
	}

	public void setConfiguracaoEmpresaSelecionado(ConfiguracaoEmpresa configuracaoEmpresaSelecionado) {
		this.configuracaoEmpresaSelecionado = configuracaoEmpresaSelecionado;
	}
	
}
