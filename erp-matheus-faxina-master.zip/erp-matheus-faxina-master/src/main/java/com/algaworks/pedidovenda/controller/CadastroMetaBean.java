package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Meta;
import com.algaworks.pedidovenda.model.Usuario;
import com.algaworks.pedidovenda.repository.Metas;
import com.algaworks.pedidovenda.service.CadastroMetaService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroMetaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Meta meta;
	
	@Inject
	private Metas metas;
	
	@Inject
	private CadastroMetaService cadastroMetaService;
	
	public void inicializar(){
		if (meta == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.meta = new Meta();
	}
	
	public void salvar() {
		try {
			cadastroMetaService.salvar(meta);
			limpar();
			
			FacesUtil.addInfoMessage("Meta foi salva com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<Usuario> completarVendedor(String nome) {
		return this.metas.porUsuario(nome);
	}
	
	public Meta getMeta() {
		return meta;
	}
	
	public void setMeta(Meta meta) {
		this.meta = meta;
	}
	
	public boolean isEditando() {
		return meta != null && meta.getId() == null;
	}
	
}
