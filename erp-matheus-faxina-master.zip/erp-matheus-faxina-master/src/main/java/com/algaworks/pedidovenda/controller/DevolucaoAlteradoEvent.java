package com.algaworks.pedidovenda.controller;

import com.algaworks.pedidovenda.model.Devolucao;

public class DevolucaoAlteradoEvent {

	private Devolucao devolucao;
	
	public DevolucaoAlteradoEvent(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}
	
}
