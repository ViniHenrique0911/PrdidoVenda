package com.algaworks.pedidovenda.controller;

import java.io.OutputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletResponse;

import org.primefaces.model.LazyDataModel;

import com.algaworks.pedidovenda.boleto.EmissorBoleto;
import com.algaworks.pedidovenda.model.Boleto;
import com.algaworks.pedidovenda.model.ContasReceber;
import com.algaworks.pedidovenda.model.StatusContasReceber;
import com.algaworks.pedidovenda.repository.Boletos;
import com.algaworks.pedidovenda.repository.ContasRecebers;
import com.algaworks.pedidovenda.repository.filter.ContasReceberFilter;
import com.algaworks.pedidovenda.service.CadastroContasReceberService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaContasRecebersBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private ContasRecebers contasRecebers;

	@Inject
	private CadastroContasReceberService cadastroContasReceberService;

	@Inject
	private EmissorBoleto emissorBoleto;

	@Inject
	private Boletos boletos;

	private ContasReceber contasReceber;

	private ContasReceberFilter filtro;
	private List<ContasReceber> contasRecebersFiltrados;

	private ContasReceber contasReceberSelecionado;

	private List<ContasReceber> contasReceberSelecionados;

	private LazyDataModel<ContasReceber> model;

	public void mesclar() {
		if (contasReceberSelecionados.size() <= 1) {
			FacesUtil.addInfoMessage("Para mesclar pagamentos tem que ter mais que um lançamento selecionado!");
		} else if (contasReceberSelecionados.size() > 1) {
			BigDecimal valor = BigDecimal.ZERO;
			for (ContasReceber contasReceber : contasReceberSelecionados) {
				valor = valor.add(contasReceber.getValorPagamento());
				System.out.println(valor);
			}
		}

	}

	public String recuperaCor(String descricao) {
		if (descricao.equals("Recebido")) {
			return "color: blue";
		}
		if (descricao.equals("A Receber")) {
			return "color: yellow";
		} else {
			return "color: red";
		}
	}

	public boolean desabilitarBotaoBoleto(String descricao) {
		if (descricao.equals("Cancelado")) {
			return true;
		}

		if (descricao.equals("Recebido")) {
			return true;
		} else {
			return false;
		}
	}

	public boolean desabilitarBotaoBaixar(String descricao) {
		if (descricao.equals("Recebido")) {
			return true;
		}

		if (descricao.equals("Cancelado")) {
			return true;
		} else {
			return false;
		}
	}

	public boolean desabilitarBotaoCancelar(String descricao) {
		if (descricao.equals("Recebido")) {
			return true;
		}

		if (descricao.equals("Cancelado")) {
			return true;
		} else {
			return false;
		}
	}

	public PesquisaContasRecebersBean() {
		filtro = new ContasReceberFilter();

		/*
		 * model = new LazyDataModel<ContasReceber>() {
		 * 
		 * private static final long serialVersionUID = 1L;
		 * 
		 * @Override public List<ContasReceber> load(int first, int pageSize, String
		 * sortField, SortOrder sortOrder, Map<String, Object> filters) {
		 * 
		 * filtro.setPrimeiroRegistro(first); filtro.setQuantidadeRegistros(pageSize);
		 * filtro.setPropriedadeOrdenacao(sortField);
		 * filtro.setAscendente(SortOrder.ASCENDING.equals(sortOrder));
		 * 
		 * setRowCount(contasRecebers.quantidadeFiltrados(filtro));
		 * 
		 * return contasRecebers.filtrados(filtro); }
		 * 
		 * };
		 */ }

	public void pesquisar() {
		this.contasRecebersFiltrados = contasRecebers.listar();
	}

	public void emitir() throws NegocioException {
		if (contasReceberSelecionado.isReceber()) {
			Boleto boleto = boletos.porCodigo(1L);
			byte[] pdf = this.emissorBoleto.gerarBoleto(boleto, contasReceberSelecionado);
			enviarBoleto(pdf);
			FacesUtil.addInfoMessage("Boleto do cliente " + contasReceberSelecionado.getCliente().getNome()
					+ " foi gerado com sucesso.");
		} else {
			FacesUtil.addErrorMessage(
					"O boleto não pode ser gerado pois a conta receber foi cancelada ou ja está baixada.");
		}
	}

	private void enviarBoleto(byte[] pdf) {
		HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext()
				.getResponse();

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition",
				"attachment; filename=boleto " + contasReceberSelecionado.getCliente().getNome() + ".pdf");

		try {
			OutputStream output = response.getOutputStream();
			output.write(pdf);
			response.flushBuffer();
		} catch (Exception e) {
			throw new RuntimeException("Erro gerando boleto: ", e);
		}

		FacesContext.getCurrentInstance().responseComplete();
	}

	public void cancelar() {
		try {
			if (contasReceberSelecionado.isNaoCancelavel()) {
				cadastroContasReceberService.cancelar(contasReceberSelecionado);
				FacesUtil.addInfoMessage("Contas a receber foi cancelada com sucesso!");
			}
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public void excluir() {
		try {
			contasRecebers.remover(contasReceberSelecionado);
			contasRecebersFiltrados.remove(contasReceberSelecionado);

			FacesUtil.addInfoMessage("Contas a receber do cliente " + contasReceberSelecionado.getCliente().getNome()
					+ " foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public StatusContasReceber[] getStatuses() {
		return StatusContasReceber.values();
	}

	public List<ContasReceber> getContasRecebersFiltrados() {
		return contasRecebersFiltrados;
	}

	public ContasReceberFilter getFiltro() {
		return filtro;
	}

	public ContasReceber getContasReceberSelecionado() {
		return contasReceberSelecionado;
	}

	public ContasReceber getContasReceber() {
		return contasReceber;
	}

	public void setContasReceberSelecionado(ContasReceber contasReceberSelecionado) {
		this.contasReceberSelecionado = contasReceberSelecionado;
	}

	public LazyDataModel<ContasReceber> getModel() {
		return model;
	}

	public List<ContasReceber> getContasReceberSelecionados() {
		return contasReceberSelecionados;
	}

	public void setContasReceberSelecionados(List<ContasReceber> contasReceberSelecionados) {
		this.contasReceberSelecionados = contasReceberSelecionados;
	}

}
