package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Marca;
import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.repository.Marcas;
import com.algaworks.pedidovenda.service.CadastroMarcaService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroMarcaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Marca marca;
	
	@Inject
	private Marcas marcas;
	
	@Inject
	private CadastroMarcaService cadastroMarcaService;
	
	public void inicializar(){
		if (marca == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.marca = new Marca();
	}
	
	public void salvar() {
		try {
			cadastroMarcaService.salvar(marca);
			limpar();
			
			FacesUtil.addInfoMessage("Marca foi salvo com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public Marca getMarca() {
		return marca;
	}
	
	public void setMarca(Marca marca) {
		this.marca = marca;
	}
	
	public boolean isEditando() {
		return marca != null && marca.getId() == null;
	}
	
}
