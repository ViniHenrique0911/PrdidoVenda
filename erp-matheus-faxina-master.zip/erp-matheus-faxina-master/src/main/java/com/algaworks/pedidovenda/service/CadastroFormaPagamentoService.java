package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.FormaPagamentoo;
import com.algaworks.pedidovenda.repository.FormaPagamentos;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroFormaPagamentoService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private FormaPagamentos formaPagamentos;

	@Transactional
	public FormaPagamentoo salvar(FormaPagamentoo formaPagamentoo) throws NegocioException {
		return formaPagamentos.guardar(formaPagamentoo);
	}
}