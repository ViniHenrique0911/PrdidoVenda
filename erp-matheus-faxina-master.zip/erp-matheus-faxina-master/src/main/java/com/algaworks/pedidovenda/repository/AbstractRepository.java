package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;

import com.algaworks.pedidovenda.util.jpa.Transactional;

public abstract class AbstractRepository<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	private Class<T> classe;

	public AbstractRepository(Class<T> classe) {
		this.classe = classe;
	}

	public abstract EntityManager getEm();

	@Transactional
	public T salvar(T entidade) throws Exception {
		try {
			entidade = getEm().merge(entidade);
			getEm().flush();
			return entidade;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Transactional
	public void excluir(T entidade) throws Exception {
		try {
			getEm().remove(getEm().merge(entidade));
			getEm().flush();
		} catch (Exception ex) {
			throw ex;
		}
	}

	public T pesquisarId(Long id) {
		return getEm().find(classe, id);
	}

	public List<T> listar() {
		return getEm().createQuery("FROM " + classe.getSimpleName()).getResultList();
	}

}
