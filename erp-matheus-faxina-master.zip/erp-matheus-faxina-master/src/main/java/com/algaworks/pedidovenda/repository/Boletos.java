package com.algaworks.pedidovenda.repository;

import java.io.Serializable;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import com.algaworks.pedidovenda.model.Boleto;

public class Boletos implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Boleto porCodigo(Long id) {
		return this.manager.find(Boleto.class, id);
	}

	public Boleto guardar(Boleto boleto) {
		return manager.merge(boleto);
	}

}
