package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.ItemDevolucao;
import com.algaworks.pedidovenda.model.Devolucao;
import com.algaworks.pedidovenda.repository.Devolucoes;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class EstoqueDevolucaoService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Devolucoes devolucoes;
	
	@Transactional
	public void aumentarItensEstoque(Devolucao pedido) throws NegocioException {
		pedido = this.devolucoes.porId(pedido.getId());
		
		for (ItemDevolucao item : pedido.getItens()) {
			item.getProduto().aumentarEstoque(item.getQuantidade());
		}
	}

	public void retornarItensEstoque(Devolucao pedido) {
		pedido = this.devolucoes.porId(pedido.getId());
		
		for (ItemDevolucao item : pedido.getItens()) {
			item.getProduto().retornarEstoque(item.getQuantidade());
		}
	}
	
}
