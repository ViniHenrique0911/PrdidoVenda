package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Categoria;
import com.algaworks.pedidovenda.model.SubCategoria;
import com.algaworks.pedidovenda.repository.filter.SubCategoriaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class SubCategorias implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public SubCategoria porId(Long id) {
		return this.manager.find(SubCategoria.class, id);
	}

	public List<SubCategoria> porNome(String nome) {
		return this.manager.createQuery("from SubCategoria " + "where upper(nome) like :nome", SubCategoria.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
	
	public List<SubCategoria> porSubCategoria(String nome) {
		return this.manager.createQuery("from SubCategoria where upper(nome) like :nome", SubCategoria.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<SubCategoria> filtrados(SubCategoriaFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<SubCategoria> criteriaQuery = builder.createQuery(SubCategoria.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<SubCategoria> subCategoriaRoot = criteriaQuery.from(SubCategoria.class);

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(subCategoriaRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(subCategoriaRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(subCategoriaRoot.get("nome")));

		TypedQuery<SubCategoria> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public SubCategoria guardar(SubCategoria subCategoria) {
		return manager.merge(subCategoria);
	}

	@Transactional
	public void remover(SubCategoria subCategoria) throws NegocioException {
		try {
			subCategoria = porId(subCategoria.getId());
			manager.remove(subCategoria);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Sub categoria não pode ser excluída.");
		}
	}

	public List<Categoria> porCategoria(String nome) {
		return this.manager.createQuery("from Categoria where upper(nome) like :nome", Categoria.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
}