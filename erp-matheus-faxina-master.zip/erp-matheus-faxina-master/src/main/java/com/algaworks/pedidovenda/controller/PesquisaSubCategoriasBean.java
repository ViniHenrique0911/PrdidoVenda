package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.SubCategoria;
import com.algaworks.pedidovenda.repository.SubCategorias;
import com.algaworks.pedidovenda.repository.filter.SubCategoriaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaSubCategoriasBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private SubCategorias subCategorias;
	
	private SubCategoriaFilter filtro;
	private List<SubCategoria> subCategoriasFiltrados;
	
	private SubCategoria subCategoriaSelecionado;
	
	public PesquisaSubCategoriasBean() {
		filtro = new SubCategoriaFilter();
	}
	
	public void pesquisar() {
		subCategoriasFiltrados = subCategorias.filtrados(filtro);
	}
	
	public void excluir() {
		try {
			subCategorias.remover(subCategoriaSelecionado);
			subCategoriasFiltrados.remove(subCategoriaSelecionado);
			
			FacesUtil.addInfoMessage("Sub categoria " + subCategoriaSelecionado.getNome() + 
					" foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<SubCategoria> getSubCategoriasFiltrados() {
		return subCategoriasFiltrados;
	}

	public SubCategoriaFilter getFiltro() {
		return filtro;
	}

	public SubCategoria getSubCategoriaSelecionado() {
		return subCategoriaSelecionado;
	}

	public void setSubCategoriaSelecionado(SubCategoria subCategoriaSelecionado) {
		this.subCategoriaSelecionado = subCategoriaSelecionado;
	}
	
}
