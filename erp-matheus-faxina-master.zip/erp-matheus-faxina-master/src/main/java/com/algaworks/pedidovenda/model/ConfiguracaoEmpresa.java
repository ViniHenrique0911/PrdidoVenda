package com.algaworks.pedidovenda.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "configuracao_empresa")
public class ConfiguracaoEmpresa implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull
	@Column(name = "razao_social", nullable = false)
	private String razaoSocial;

	@NotNull
	@Column(name = "nome_fantasia", nullable = false)
	private String nomeFantasia;

	@NotNull
	@Column(name = "cnpj", nullable = false)
	private String cnpj;

	@NotNull
	@Column(name = "ie", nullable = false)
	private String ie;

	@NotNull
	@Column(name = "areaAtuacao", nullable = false)
	private String areaAtuacao;

	@NotNull
	@Column(name = "telefone", nullable = false)
	private String telefone;

	@NotNull
	@Column(name = "email", nullable = false)
	private String email;

	@Column(name = "desconto_maximo_pedido")
	private Integer descontoMaximoPedido;

	@Column(name = "dias_valiade_orcamento")
	private Integer diasValidadeOrcaomento;

	private String foto;

	@Column(name = "sku_carvao")
	private String skuCarvao;

	@Column(name = "sku_aluminio")
	private String skuAluminio;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getNomeFantasia() {
		return nomeFantasia;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getIe() {
		return ie;
	}

	public void setIe(String ie) {
		this.ie = ie;
	}

	public String getAreaAtuacao() {
		return areaAtuacao;
	}

	public void setAreaAtuacao(String areaAtuacao) {
		this.areaAtuacao = areaAtuacao;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getDescontoMaximoPedido() {
		return descontoMaximoPedido;
	}

	public void setDescontoMaximoPedido(Integer descontoMaximoPedido) {
		this.descontoMaximoPedido = descontoMaximoPedido;
	}

	public Integer getDiasValidadeOrcaomento() {
		return diasValidadeOrcaomento;
	}

	public void setDiasValidadeOrcaomento(Integer diasValidadeOrcaomento) {
		this.diasValidadeOrcaomento = diasValidadeOrcaomento;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getSkuCarvao() {
		return skuCarvao;
	}

	public void setSkuCarvao(String skuCarvao) {
		this.skuCarvao = skuCarvao;
	}

	public String getSkuAluminio() {
		return skuAluminio;
	}

	public void setSkuAluminio(String skuAluminio) {
		this.skuAluminio = skuAluminio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConfiguracaoEmpresa other = (ConfiguracaoEmpresa) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
