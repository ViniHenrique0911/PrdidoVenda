package com.algaworks.pedidovenda.service;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.ContasReceber;
import com.algaworks.pedidovenda.model.FluxoCaixa;
import com.algaworks.pedidovenda.model.StatusContasReceber;
import com.algaworks.pedidovenda.model.StatusPedido;
import com.algaworks.pedidovenda.model.TipoFluxoCaixa;
import com.algaworks.pedidovenda.repository.ContasRecebers;
import com.algaworks.pedidovenda.repository.FluxoCaixas;
import com.algaworks.pedidovenda.util.jpa.Transactional;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

public class CadastroContasReceberService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private ContasRecebers contasRecebers;
	
	@Inject
	private FluxoCaixas fluxoCaixas;
	
	@Transactional
	public ContasReceber salvarSemIf(ContasReceber contasReceber) throws NegocioException {
		return contasRecebers.guardar(contasReceber);
	}
	
	@Transactional
	public ContasReceber salvar(ContasReceber contasReceber) throws NegocioException {

		BigDecimal valorPagar = contasReceber.getValorPagamento();
		BigDecimal valorReceber = contasReceber.getValorRecebimento();
		
		if (valorReceber.compareTo(valorPagar) < 0) {
			verificaValorRecebido(contasReceber, valorPagar, valorReceber);
		}
		
		if (valorPagar.compareTo(valorReceber) < 0) {
			throw new NegocioException("O valor a receber informado é maior que o valor a pagar.");
		}
		
		if (contasReceber.getPedido().getStatus() == StatusPedido.CANCELADO) {
			cancelar(contasReceber);
		}

		if (contasReceber.isCancelado()) {
			throw new NegocioException("Essa conta a receber foi cancelada.");
		}

		if (contasReceber.isRecebido()) {
			throw new NegocioException("Essa conta a receber já foi baixada.");
		}
		
		contasReceber.setStatus(StatusContasReceber.RECEBIDO);
		
		FluxoCaixa fluxoCaixa = new FluxoCaixa();
		fluxoCaixa.setContasReceber(contasReceber);
		fluxoCaixa.setDataLancamento(contasReceber.getDataLancamento());
		fluxoCaixa.setTipoFluxoCaixa(TipoFluxoCaixa.CONTAS_RECEBER);
		fluxoCaixa.setValor(contasReceber.getValorRecebimento());
		fluxoCaixas.guardar(fluxoCaixa);
		
		return contasRecebers.guardar(contasReceber);

	}

	private void verificaValorRecebido(ContasReceber contasReceber, BigDecimal valorPagar, BigDecimal valorReceber) {
		BigDecimal valorRestante;
		valorRestante = valorPagar.subtract(valorReceber);
		System.out.println(valorRestante);
		ContasReceber contasReceberNova = new ContasReceber();
		contasReceberNova.setCliente(contasReceber.getCliente());
		contasReceberNova.setDataLancamento(contasReceber.getDataLancamento());
		contasReceberNova.setDataPagamento(contasReceber.getDataPagamento());
		contasReceberNova.setDataVencimento(contasReceber.getDataVencimento());
		contasReceberNova.setNumeroParcela(contasReceber.getNumeroParcela());
		contasReceberNova.setPedido(contasReceber.getPedido());
		contasReceberNova.setStatus(StatusContasReceber.RECEBIDO_PARCIALMENTE);
		contasReceberNova.setTipoContasReceber(contasReceber.getTipoContasReceber());
		contasReceberNova.setValorPagamento(valorRestante);
		contasReceberNova.setVendedor(contasReceber.getVendedor());
		FacesUtil.addInfoMessage("O valor recebido é menor que o valor a pagar, sendo assim, foi criado um novo contas a receber com o valor restante!");
		contasRecebers.guardar(contasReceberNova);
	}

	@Transactional
	public ContasReceber cancelar(ContasReceber contasReceber) throws NegocioException {

		if (contasReceber.isReceber()) {
			contasReceber.setStatus(StatusContasReceber.CANCELADO);
			return contasRecebers.guardar(contasReceber);
		} else {
			throw new NegocioException(
					"Essa conta a receber não pode ser cancelada pois já foi recebida ou já está cancelada.");
		}
	}

}