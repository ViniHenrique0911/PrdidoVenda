package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.ContasPagar;
import com.algaworks.pedidovenda.repository.ContasPagars;

@FacesConverter(forClass = ContasPagar.class)
public class ContasPagarConverter implements Converter {

	@Inject
	private ContasPagars contasPagars;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		ContasPagar retorno = null;
		
		if (StringUtils.isNotEmpty(value)) {
			Long id = new Long(value);
			retorno = contasPagars.porId(id);
		}
		
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			ContasPagar contasPagar = (ContasPagar) value;
			return contasPagar.getId() == null ? null : contasPagar.getId().toString();
		}
		
		return "";
	}

}
