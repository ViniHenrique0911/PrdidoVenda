package com.algaworks.pedidovenda.controller;

import java.io.InputStream;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletResponse;

import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.repository.Produtos;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.view.JasperViewer;

@Named
@RequestScoped
public class RelatorioEtiquetasBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String[] is;

	private Produto produto;

	@Inject
	private Produtos produtos;

	private List<Produto> listProdutos = new ArrayList<>();

	@Inject
	private FacesContext facesContext;

	@Inject
	private HttpServletResponse response;

	@Inject
	private EntityManager manager;

	public void pegaId() {
		this.listProdutos = produtos.todos();
		System.out.println(listProdutos.get(1).getNome());
	}

	public void emitir() {
		pegaId();
		try {
			InputStream relatorioStream = this.getClass().getResourceAsStream("/relatorios/etiquetass.jasper");
			
			JRBeanCollectionDataSource dados = new JRBeanCollectionDataSource(listProdutos, false);
			JasperPrint print = JasperFillManager.fillReport(relatorioStream, null, dados);
			JasperViewer view = new JasperViewer(print, false);
			view.setVisible(true);
			
				JRExporter exportador = new JRPdfExporter();
				exportador.setParameter(JRExporterParameter.OUTPUT_STREAM, response.getOutputStream());
				exportador.setParameter(JRExporterParameter.JASPER_PRINT, print);
				
				response.setContentType("application/pdf");
				response.setHeader("Content-Disposition", "attachment; filename=\"" 
						+ "etiquetas"  + "\"");
				
				exportador.exportReport();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
