package com.algaworks.pedidovenda.repository;

import java.io.Serializable;

import javax.inject.Inject;
import javax.persistence.EntityManager;

public class Dashboards implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Long getProdutosBaixaEstoque() {
		return (Long) manager.createQuery("select count(id) from Produto where quantidadeEstoque < 2").getSingleResult();
	}
	
	public Long getRoshAPreparar() {
		return (Long) manager.createQuery("select count(id) from Preparar where preparado = 0 and entregue = 0").getSingleResult();
	}

}