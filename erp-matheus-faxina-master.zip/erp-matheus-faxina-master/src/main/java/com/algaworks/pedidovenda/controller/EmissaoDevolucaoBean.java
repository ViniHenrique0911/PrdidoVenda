package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Devolucao;
import com.algaworks.pedidovenda.service.EmissaoDevolucaoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@RequestScoped
public class EmissaoDevolucaoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EmissaoDevolucaoService emissaoDevolucaoService;
	
	@Inject
	@DevolucaoEdicao
	private Devolucao devolucao;
	
	@Inject
	private Event<DevolucaoAlteradoEvent> devolucaoAlteradoEvent;
	
	public void emitirDevolucao() {
		this.devolucao.removerItemVazio();
		
		try {
			this.devolucao = this.emissaoDevolucaoService.emitir(this.devolucao);
			this.devolucaoAlteradoEvent.fire(new DevolucaoAlteradoEvent(this.devolucao));
			
			FacesUtil.addInfoMessage("Devolução foi emitido com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		} finally {
			this.devolucao.adicionarItemVazio();
		}
	}
	
}
