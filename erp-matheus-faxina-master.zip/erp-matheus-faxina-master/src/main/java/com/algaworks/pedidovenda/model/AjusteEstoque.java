package com.algaworks.pedidovenda.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ajuste_estoque")
public class AjusteEstoque implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "data_ajuste")
	private Date dataAjuste = new Date();

	private String tipo = "ENTRADA";

	private String motivo;

	@Column(name = "estoque_atual")
	private Float estoqueAtual;

	@Column(name = "estoque_anterior")
	private Float estoqueAnterior;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "produto_id")
	private Produto produto;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getDataAjuste() {
		return dataAjuste;
	}

	public void setDataAjuste(Date dataAjuste) {
		this.dataAjuste = dataAjuste;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public Float getEstoqueAtual() {
		return estoqueAtual;
	}

	public void setEstoqueAtual(Float estoqueAtual) {
		this.estoqueAtual = estoqueAtual;
	}

	public Float getEstoqueAnterior() {
		return estoqueAnterior;
	}

	public void setEstoqueAnterior(Float estoqueAnterior) {
		this.estoqueAnterior = estoqueAnterior;
	}

	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

	public void ajustarEstoque() throws Exception {
		this.estoqueAnterior = produto.getQuantidadeEstoque();
		if (tipo.equals("ENTRADA")) {
			Float novoEstoque = produto.getQuantidadeEstoque() + estoqueAtual;
			produto.setQuantidadeEstoque(novoEstoque);
		} else {
			if (estoqueAtual.compareTo(produto.getQuantidadeEstoque()) > 0) {
				throw new Exception("Quantidade insuficiente no estoque");
			}
			Float novoEstoque = produto.getQuantidadeEstoque() - estoqueAtual;
			produto.setQuantidadeEstoque(novoEstoque);

		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AjusteEstoque other = (AjusteEstoque) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
