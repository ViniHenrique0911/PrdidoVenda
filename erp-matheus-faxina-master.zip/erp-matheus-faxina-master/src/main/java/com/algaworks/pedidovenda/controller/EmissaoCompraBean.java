package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Compra;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.service.EmissaoCompraService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@RequestScoped
public class EmissaoCompraBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EmissaoCompraService emissaoCompraService;
	
	@Inject
	@CompraEdicao
	private Compra compra;
	
	@Inject
	private Event<CompraAlteradoEvent> compraAlteradoEvent;
	
	private Produto produto;
	
	public void emitirCompra() {
		this.compra.removerItemVazio();
		
		try {
			this.compra = this.emissaoCompraService.emitir(this.compra);
			this.compraAlteradoEvent.fire(new CompraAlteradoEvent(this.compra));
			
			FacesUtil.addInfoMessage("Compra foi emitido com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		} finally {
			this.compra.adicionarItemVazio();
		}
	}
	
}
