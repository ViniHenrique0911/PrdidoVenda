package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.converter.MoneyConverter;
import com.algaworks.pedidovenda.model.Cidade;
import com.algaworks.pedidovenda.model.Cliente;
import com.algaworks.pedidovenda.model.Endereco;
import com.algaworks.pedidovenda.model.Pedido;
import com.algaworks.pedidovenda.model.TipoPessoa;
import com.algaworks.pedidovenda.repository.Clientes;
import com.algaworks.pedidovenda.repository.filter.HistoricoFilter;
import com.algaworks.pedidovenda.service.CadastroClienteService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroClienteBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Cliente cliente;

	private Endereco endereco;

	private boolean editandoEndereco;

	@Inject
	private Clientes clientes;

	@Inject
	private CadastroClienteService cadastroClienteService;

	private List<Pedido> historicoPedidosClientes;

	private HistoricoFilter historicoFiltro;

	public void pesquisarHistoricoClientes() {
		historicoPedidosClientes = clientes.pedidosPorCliente(cliente.getId());
	}

	public void inicializar() {
		if (cliente == null) {
			limpar();
		}
	}

	public void limpar() {
		this.cliente = new Cliente();
		this.cliente.setTipo(TipoPessoa.FISICA);
	}

	public void salvar() {
		try {
			cadastroClienteService.salvar(cliente);
			FacesUtil.addInfoMessage("Cliente foi salvo com sucesso!");
			limpar();
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public List<Cidade> completarCidade(String nome) {
		return this.clientes.porCidade(nome);
	}

	public void novoEndereco() {
		this.endereco = new Endereco();
		this.endereco.setCliente(this.cliente);
		this.editandoEndereco = false;
	}

	public void editarEndereco(Endereco endereco) {
		this.endereco = endereco;
		this.editandoEndereco = true;
	}

	public void excluirEndereco(Endereco endereco) {
		this.cliente.getEnderecos().remove(endereco);
	}

	public void confirmarEndereco() {
		if (!this.cliente.getEnderecos().contains(this.endereco)) {
			this.cliente.getEnderecos().add(this.endereco);
		}
	}

	public Long getTotalPedidoPorCliente() {
		return clientes.getTotalPedidosEmitidosPorCliente(cliente);
	}

	public BigDecimal getTotalPedidosEmitidosPorClienteDinheiro() {
		return clientes.getTotalPedidosEmitidosDinheiro(cliente);
	}

	public BigDecimal getTotalContasReceberVencer() {
		return clientes.getTotalContasReceberVencer(cliente);
	}

	public BigDecimal getTotalContasReceberVencidas() {
		return clientes.getTotalContasReceberVencidas(cliente);
	}

	public BigDecimal getContasReceberPagas() {
		return clientes.getTotalContasReceberPagas(cliente);
	}

	public BigDecimal getTotalLimite() {
		return clientes.getTotalLimite(cliente);
	}

	public BigDecimal getTotalLimiteUsado() {
		return clientes.getTotalLimiteUsado(cliente);
	}

	public BigDecimal getTotalLimiteDisponivel() {
		return clientes.getTotalLimiteDisponivel(cliente);
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<Pedido> getHistoricoPedidosClientes() {
		return historicoPedidosClientes;
	}

	public void setHistoricoPedidosClientes(List<Pedido> historicoPedidosClientes) {
		this.historicoPedidosClientes = historicoPedidosClientes;
	}

	public boolean isEditando() {
		return cliente != null && cliente.getId() == null;
	}

	public boolean isEditandoEndereco() {
		return editandoEndereco;
	}

	public TipoPessoa[] getTipos() {
		return TipoPessoa.values();
	}

	public HistoricoFilter getHistoricoFiltro() {
		return historicoFiltro;
	}

	public void setHistoricoFiltro(HistoricoFilter historicoFiltro) {
		this.historicoFiltro = historicoFiltro;
	}

}
