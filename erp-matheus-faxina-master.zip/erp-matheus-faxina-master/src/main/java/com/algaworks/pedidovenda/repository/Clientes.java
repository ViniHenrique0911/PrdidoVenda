package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Cidade;
import com.algaworks.pedidovenda.model.Cliente;
import com.algaworks.pedidovenda.model.Pedido;
import com.algaworks.pedidovenda.repository.filter.ClienteFilter;
import com.algaworks.pedidovenda.repository.filter.ClientePedidoFilter;
import com.algaworks.pedidovenda.repository.filter.HistoricoFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Clientes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;
	
	public List<Cliente> todosClientes() {
		return this.manager.createQuery("from Cliente", Cliente.class).getResultList();
	}

	public Cliente porId(Long id) {
		return this.manager.find(Cliente.class, id);
	}

	public List<Cliente> filtradosPedidos(ClientePedidoFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Cliente> criteriaQuery = builder.createQuery(Cliente.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Cliente> clienteRoot = criteriaQuery.from(Cliente.class);

		if (StringUtils.isNotBlank(filtro.getCpf())) {
			predicates.add(
					builder.equal(clienteRoot.get("documentoReceitaFederal"), filtro.getCpf()));
		}

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(clienteRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(clienteRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(clienteRoot.get("nome")));

		TypedQuery<Cliente> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public List<Cliente> porNome(String nome) {
		return this.manager
				.createQuery("from Cliente " + "where upper(nome) like :nome and tipo = 'FISICA' and ativo = 1",
						Cliente.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
	
	public List<Cliente> porNomeJuridica(String nome) {
		return this.manager
				.createQuery("from Cliente " + "where upper(nome) like :nome and tipo = 'JURIDICA' and ativo = 1",
						Cliente.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Pedido> pedidosPorCliente(Long id) {
		return this.manager.createQuery("from Pedido where cliente.id = :id", Pedido.class).setParameter("id", id)
				.getResultList();
	}

	public List<Cliente> porCpf(String cpf) {
		return this.manager
				.createQuery("from Cliente " + "where upper(documentoReceitaFederal) like :nome and tipo = 'FISICA'",
						Cliente.class)
				.setParameter("documentoReceitaFederal", cpf.toUpperCase() + "%").getResultList();
	}

	public List<Cidade> porCidade(String nome) {
		return this.manager.createQuery("from Cidade where upper(nome) like :nome", Cidade.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<Cliente> filtrados(ClienteFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Cliente> criteriaQuery = builder.createQuery(Cliente.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Cliente> clienteRoot = criteriaQuery.from(Cliente.class);

		if (StringUtils.isNotBlank(filtro.getDocumentoReceitaFederal())) {
			predicates.add(
					builder.equal(clienteRoot.get("documentoReceitaFederal"), filtro.getDocumentoReceitaFederal()));
		}

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(clienteRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(clienteRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(clienteRoot.get("nome")));

		TypedQuery<Cliente> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public List<Pedido> filtrarHistorico(HistoricoFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Pedido> criteriaQuery = builder.createQuery(Pedido.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Pedido> clienteRoot = criteriaQuery.from(Pedido.class);

		if (filtro.getDataDe() != null) {
			predicates.add(builder.greaterThanOrEqualTo(clienteRoot.get("dataCriacao"), filtro.getDataDe()));
		}

		if (filtro.getDataAte() != null) {
			predicates.add(builder.lessThanOrEqualTo(clienteRoot.get("dataCriacao"), filtro.getDataAte()));
		}
		
		criteriaQuery.select(clienteRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(clienteRoot.get("nome")));

		TypedQuery<Pedido> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}
	
	public Cliente guardar(Cliente cliente) {
		return manager.merge(cliente);
	}

	@Transactional
	public void remover(Cliente cliente) throws NegocioException {
		try {
			cliente = porId(cliente.getId());
			manager.remove(cliente);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Cliente não pode ser excluído.");
		}
	}

	public Long getTotalPedidosEmitidosPorCliente(Cliente cliente) {
		return (Long) manager.createQuery("select count(id) from Pedido where status = 'EMITIDO' and cliente.id = :num")
				.setParameter("num", cliente.getId()).getSingleResult();
	}

	public BigDecimal getTotalPedidosEmitidosDinheiro(Cliente cliente) {
		return (BigDecimal) manager
				.createQuery("select sum(valorTotal) from Pedido where status = 'EMITIDO' and cliente.id = :num")
				.setParameter("num", cliente.getId()).getSingleResult();
	}

	public BigDecimal getTotalContasReceberVencer(Cliente cliente) {
		return (BigDecimal) manager.createQuery(
				"select sum(valorPagamento) from ContasReceber where status = 'A_RECEBER' and cliente.id = :num")
				.setParameter("num", cliente.getId()).getSingleResult();
	}

	public BigDecimal getTotalContasReceberPagas(Cliente cliente) {
		return (BigDecimal) manager.createQuery(
				"select sum(valorRecebimento) from ContasReceber where status = 'RECEBIDO' and cliente.id = :num")
				.setParameter("num", cliente.getId()).getSingleResult();
	}

	public BigDecimal getTotalContasReceberVencidas(Cliente cliente) {
		return (BigDecimal) manager.createQuery(
				"select sum(valorRecebimento) from ContasReceber where status = 'CANCELADO' and cliente.id = :num")
				.setParameter("num", cliente.getId()).getSingleResult();
	}

	public BigDecimal getTotalLimite(Cliente cliente) {
		return (BigDecimal) manager.createQuery("select sum(limite) from Cliente where id = :num")
				.setParameter("num", cliente.getId()).getSingleResult();
	}

	public BigDecimal getTotalLimiteUsado(Cliente cliente) {
		return (BigDecimal) manager
				.createQuery("select sum(valorTotal) from Pedido where status = 'EMITIDO' and cliente.id = :num")
				.setParameter("num", cliente.getId()).getSingleResult();
	}

	public BigDecimal getTotalLimiteDisponivel(Cliente cliente) {
		return (BigDecimal) manager
				.createQuery(
						"select max(cli.limite) - min(ped.valorTotal) from Cliente cli, Pedido ped where cli.id = :num")
				.setParameter("num", cliente.getId()).getSingleResult();
	}

}