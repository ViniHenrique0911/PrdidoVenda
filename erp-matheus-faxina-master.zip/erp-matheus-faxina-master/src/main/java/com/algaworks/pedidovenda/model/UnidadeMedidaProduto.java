package com.algaworks.pedidovenda.model;

public enum UnidadeMedidaProduto {

	CAIXA("Caixa"),
	LOUNGE("Lounge"),
	MIX("Mix"),
	UNIDADE("Unidade"),
	KILOGRAMA("Kilograma");
	
	private String descricao;
	
	UnidadeMedidaProduto(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}
	
}
