package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Preparar;
import com.algaworks.pedidovenda.repository.Preparars;
import com.algaworks.pedidovenda.repository.filter.PrepararFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaPrepararBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Preparars preparars;

	private PrepararFilter filtro;
	private List<Preparar> prepararsFiltrados;
	private List<Preparar> preparadoFiltrados;
	private List<Preparar> entregueFiltrados;

	private Preparar preparar;

	private Preparar prepararSelecionado;

	public PesquisaPrepararBean() {
		filtro = new PrepararFilter();
	}

	public void pesquisar() {
		prepararsFiltrados = preparars.filtrados(filtro);
		preparadoFiltrados = preparars.preparados(filtro);
		entregueFiltrados = preparars.entregues(filtro);
	}

	public void excluir() {
		try {
			preparars.remover(prepararSelecionado);
			prepararsFiltrados.remove(prepararSelecionado);

			FacesUtil.addInfoMessage("Preparar do cliente " + prepararSelecionado.getPedido().getCliente().getNome()
					+ " foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public List<Preparar> getPrepararsFiltrados() {
		return prepararsFiltrados;
	}

	public PrepararFilter getFiltro() {
		return filtro;
	}

	public Preparar getPrepararSelecionado() {
		return prepararSelecionado;
	}

	public void setPrepararSelecionado(Preparar prepararSelecionado) {
		this.prepararSelecionado = prepararSelecionado;
	}

	public List<Preparar> getPreparadoFiltrados() {
		return preparadoFiltrados;
	}

	public void setPreparadoFiltrados(List<Preparar> preparadoFiltrados) {
		this.preparadoFiltrados = preparadoFiltrados;
	}

	public List<Preparar> getEntregueFiltrados() {
		return entregueFiltrados;
	}

	public void setEntregueFiltrados(List<Preparar> entregueFiltrados) {
		this.entregueFiltrados = entregueFiltrados;
	}

	public void setPrepararsFiltrados(List<Preparar> prepararsFiltrados) {
		this.prepararsFiltrados = prepararsFiltrados;
	}

	public Preparar getPreparar() {
		return preparar;
	}

}
