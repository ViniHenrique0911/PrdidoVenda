package com.algaworks.pedidovenda.model;

public enum StatusContasPagar {
	
	CANCELADO("Cancelado"),
	PAGO("Pago"),
	PAGO_PARCIALMENTE("Pago Parcialmente"),
	A_PAGAR("A Pagar");
	
	private String descricao;
	
	StatusContasPagar(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

}
