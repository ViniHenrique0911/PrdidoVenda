package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.primefaces.event.SelectEvent;

import com.algaworks.pedidovenda.model.Cliente;
import com.algaworks.pedidovenda.model.Devolucao;
import com.algaworks.pedidovenda.model.ItemDevolucao;
import com.algaworks.pedidovenda.model.Pedido;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.model.Usuario;
import com.algaworks.pedidovenda.repository.Clientes;
import com.algaworks.pedidovenda.repository.Devolucoes;
import com.algaworks.pedidovenda.repository.Produtos;
import com.algaworks.pedidovenda.repository.Usuarios;
import com.algaworks.pedidovenda.service.CadastroDevolucaoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;
import com.algaworks.pedidovenda.validation.SKU;

@Named
@ViewScoped
public class CadastroDevolucaoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Usuarios usuarios;

	@Inject
	private Clientes clientes;

	@Inject
	private Produtos produtos;

	@Inject
	private CadastroDevolucaoService cadastroDevolucaoService;

	@Inject
	private Devolucoes devolucoes;

	private String sku;

	private String nome;

	@Produces
	@DevolucaoEdicao
	private Devolucao devolucao;

	private List<Usuario> vendedores;

	private List<Pedido> pedidos;

	private Produto produtoLinhaEditavel;

	private Cliente clienteSelecionado;

	public CadastroDevolucaoBean() {
		limpar();
	}

	public void inicializar() {
		if (this.devolucao == null) {
			limpar();
		}

		this.pedidos = this.devolucoes.pedidos();

		this.vendedores = this.usuarios.vendedores();

		this.devolucao.adicionarItemVazio();

		this.recalcularDevolucao();
	}

	private void limpar() {
		devolucao = new Devolucao();
	}

	public List<Pedido> completarPedido(String nome) {
		return this.devolucoes.porPedido(nome);
	}

	public void devolucaoAlterado(@Observes DevolucaoAlteradoEvent event) {
		this.devolucao = event.getDevolucao();
	}

	public void salvar() {
		this.devolucao.removerItemVazio();

		try {
			this.devolucao = this.cadastroDevolucaoService.salvar(this.devolucao);

			FacesUtil.addInfoMessage("Devolução foi salva com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		} finally {
			this.devolucao.adicionarItemVazio();
		}
	}

	public void recalcularDevolucao() {
		if (this.devolucao != null) {
			this.devolucao.recalcularValorTotal();
		}
	}

	public void carregarProdutoPorSku() {
		if (StringUtils.isNotEmpty(this.sku)) {
			this.produtoLinhaEditavel = this.produtos.porSku(this.sku);
			this.carregarProdutoLinhaEditavel();
		}
	}

	public void carregarProdutoLinhaEditavel() {
		ItemDevolucao item = this.devolucao.getItens().get(0);

		if (this.produtoLinhaEditavel != null) {
			if (this.existeItemComProduto(this.produtoLinhaEditavel)) {
				FacesUtil.addErrorMessage("Já existe um item no devolucao com o produto informado.");
			} else {
				item.setProduto(produtoLinhaEditavel);
				item.setValorUnitario(produtoLinhaEditavel.getValorUnitario());

				this.devolucao.adicionarItemVazio();
				this.produtoLinhaEditavel = null;
				this.sku = null;

				this.devolucao.recalcularValorTotal();

			}
		}
	}

	private boolean existeItemComProduto(Produto produto) {
		boolean existeItem = false;

		for (ItemDevolucao item : this.getDevolucao().getItens()) {
			if (produto.equals(item.getProduto())) {
				existeItem = true;
				break;
			}
		}

		return existeItem;
	}

	public List<Produto> completarProduto(String nome) {
		return this.produtos.porNome(nome);
	}

	public void clienteSelecionado(SelectEvent event) {
		devolucao.setCliente((Cliente) event.getObject());
	}

	public void atualizarQuantidade(ItemDevolucao item, Float linha) {
		if (item.getQuantidade() < 1.0) {
			if (linha == 0) {
				item.setQuantidade((float) 1.0);
			} else {
				this.getDevolucao().getItens().remove(linha);
			}
		}

		this.devolucao.recalcularValorTotal();
	}

	public List<Cliente> completarCliente(String nome) {
		return this.clientes.porNome(nome);
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public List<Usuario> getVendedores() {
		return vendedores;
	}

	public List<Pedido> getPedidosDevolucao() {
		return pedidos;
	}

	public boolean isEditando() {
		return this.devolucao.getId() != null;
	}

	public Produto getProdutoLinhaEditavel() {
		return produtoLinhaEditavel;
	}

	public void setProdutoLinhaEditavel(Produto produtoLinhaEditavel) {
		this.produtoLinhaEditavel = produtoLinhaEditavel;
	}

	@SKU
	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	@NotBlank
	public String getNomeCliente() {
		return devolucao.getCliente() == null ? null : devolucao.getCliente().getNome();
	}

	public void setNomeCliente(String nome) {
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Cliente getClienteSelecionado() {
		return clienteSelecionado;
	}

	public void setClienteSelecionado(Cliente clienteSelecionado) {
		this.clienteSelecionado = clienteSelecionado;
	}

}