package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Compra;
import com.algaworks.pedidovenda.model.ItemCompra;
import com.algaworks.pedidovenda.repository.Compras;
import com.algaworks.pedidovenda.security.UsuarioLogado;
import com.algaworks.pedidovenda.security.UsuarioSistema;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class EstoqueCompraService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Compras compras;

	@Inject
	@UsuarioLogado
	private UsuarioSistema usuarioSistema;

	public void baixarItensEstoque(Compra pedido) throws NegocioException {
		pedido = this.compras.porId(pedido.getId());

		for (ItemCompra item : pedido.getItens()) {
			item.getProduto().aumentarEstoque(item.getQuantidade());
		}
	}

	public void retornarItensEstoque(Compra pedido) {
		pedido = this.compras.porId(pedido.getId());

		for (ItemCompra item : pedido.getItens()) {
			item.getProduto().adicionarEstoque(item.getQuantidade());
		}
	}

}
