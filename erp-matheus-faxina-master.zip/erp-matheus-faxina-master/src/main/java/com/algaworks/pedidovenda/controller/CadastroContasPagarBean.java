package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.ContasPagar;
import com.algaworks.pedidovenda.service.CadastroContasPagarService;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroContasPagarBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private ContasPagar receber;

	@Inject
	private CadastroContasPagarService cadastroContasPagarService;

	public void inicializar() {
		if (receber == null) {
			limpar();
		}
		
		this.recalcularValor();
	}

	public void limpar() {
		this.receber = new ContasPagar();
	}

	public void salvar() {
		try {
			cadastroContasPagarService.salvar(receber);
			FacesUtil.addInfoMessage("Contas a pagar foi salvo com sucesso!");
			limpar();
		} catch (Exception e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public void recalcularValor() {
		if (this.receber != null) {
			this.receber.recalcularValorTotal();
		}
	}
	
	public void recalcularDesconto() {
		if (this.receber != null) {
			this.receber.recalcularDesconto();
		}
	}
	
	public void recalcularJuros() {
		if (this.receber != null) {
			this.receber.recalcularJuros();
		}
	}

	public ContasPagar getReceber() {
		return receber;
	}

	public void setReceber(ContasPagar receber) {
		this.receber = receber;
	}

	public boolean isEditando() {
		return receber != null && receber.getId() == null;
	}

}
