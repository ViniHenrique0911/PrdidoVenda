package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Preparar;
import com.algaworks.pedidovenda.repository.Preparars;
import com.algaworks.pedidovenda.service.CadastroPrepararService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroPrepararBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Preparar preparar;

	@Inject
	private Preparars preparars;

	@Inject
	private CadastroPrepararService cadastroPrepararService;

	public void inicializar() {
		if (preparar == null) {
			limpar();
		}
	}

	public void limpar() {
		this.preparar = new Preparar();
	}
	
	public void salvar() {
		try {
			cadastroPrepararService.salvar(preparar);
			limpar();
			FacesUtil.addInfoMessage("Preparar foi salvo com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public Preparar getPreparar() {
		return preparar;
	}

	public void setPreparar(Preparar preparar) {
		this.preparar = preparar;
	}

	public boolean isEditando() {
		return preparar != null && preparar.getId() == null;
	}

}
