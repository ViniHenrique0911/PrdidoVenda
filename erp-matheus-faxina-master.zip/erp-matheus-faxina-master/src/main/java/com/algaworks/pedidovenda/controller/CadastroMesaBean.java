package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Mesa;
import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.repository.Mesas;
import com.algaworks.pedidovenda.service.CadastroMesaService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroMesaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Mesa mesa;
	
	@Inject
	private Mesas mesas;
	
	@Inject
	private CadastroMesaService cadastroMesaService;
	
	public void inicializar(){
		if (mesa == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.mesa = new Mesa();
	}
	
	public void salvar() {
		try {
			cadastroMesaService.salvar(mesa);
			limpar();
			
			FacesUtil.addInfoMessage("Mesa foi salva com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public Mesa getMesa() {
		return mesa;
	}
	
	public void setMesa(Mesa mesa) {
		this.mesa = mesa;
	}
	
	public boolean isEditando() {
		return mesa != null && mesa.getId() == null;
	}
	
}
