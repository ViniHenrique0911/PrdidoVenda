package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Preparar;
import com.algaworks.pedidovenda.repository.Preparars;

@FacesConverter(forClass = Preparar.class)
public class PrepararConverter implements Converter {

	@Inject
	private Preparars preparars;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Preparar retorno = null;
		
		if (StringUtils.isNotEmpty(value)) {
			Long id = new Long(value);
			retorno = preparars.porId(id);
		}
		
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			Preparar preparar = (Preparar) value;
			return preparar.getId() == null ? null : preparar.getId().toString();
		}
		
		return "";
	}

}
