package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.AberturaCaixa;
import com.algaworks.pedidovenda.model.Usuario;
import com.algaworks.pedidovenda.repository.AberturaCaixas;
import com.algaworks.pedidovenda.repository.Usuarios;
import com.algaworks.pedidovenda.service.CadastroAberturaCaixaService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroAberturaCaixaBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private AberturaCaixa aberturaCaixa;

	@Inject
	private AberturaCaixas aberturaCaixas;

	@Inject
	private CadastroAberturaCaixaService cadastroAberturaCaixaService;

	private List<Usuario> listUsuarios;

	@Inject
	private Usuarios usuarios;

	public void inicializar() {
		this.listUsuarios = usuarios.vendedores();
		if (aberturaCaixa == null) {
			limpar();
		}
	}

	public void limpar() {
		this.aberturaCaixa = new AberturaCaixa();
	}

	public void salvar() {
		try {
			cadastroAberturaCaixaService.salvar(aberturaCaixa);
			limpar();

			FacesUtil.addInfoMessage("Abertura de caixa foi salvo com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public AberturaCaixa getAberturaCaixa() {
		return aberturaCaixa;
	}

	public void setAberturaCaixa(AberturaCaixa aberturaCaixa) {
		this.aberturaCaixa = aberturaCaixa;
	}

	public boolean isEditando() {
		return aberturaCaixa != null && aberturaCaixa.getId() == null;
	}

	public List<Usuario> getListUsuarios() {
		return listUsuarios;
	}

	public void setListUsuarios(List<Usuario> listUsuarios) {
		this.listUsuarios = listUsuarios;
	}

}
