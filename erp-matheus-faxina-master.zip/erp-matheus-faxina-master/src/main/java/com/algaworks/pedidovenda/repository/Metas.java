package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.algaworks.pedidovenda.model.Meta;
import com.algaworks.pedidovenda.model.Usuario;
import com.algaworks.pedidovenda.repository.filter.MetaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Metas implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Meta porId(Long id) {
		return this.manager.find(Meta.class, id);
	}

	public List<Meta> porNome(String vendedor) {
		return this.manager.createQuery("from Meta " + "where upper(vendedor) like :vendedor", Meta.class)
				.setParameter("vendedor", vendedor.toUpperCase() + "%").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Meta> filtrados(MetaFilter filtro) {
		Session session = this.manager.unwrap(Session.class);

		Criteria criteria = session.createCriteria(Meta.class)
				// fazemos uma associação (join) com usuario e nomeamos como "u"
				.createAlias("vendedor", "u");

		if (StringUtils.isNotBlank(filtro.getVendedor())) {
			// acessamos o nome do cliente associado ao pedido pelo alias "c", criado
			// anteriormente
			criteria.add(Restrictions.ilike("u.nome", filtro.getVendedor(), MatchMode.ANYWHERE));
		}

		return criteria.addOrder(Order.asc("id")).list();
	}

	public Meta guardar(Meta meta) {
		return manager.merge(meta);
	}

	@Transactional
	public void remover(Meta meta) throws NegocioException {
		try {
			meta = porId(meta.getId());
			manager.remove(meta);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Meta não pode ser excluído.");
		}
	}

	public List<Usuario> porUsuario(String nome) {
		return this.manager.createQuery("from Usuario where upper(nome) like :nome", Usuario.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}
}