package com.algaworks.pedidovenda.model;

public enum StatusDevolucao {

	NAO_DEVOLVIDA("Não devolvida"), 
	DEVOLVIDA("Devolvida"),
	CANCELADO("Cancelado");
	
	private String descricao;
	
	StatusDevolucao(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}
	
}
