package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.AberturaCaixa;
import com.algaworks.pedidovenda.repository.AberturaCaixas;

@FacesConverter(forClass = AberturaCaixa.class)
public class AberturaCaixaConverter implements Converter {

	@Inject
	private AberturaCaixas aberturaCaixas;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		AberturaCaixa retorno = null;
		
		if (StringUtils.isNotEmpty(value)) {
			Long id = new Long(value);
			retorno = aberturaCaixas.porId(id);
		}
		
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			AberturaCaixa aberturaCaixa = (AberturaCaixa) value;
			return aberturaCaixa.getId() == null ? null : aberturaCaixa.getId().toString();
		}
		
		return "";
	}

}
