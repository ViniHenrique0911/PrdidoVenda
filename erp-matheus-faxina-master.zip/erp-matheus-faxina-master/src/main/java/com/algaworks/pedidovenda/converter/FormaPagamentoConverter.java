package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.FormaPagamentoo;
import com.algaworks.pedidovenda.repository.FormaPagamentos;

@FacesConverter(forClass = FormaPagamentoo.class)
public class FormaPagamentoConverter implements Converter {

	@Inject
	private FormaPagamentos formaPagamentos;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		FormaPagamentoo retorno = null;

		if (StringUtils.isNotEmpty(value)) {
			Long id = new Long(value);
			retorno = formaPagamentos.porId(id);
		}

		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			FormaPagamentoo cidade = (FormaPagamentoo) value;
			return cidade.getId() == null ? null : cidade.getId().toString();
		}

		return "";
	}

}
