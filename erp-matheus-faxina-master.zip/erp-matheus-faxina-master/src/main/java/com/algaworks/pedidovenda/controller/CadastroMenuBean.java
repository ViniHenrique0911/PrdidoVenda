package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Menu;
import com.algaworks.pedidovenda.repository.Menus;
import com.algaworks.pedidovenda.service.CadastroMenuService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroMenuBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Menu menu;

	@Inject
	private Menus menus;

	private List<Menu> listaMenus;

	@Inject
	private CadastroMenuService cadastroMenuService;

	public void inicializar() {
		if (menu == null) {
			limpar();
		}
		
		this.listaMenus = this.menus.menusPais();
	}

	public List<Menu> getMenus() {
		return listaMenus;
	}

	public void limpar() {
		this.menu = new Menu();
	}

	public void salvar() {
		try {
			cadastroMenuService.salvar(menu);
			limpar();

			FacesUtil.addInfoMessage("Menu foi salvo com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public boolean isEditando() {
		return menu != null && menu.getId() == null;
	}

	public List<Menu> getListaMenus() {
		return listaMenus;
	}

	public void setListaMenus(List<Menu> listaMenus) {
		this.listaMenus = listaMenus;
	}

}
