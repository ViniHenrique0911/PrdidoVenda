package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.FormaPagamentoo;
import com.algaworks.pedidovenda.repository.FormaPagamentos;
import com.algaworks.pedidovenda.repository.filter.FormaPagamentoFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaFormaPagamentosBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private FormaPagamentos formaPagamentos;

	private FormaPagamentoFilter filtro;
	private List<FormaPagamentoo> formaPagamentosFiltrados;

	private FormaPagamentoo formaPagamentoSelecionado;

	public PesquisaFormaPagamentosBean() {
		filtro = new FormaPagamentoFilter();
	}

	public void pesquisar() {
		formaPagamentosFiltrados = formaPagamentos.filtrados(filtro);
	}

	public void excluir() {
		try {
			formaPagamentos.remover(formaPagamentoSelecionado);
			formaPagamentosFiltrados.remove(formaPagamentoSelecionado);

			FacesUtil.addInfoMessage(
					"Forma de pagamento " + formaPagamentoSelecionado.getNome() + " foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public FormaPagamentoFilter getFiltro() {
		return filtro;
	}

	public void setFiltro(FormaPagamentoFilter filtro) {
		this.filtro = filtro;
	}

	public List<FormaPagamentoo> getFormaPagamentosFiltrados() {
		return formaPagamentosFiltrados;
	}

	public void setFormaPagamentosFiltrados(List<FormaPagamentoo> formaPagamentosFiltrados) {
		this.formaPagamentosFiltrados = formaPagamentosFiltrados;
	}

	public FormaPagamentoo getFormaPagamentoSelecionado() {
		return formaPagamentoSelecionado;
	}

	public void setFormaPagamentoSelecionado(FormaPagamentoo formaPagamentoSelecionado) {
		this.formaPagamentoSelecionado = formaPagamentoSelecionado;
	}

}
