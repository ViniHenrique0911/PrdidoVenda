package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.Locale;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.velocity.tools.generic.NumberTool;

import com.algaworks.pedidovenda.model.Devolucao;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;
import com.algaworks.pedidovenda.util.mail.Mailer;
import com.outjected.email.api.MailMessage;
import com.outjected.email.impl.templating.velocity.VelocityTemplate;

@Named
@RequestScoped
public class EnvioDevolucaoEmailBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Mailer mailer;

	@Inject
	@DevolucaoEdicao
	private Devolucao devolucao;

	public void enviarDevolucao() {
		MailMessage message = mailer.novaMensagem();

		message.to(this.devolucao.getCliente().getEmail()).subject("Devolucao " + this.devolucao.getId())
				.bodyHtml(new VelocityTemplate(getClass().getResourceAsStream("/emails/devolucao.template")))
				.put("devolucao", this.devolucao).put("numberTool", new NumberTool())
				.put("locale", new Locale("pt", "BR")).send();

		FacesUtil.addInfoMessage("Devolução foi enviado por e-mail com sucesso!");
	}

}
