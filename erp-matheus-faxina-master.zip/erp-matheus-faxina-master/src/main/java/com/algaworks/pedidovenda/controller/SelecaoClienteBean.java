package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import com.algaworks.pedidovenda.model.Cliente;
import com.algaworks.pedidovenda.repository.Clientes;
import com.algaworks.pedidovenda.repository.filter.ClientePedidoFilter;

@Named
@ViewScoped
public class SelecaoClienteBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Clientes clientes;

	private List<Cliente> clientesFiltrados;

	private ClientePedidoFilter filtro;

	private SelecaoClienteBean() {
		filtro = new ClientePedidoFilter();
	}

	/*
	 * public void pesquisar() { clientesFiltrados = clientes.porNome(nome); }
	 */

	public void pesquisar() {
		clientesFiltrados = clientes.filtradosPedidos(filtro);
	}

	public void selecionar(Cliente cliente) {
		RequestContext.getCurrentInstance().closeDialog(cliente);
	}

	public void abrirDialogo() {
		Map<String, Object> opcoes = new HashMap<>();
		opcoes.put("modal", true);

		RequestContext.getCurrentInstance().openDialog("/dialogos/SelecaoCliente", opcoes, null);
	}

	public List<Cliente> getClientesFiltrados() {
		return clientesFiltrados;
	}

	public ClientePedidoFilter getFiltro() {
		return filtro;
	}

	public void setFiltro(ClientePedidoFilter filtro) {
		this.filtro = filtro;
	}
}