package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.ContasReceber;
import com.algaworks.pedidovenda.model.Pedido;
import com.algaworks.pedidovenda.model.StatusContasReceber;
import com.algaworks.pedidovenda.repository.Pedidos;
import com.algaworks.pedidovenda.service.CancelamentoPedidoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@RequestScoped
public class CancelamentoPedidoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CancelamentoPedidoService cancelamentoPedidoService;

	@Inject
	private Event<PedidoAlteradoEvent> pedidoAlteradoEvent;

	@Inject
	@PedidoEdicao
	private Pedido pedido;

	@Inject
	private Pedidos pedidos;

	public void cancelarPedido() {
		try {
			this.pedido = this.cancelamentoPedidoService.cancelar(this.pedido);
			this.pedidoAlteradoEvent.fire(new PedidoAlteradoEvent(this.pedido));
			cancelaContasReceber();
			
			FacesUtil.addInfoMessage("Pedido foi cancelado com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		}
	}

	public void cancelaContasReceber() {
		for (ContasReceber contasReceber : pedido.getContasRecebers()) {
			try {
				contasReceber.setStatus(StatusContasReceber.CANCELADO);
				cancelamentoPedidoService.salvarSemIf(contasReceber);
			} catch (NegocioException e) {
				e.printStackTrace();
			}
		}
	}
}
