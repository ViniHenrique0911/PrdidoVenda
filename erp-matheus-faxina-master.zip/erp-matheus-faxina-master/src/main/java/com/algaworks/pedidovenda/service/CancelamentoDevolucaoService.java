package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.ContasReceber;
import com.algaworks.pedidovenda.model.Devolucao;
import com.algaworks.pedidovenda.model.StatusDevolucao;
import com.algaworks.pedidovenda.repository.ContasRecebers;
import com.algaworks.pedidovenda.repository.Devolucoes;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CancelamentoDevolucaoService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Devolucoes devolucoes;
	
	@Inject
	private EstoqueDevolucaoService estoqueDevolucaoService;
	
	@Inject
	private ContasRecebers contasRecebers;
	
	@Transactional
	public ContasReceber salvarSemIf(ContasReceber contasReceber) throws NegocioException {
		return contasRecebers.guardar(contasReceber);
	}
	
	@Transactional
	public Devolucao cancelar(Devolucao devolucao) throws NegocioException {
		devolucao = this.devolucoes.porId(devolucao.getId());
		
		if (devolucao.isNaoCancelavel()) {
			throw new NegocioException("Devolucao não pode ser cancelado no status "
					+ devolucao.getStatus().getDescricao() + ".");
		}
		
		if (devolucao.isDevolvida()) {
			this.estoqueDevolucaoService.retornarItensEstoque(devolucao);
		}
		
		devolucao.setStatus(StatusDevolucao.CANCELADO);
		
		devolucao = this.devolucoes.guardar(devolucao);
		
		return devolucao;
	}
	
}