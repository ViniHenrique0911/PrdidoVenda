package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Menu;
import com.algaworks.pedidovenda.repository.Menus;

@FacesConverter(forClass = Menu.class)
public class MenuConverter implements Converter {

	@Inject
	private Menus menus;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Menu retorno = null;
		
		if (StringUtils.isNotEmpty(value)) {
			Long id = new Long(value);
			retorno = menus.porId(id);
		}
		
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			Menu menu = (Menu) value;
			return menu.getId() == null ? null : menu.getId().toString();
		}
		
		return "";
	}

}