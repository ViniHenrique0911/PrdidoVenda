package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.AberturaCaixa;
import com.algaworks.pedidovenda.repository.AberturaCaixas;
import com.algaworks.pedidovenda.repository.filter.AberturaCaixaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaAberturaCaixasBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private AberturaCaixas aberturaAberturaCaixas;

	private AberturaCaixaFilter filtro;
	private List<AberturaCaixa> aberturaAberturaCaixasFiltrados;

	private AberturaCaixa aberturaAberturaCaixaSelecionado;

	public PesquisaAberturaCaixasBean() {
		filtro = new AberturaCaixaFilter();
	}

	public void pesquisar() {
		aberturaAberturaCaixasFiltrados = aberturaAberturaCaixas.filtrados(filtro);
	}

	public void excluir() {
		try {
			aberturaAberturaCaixas.remover(aberturaAberturaCaixaSelecionado);
			aberturaAberturaCaixasFiltrados.remove(aberturaAberturaCaixaSelecionado);

			FacesUtil.addInfoMessage(
					"Abertura de caixa do usuário" + aberturaAberturaCaixaSelecionado.getUsuario().getNome() + " foi excluída com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public List<AberturaCaixa> getAberturaCaixasFiltrados() {
		return aberturaAberturaCaixasFiltrados;
	}

	public AberturaCaixaFilter getFiltro() {
		return filtro;
	}

	public AberturaCaixa getAberturaCaixaSelecionado() {
		return aberturaAberturaCaixaSelecionado;
	}

	public void setAberturaCaixaSelecionado(AberturaCaixa aberturaAberturaCaixaSelecionado) {
		this.aberturaAberturaCaixaSelecionado = aberturaAberturaCaixaSelecionado;
	}

}
