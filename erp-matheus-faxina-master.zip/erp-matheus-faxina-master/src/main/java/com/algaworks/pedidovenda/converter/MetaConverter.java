package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Meta;
import com.algaworks.pedidovenda.repository.Metas;

@FacesConverter(forClass = Meta.class)
public class MetaConverter implements Converter {

	@Inject
	private Metas metas;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Meta retorno = null;
		
		if (StringUtils.isNotEmpty(value)) {
			Long id = new Long(value);
			retorno = metas.porId(id);
		}
		
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			Meta meta = (Meta) value;
			return meta.getId() == null ? null : meta.getId().toString();
		}
		
		return "";
	}

}
