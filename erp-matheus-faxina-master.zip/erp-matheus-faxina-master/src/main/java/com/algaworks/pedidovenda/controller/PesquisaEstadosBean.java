package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.repository.Estados;
import com.algaworks.pedidovenda.repository.filter.EstadoFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaEstadosBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private Estados estados;
	
	private EstadoFilter filtro;
	private List<Estado> estadosFiltrados;
	
	private Estado estadoSelecionado;
	
	public PesquisaEstadosBean() {
		filtro = new EstadoFilter();
	}
	
	public void pesquisar() {
		estadosFiltrados = estados.filtrados(filtro);
	}
	
	public void excluir() {
		try {
			estados.remover(estadoSelecionado);
			estadosFiltrados.remove(estadoSelecionado);
			
			FacesUtil.addInfoMessage("Estado " + estadoSelecionado.getNome() + 
					" foi excluído com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public List<Estado> getEstadosFiltrados() {
		return estadosFiltrados;
	}

	public EstadoFilter getFiltro() {
		return filtro;
	}

	public Estado getEstadoSelecionado() {
		return estadoSelecionado;
	}

	public void setEstadoSelecionado(Estado estadoSelecionado) {
		this.estadoSelecionado = estadoSelecionado;
	}
	
}
