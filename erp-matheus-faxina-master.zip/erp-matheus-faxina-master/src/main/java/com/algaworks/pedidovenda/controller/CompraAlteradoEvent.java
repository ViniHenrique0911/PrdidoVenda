package com.algaworks.pedidovenda.controller;

import com.algaworks.pedidovenda.model.Compra;

public class CompraAlteradoEvent {

	private Compra compra;
	
	public CompraAlteradoEvent(Compra compra) {
		this.compra = compra;
	}

	public Compra getCompra() {
		return compra;
	}
	
}
