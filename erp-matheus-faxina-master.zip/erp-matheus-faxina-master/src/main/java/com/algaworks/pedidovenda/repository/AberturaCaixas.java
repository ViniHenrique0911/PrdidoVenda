package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.AberturaCaixa;
import com.algaworks.pedidovenda.repository.filter.AberturaCaixaFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class AberturaCaixas implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public AberturaCaixa porId(Long id) {
		return this.manager.find(AberturaCaixa.class, id);
	}

	public List<AberturaCaixa> porNome(String nome) {
		return this.manager.createQuery("from AberturaCaixa " + "where upper(nome) like :nome", AberturaCaixa.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public List<AberturaCaixa> filtrados(AberturaCaixaFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<AberturaCaixa> criteriaQuery = builder.createQuery(AberturaCaixa.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<AberturaCaixa> aberturaCaixaRoot = criteriaQuery.from(AberturaCaixa.class);

		if (StringUtils.isNotEmpty(filtro.getNome())) {
			predicates.add(builder.like(builder.lower(aberturaCaixaRoot.get("nome")),
					"%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(aberturaCaixaRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(aberturaCaixaRoot.get("nome")));

		TypedQuery<AberturaCaixa> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public AberturaCaixa guardar(AberturaCaixa aberturaCaixa) {
		return manager.merge(aberturaCaixa);
	}

	@Transactional
	public void remover(AberturaCaixa aberturaCaixa) throws NegocioException {
		try {
			aberturaCaixa = porId(aberturaCaixa.getId());
			manager.remove(aberturaCaixa);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Abertura de caixa não pode ser excluído.");
		}
	}

}