package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Permissao;
import com.algaworks.pedidovenda.service.CadastroPermissaoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroPermissaoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Permissao permissao;
	
	@Inject
	private CadastroPermissaoService cadastroPermissaoService;
	
	public void inicializar(){
		if (permissao == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.permissao = new Permissao();
	}
	
	public void salvar() {
		try {
			cadastroPermissaoService.salvar(permissao);
			limpar();
			
			FacesUtil.addInfoMessage("Permisão foi salvo com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	
	public Permissao getPermissao() {
		return permissao;
	}
	
	public void setPermissao(Permissao permissao) {
		this.permissao = permissao;
	}
	
	public boolean isEditando() {
		return permissao != null && permissao.getId() == null;
	}
	
}
