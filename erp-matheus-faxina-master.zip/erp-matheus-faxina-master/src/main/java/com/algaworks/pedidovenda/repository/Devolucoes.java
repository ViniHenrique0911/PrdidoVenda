package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import com.algaworks.pedidovenda.model.Cliente;
import com.algaworks.pedidovenda.model.Devolucao;
import com.algaworks.pedidovenda.model.Pedido;
import com.algaworks.pedidovenda.model.Usuario;
import com.algaworks.pedidovenda.model.vo.DataValor;
import com.algaworks.pedidovenda.repository.filter.DevolucaoFilter;

public class Devolucoes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Map<Date, BigDecimal> valoresTotaisPorData(Integer numeroDeDias, Usuario criadoPor) {
		numeroDeDias -= 1;

		Calendar dataInicial = Calendar.getInstance();
		dataInicial = DateUtils.truncate(dataInicial, Calendar.DAY_OF_MONTH);
		dataInicial.add(Calendar.DAY_OF_MONTH, numeroDeDias * -1);

		Map<Date, BigDecimal> resultado = criarMapaVazio(numeroDeDias, dataInicial);

		String jpql = "select new com.algaworks.pedidovenda.model.vo.DataValor(date(p.dataCriacao), sum(p.valorTotal)) "
				+ "from Devolucao p where p.dataCriacao >= :dataInicial ";

		if (criadoPor != null) {
			jpql += "and p.vendedor = :vendedor ";
		}

		jpql += "group by date(dataCriacao)";

		TypedQuery<DataValor> query = manager.createQuery(jpql, DataValor.class);

		query.setParameter("dataInicial", dataInicial.getTime());

		if (criadoPor != null) {
			query.setParameter("vendedor", criadoPor);
		}

		List<DataValor> valoresPorData = query.getResultList();

		for (DataValor dataValor : valoresPorData) {
			resultado.put(dataValor.getData(), dataValor.getValor());
		}

		return resultado;
	}

	private Map<Date, BigDecimal> criarMapaVazio(Integer numeroDeDias, Calendar dataInicial) {
		dataInicial = (Calendar) dataInicial.clone();
		Map<Date, BigDecimal> mapaInicial = new TreeMap<>();

		for (int i = 0; i <= numeroDeDias; i++) {
			mapaInicial.put(dataInicial.getTime(), BigDecimal.ZERO);
			dataInicial.add(Calendar.DAY_OF_MONTH, 1);
		}

		return mapaInicial;
	}

	private List<Predicate> criarPredicatesParaFiltro(DevolucaoFilter filtro, Root<Devolucao> devolucaoRoot,
			From<?, ?> clienteJoin, From<?, ?> vendedorJoin) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		List<Predicate> predicates = new ArrayList<>();

		if (filtro.getNumeroDe() != null) {
			predicates.add(builder.greaterThanOrEqualTo(devolucaoRoot.get("id"), filtro.getNumeroDe()));
		}

		if (filtro.getNumeroAte() != null) {
			predicates.add(builder.lessThanOrEqualTo(devolucaoRoot.get("id"), filtro.getNumeroAte()));
		}

		if (filtro.getDataCriacaoDe() != null) {
			predicates.add(builder.greaterThanOrEqualTo(devolucaoRoot.get("dataCriacao"), filtro.getDataCriacaoDe()));
		}

		if (filtro.getDataCriacaoAte() != null) {
			predicates.add(builder.lessThanOrEqualTo(devolucaoRoot.get("dataCriacao"), filtro.getDataCriacaoAte()));
		}

		if (StringUtils.isNotBlank(filtro.getNomeCliente())) {
			predicates.add(builder.like(clienteJoin.get("nome"), "%" + filtro.getNomeCliente() + "%"));
		}

		if (StringUtils.isNotBlank(filtro.getNomeVendedor())) {
			predicates.add(builder.like(vendedorJoin.get("nome"), "%" + filtro.getNomeVendedor() + "%"));
		}

		if (filtro.getStatuses() != null && filtro.getStatuses().length > 0) {
			predicates.add(devolucaoRoot.get("status").in(Arrays.asList(filtro.getStatuses())));
		}

		return predicates;
	}

	public List<Devolucao> filtrados(DevolucaoFilter filtro) {
		From<?, ?> orderByFromEntity = null;

		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Devolucao> criteriaQuery = builder.createQuery(Devolucao.class);

		Root<Devolucao> devolucaoRoot = criteriaQuery.from(Devolucao.class);
		From<?, ?> clienteJoin = (From<?, ?>) devolucaoRoot.fetch("cliente", JoinType.INNER);
		From<?, ?> vendedorJoin = (From<?, ?>) devolucaoRoot.fetch("vendedor", JoinType.INNER);

		List<Predicate> predicates = criarPredicatesParaFiltro(filtro, devolucaoRoot, clienteJoin, vendedorJoin);

		criteriaQuery.select(devolucaoRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));

		if (filtro.getPropriedadeOrdenacao() != null) {
			String nomePropriedadeOrdenacao = filtro.getPropriedadeOrdenacao();
			orderByFromEntity = devolucaoRoot;

			if (filtro.getPropriedadeOrdenacao().contains(".")) {
				nomePropriedadeOrdenacao = nomePropriedadeOrdenacao
						.substring(filtro.getPropriedadeOrdenacao().indexOf(".") + 1);
			}

			if (filtro.getPropriedadeOrdenacao().startsWith("cliente.")) {
				orderByFromEntity = clienteJoin;
			}

			if (filtro.isAscendente() && filtro.getPropriedadeOrdenacao() != null) {
				criteriaQuery.orderBy(builder.asc(orderByFromEntity.get(nomePropriedadeOrdenacao)));
			} else if (filtro.getPropriedadeOrdenacao() != null) {
				criteriaQuery.orderBy(builder.desc(orderByFromEntity.get(nomePropriedadeOrdenacao)));
			}
		}

		TypedQuery<Devolucao> query = manager.createQuery(criteriaQuery);

		query.setFirstResult(filtro.getPrimeiroRegistro());
		query.setMaxResults(filtro.getQuantidadeRegistros());

		return query.getResultList();
	}

	public int quantidadeFiltrados(DevolucaoFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);

		Root<Devolucao> devolucaoRoot = criteriaQuery.from(Devolucao.class);
		Join<Devolucao, Cliente> clienteJoin = devolucaoRoot.join("cliente", JoinType.INNER);
		Join<Devolucao, Cliente> vendedorJoin = devolucaoRoot.join("vendedor", JoinType.INNER);

		List<Predicate> predicates = criarPredicatesParaFiltro(filtro, devolucaoRoot, clienteJoin, vendedorJoin);

		criteriaQuery.select(builder.count(devolucaoRoot));
		criteriaQuery.where(predicates.toArray(new Predicate[0]));

		TypedQuery<Long> query = manager.createQuery(criteriaQuery);

		return query.getSingleResult().intValue();
	}

	/*public List<Object> produtoPorCliente(Long id) {
		return this.manager.createQuery("SELECT pr.nome FROM ItemPedido as ip INNER JOIN Produto as pr ON pr.id = ip.produto.id INNER JOIN Pedido as p ON p.id = ip.pedido.id WHERE p.id = :id", Object.class).setParameter("id",  id).getResultList();
	}*/

	public List<Pedido> porPedido(String nome) {
		return this.manager.createQuery("from Pedido where upper(cliente.nome) like :nome", Pedido.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	/*public List<Pedido> produtosPorPedido(Long id) {
		return this.manager.createQuery("from Pedido where cliente.id = :id", Pedido.class).setParameter("id", id)
				.getResultList();
	}*/

	public List<Pedido> pedidos() {
		return this.manager.createQuery("from Pedido", Pedido.class).getResultList();
	}

	public Devolucao guardar(Devolucao devolucao) {
		return this.manager.merge(devolucao);
	}

	public Devolucao porId(Long id) {
		return this.manager.find(Devolucao.class, id);
	}

}