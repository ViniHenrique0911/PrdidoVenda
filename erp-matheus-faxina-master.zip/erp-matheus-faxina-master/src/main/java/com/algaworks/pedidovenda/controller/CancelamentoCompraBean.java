package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.ContasPagar;
import com.algaworks.pedidovenda.model.Compra;
import com.algaworks.pedidovenda.model.StatusContasPagar;
import com.algaworks.pedidovenda.repository.Compras;
import com.algaworks.pedidovenda.service.CancelamentoCompraService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@RequestScoped
public class CancelamentoCompraBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CancelamentoCompraService cancelamentoCompraService;

	@Inject
	private Event<CompraAlteradoEvent> compraAlteradoEvent;

	@Inject
	@CompraEdicao
	private Compra compra;

	@Inject
	private Compras compras;

	public void cancelarCompra() {
		try {
			this.compra = this.cancelamentoCompraService.cancelar(this.compra);
			this.compraAlteradoEvent.fire(new CompraAlteradoEvent(this.compra));
			cancelaContasPagar();
			
			FacesUtil.addInfoMessage("Compra foi cancelado com sucesso!");
		} catch (NegocioException ne) {
			FacesUtil.addErrorMessage(ne.getMessage());
		}
	}

	public void cancelaContasPagar() {
		for (ContasPagar contasReceber : compra.getContasRecebers()) {
			try {
				contasReceber.setStatus(StatusContasPagar.CANCELADO);
				cancelamentoCompraService.salvarSemIf(contasReceber);
			} catch (NegocioException e) {
				e.printStackTrace();
			}
		}
	}
}
