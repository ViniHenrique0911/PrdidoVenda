package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Parcela;
import com.algaworks.pedidovenda.service.CadastroParcelaService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroParcelaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Parcela parcela;
	
	@Inject
	private CadastroParcelaService cadastroParcelaService;
	
	public void inicializar(){
		if (parcela == null) {
			limpar();
		}
	}
	
	public void limpar() {
		this.parcela = new Parcela();
	}
	
	public void salvar() {
		try {
			cadastroParcelaService.salvar(parcela);
			limpar();
			
			FacesUtil.addInfoMessage("Parcela foi salva com sucesso!");
		} catch(NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}
	
	public Parcela getParcela() {
		return parcela;
	}
	
	public void setParcela(Parcela parcela) {
		this.parcela = parcela;
	}
	
	public boolean isEditando() {
		return parcela != null && parcela.getId() == null;
	}

}
