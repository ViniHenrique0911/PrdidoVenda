package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Cidade;
import com.algaworks.pedidovenda.model.Estado;
import com.algaworks.pedidovenda.repository.Cidades;
import com.algaworks.pedidovenda.service.CadastroCidadeService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroCidadeBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Cidade cidade;

	@Inject
	private Cidades cidades;

	@Inject
	private CadastroCidadeService cadastroCidadeService;

	private List<Estado> listEstados;

	public void inicializar() {
		this.listEstados = cidades.porEstado();
		if (cidade == null) {
			limpar();
		}
	}

	public void limpar() {
		this.cidade = new Cidade();
	}

	public void salvar() {
		try {
			cadastroCidadeService.salvar(cidade);
			limpar();

			FacesUtil.addInfoMessage("Cidade foi salvo com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public Cidade getCidade() {
		return cidade;
	}

	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}

	public boolean isEditando() {
		return cidade != null && cidade.getId() == null;
	}

	public List<Estado> getListEstados() {
		return listEstados;
	}

}
