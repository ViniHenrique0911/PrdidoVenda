package com.algaworks.pedidovenda.repository;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Marca;
import com.algaworks.pedidovenda.model.Preco;
import com.algaworks.pedidovenda.model.Produto;
import com.algaworks.pedidovenda.model.Usuario;
import com.algaworks.pedidovenda.repository.filter.ProdutoFilter;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class Produtos implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Produto guardar(Produto produto) {
		return manager.merge(produto);
	}

	@SuppressWarnings("unchecked")
	public List<Produto> buscarTodos() {
		return manager.createQuery("from Produto order by nome asc").getResultList();
	}
	
	public List<Produto> todos() {
		return manager.createQuery("from Produto", Produto.class).getResultList();
	}

	@Transactional
	public void remover(Produto produto) throws NegocioException {
		try {
			produto = porId(produto.getId());
			manager.remove(produto);
			manager.flush();
		} catch (PersistenceException e) {
			throw new NegocioException("Produto não pode ser excluído.");
		}
	}

	public Produto porSku(String sku) {
		try {
			return manager.createQuery("from Produto where upper(sku) = :sku", Produto.class)
					.setParameter("sku", sku.toUpperCase()).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public List<Preco> porGrupoPreco(Long id) {
		return this.manager.createQuery("from Preco where produto_id = :id", Preco.class).setParameter("id", id)
				.getResultList();
	}

	public TypedQuery<Preco> porGrupo(Long id) {
		return (TypedQuery<Preco>) this.manager.createQuery("from Preco where produto_id = :id", Preco.class)
				.setParameter("id", id).getResultList();
	}

	public BigDecimal porPreco(Preco preco) {
		return (BigDecimal) this.manager
				.createQuery("select valor from Preco where nome = :nome and produto_id = :id", BigDecimal.class)
				.setParameter("nome", preco.getNome()).setParameter("id", preco.getProduto().getId()).getResultList();
	}

	public Long getPedidoTotalPorFuncionario(Usuario f) {
		return (Long) manager.createQuery("select count(p.id) from Pedido P where P.vendedor.id = :num")
				.setParameter("num", f.getId()).getSingleResult();
	}

	public List<Produto> filtrados(ProdutoFilter filtro) {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Produto> criteriaQuery = builder.createQuery(Produto.class);
		List<Predicate> predicates = new ArrayList<>();

		Root<Produto> produtoRoot = criteriaQuery.from(Produto.class);

		if (StringUtils.isNotBlank(filtro.getSku())) {
			predicates.add(builder.equal(produtoRoot.get("sku"), filtro.getSku()));
		}

		if (StringUtils.isNotBlank(filtro.getNome())) {
			predicates.add(
					builder.like(builder.lower(produtoRoot.get("nome")), "%" + filtro.getNome().toLowerCase() + "%"));
		}

		criteriaQuery.select(produtoRoot);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(builder.asc(produtoRoot.get("nome")));

		TypedQuery<Produto> query = manager.createQuery(criteriaQuery);
		return query.getResultList();
	}

	public List<Marca> porMarca(String nome) {
		return this.manager.createQuery("from Marca where upper(nome) like :nome", Marca.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

	public Produto porId(Long id) {
		return manager.find(Produto.class, id);
	}

	public List<Produto> porNome(String nome) {
		return this.manager.createQuery("from Produto where upper(nome) like :nome and ativo = '1'", Produto.class)
				.setParameter("nome", nome.toUpperCase() + "%").getResultList();
	}

}