package com.algaworks.pedidovenda.service;

import java.io.Serializable;

import javax.inject.Inject;

import com.algaworks.pedidovenda.model.Meta;
import com.algaworks.pedidovenda.repository.Metas;
import com.algaworks.pedidovenda.util.jpa.Transactional;

public class CadastroMetaService implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Metas metas;
	
	@Transactional
	public Meta salvar(Meta meta) throws NegocioException {
		return metas.guardar(meta);
	}
}