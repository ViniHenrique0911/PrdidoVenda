package com.algaworks.pedidovenda.boleto;

import java.io.File;
import java.io.Serializable;

import com.algaworks.pedidovenda.model.Boleto;
import com.algaworks.pedidovenda.model.ContasReceber;

public interface EmissorBoleto extends Serializable {

	public byte[] gerarBoleto(Boleto cedenteSistema, ContasReceber cobrancaSistema);
	public File gerarBoletoEmArquivo(String arquivo, Boleto cedenteSistema, ContasReceber cobrancaSistema);

}
