package com.algaworks.pedidovenda.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.FormaPagamentoo;
import com.algaworks.pedidovenda.model.Parcela;
import com.algaworks.pedidovenda.service.CadastroFormaPagamentoService;
import com.algaworks.pedidovenda.service.NegocioException;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class CadastroFormaPagamentoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private FormaPagamentoo formaPagamento;

	@Inject
	private CadastroFormaPagamentoService cadastroFormaPagamentoService;

	private Parcela parcela = new Parcela();

	private boolean editandoParcela;

	public void inicializar() {
		if (formaPagamento == null) {
			limpar();
		}
	}

	public void limpar() {
		this.formaPagamento = new FormaPagamentoo();
	}

	public void salvar() {
		try {
			cadastroFormaPagamentoService.salvar(formaPagamento);
			limpar();

			FacesUtil.addInfoMessage("Forma de pagamento foi salvo com sucesso!");
		} catch (NegocioException e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public void novaParcela() {
		this.parcela = new Parcela();
		this.parcela.setFormaPagamento(this.formaPagamento);
		this.editandoParcela = false;
	}

	public void editarParcela(Parcela parcela) {
		this.parcela = parcela;
		this.editandoParcela = true;
	}

	public void confirmarParcela() {
		if (!this.formaPagamento.getParcelas().contains(this.parcela)
				|| this.formaPagamento.getParcelas().contains(this.parcela)) {
			if (this.editandoParcela == false) {
				this.formaPagamento.getParcelas().add(this.parcela);
			}
		}
	}

	public void excluirParcela(Parcela parcela) {
		this.formaPagamento.getParcelas().remove(parcela);
	}

	public FormaPagamentoo getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(FormaPagamentoo formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public boolean isEditando() {
		return formaPagamento != null && formaPagamento.getId() == null;
	}

	public Parcela getParcela() {
		return parcela;
	}

	public void setParcela(Parcela parcela) {
		this.parcela = parcela;
	}

	public boolean isEditandoParcela() {
		return editandoParcela;
	}

	public void setEditandoParcela(boolean editandoParcela) {
		this.editandoParcela = editandoParcela;
	}

}
