package com.algaworks.pedidovenda.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.algaworks.pedidovenda.model.Grupo;
import com.algaworks.pedidovenda.repository.Grupoos;
import com.algaworks.pedidovenda.repository.filter.GrupoFilter;
import com.algaworks.pedidovenda.util.jsf.FacesUtil;

@Named
@ViewScoped
public class PesquisaGruposBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Grupoos grupos;

	private GrupoFilter filtro;

	private List<Grupo> gruposFiltrados;

	private Grupo grupoSelecionado;

	public PesquisaGruposBean() {
		filtro = new GrupoFilter();
	}

	public void excluir() {
		try {
			grupos.remover(grupoSelecionado);
			gruposFiltrados.remove(grupoSelecionado);

			FacesUtil.addInfoMessage("Grupo " + grupoSelecionado.getNome() + " foi excluído com sucesso.");
		} catch (Exception e) {
			FacesUtil.addErrorMessage(e.getMessage());
		}
	}

	public void pesquisar() {
		gruposFiltrados = grupos.filtrados(filtro);
	}

	public List<Grupo> getGrupoosFiltrados() {
		return gruposFiltrados;
	}

	public GrupoFilter getFiltro() {
		return filtro;
	}

	public Grupo getGrupoSelecionado() {
		return grupoSelecionado;
	}

	public void setGrupoSelecionado(Grupo grupoSelecionado) {
		this.grupoSelecionado = grupoSelecionado;
	}

}