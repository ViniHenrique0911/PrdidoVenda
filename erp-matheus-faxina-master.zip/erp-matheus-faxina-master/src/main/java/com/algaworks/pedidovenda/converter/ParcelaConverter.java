package com.algaworks.pedidovenda.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.algaworks.pedidovenda.model.Parcela;
import com.algaworks.pedidovenda.repository.Parcelas;

@FacesConverter(forClass = Parcela.class)
public class ParcelaConverter implements Converter {

	@Inject
	private Parcelas parcelas;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Parcela retorno = null;

		if (StringUtils.isNotEmpty(value)) {
			retorno = this.parcelas.porId(new Long(value));
		}

		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			Parcela parcela = (Parcela) value; 
			return parcela != null && parcela.getId() != null ? parcela.getId().toString() : null;
		}
		return "";
	}

}